from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass

from .provider import ProviderError, env_int, post_json, validate_provider_url


@dataclass(frozen=True, slots=True)
class EmbeddingConfig:
    endpoint: str
    model: str
    api_key: str = ""
    timeout_seconds: int = 30

    @classmethod
    def from_env(cls) -> "EmbeddingConfig | None":
        endpoint = os.getenv("SIC_EMBEDDING_URL", "").strip()
        model = os.getenv("SIC_EMBEDDING_MODEL", "").strip()
        if not endpoint or not model:
            return None
        validate_provider_url(endpoint)
        return cls(endpoint, model, os.getenv("SIC_EMBEDDING_API_KEY", "").strip(), env_int("SIC_EMBEDDING_TIMEOUT", 30, 1, 600))


def call_embeddings(config: EmbeddingConfig, texts: list[str]) -> list[list[float]]:
    if not texts or len(texts) > 101:
        raise ProviderError("La solicitud de embeddings debe contener entre 1 y 101 textos.")
    raw = post_json(config.endpoint, {"model": config.model, "input": texts}, api_key=config.api_key,
                    timeout=config.timeout_seconds, max_bytes=4_000_000, label="proveedor de embeddings",
                    size_error="La respuesta de embeddings supera 4 MB.")
    try:
        data = json.loads(raw.decode("utf-8"))
        rows = sorted(data["data"], key=lambda row: row["index"])
        vectors = [row["embedding"] for row in rows]
        if len(vectors) != len(texts):
            raise ValueError("cantidad de vectores distinta a la solicitada")
        clean = []
        for vector in vectors:
            if not isinstance(vector, list) or not vector or any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in vector):
                raise ValueError("vector inválido")
            clean.append([float(x) for x in vector])
        if len({len(v) for v in clean}) != 1:
            raise ValueError("dimensiones incompatibles")
        return clean
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise ProviderError("Respuesta de embeddings incompatible: se esperaba data[index, embedding].") from exc
