from __future__ import annotations

import json
import os
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

from .contracts import utc_now

MAX_CONTENT = 20_000
MAX_TITLE = 300


def _like(query: str) -> str:
    """Escape LIKE wildcards so '100%' or 'a_b' are searched literally."""
    return "%" + query[:200].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


class MemoryStore:
    """Local SQLite store for explicit memories and versioned knowledge records."""

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @contextmanager
    def _connect(self):
        connection = sqlite3.connect(self.db_path, timeout=30)
        connection.execute("PRAGMA busy_timeout=30000")
        connection.row_factory = sqlite3.Row
        try:
            connection.execute("PRAGMA foreign_keys = ON")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _initialize(self) -> None:
        with self._connect() as db:
            # Multiple workers may initialize the same database simultaneously.
            for attempt in range(60):
                try:
                    db.execute("PRAGMA journal_mode = WAL")
                    break
                except sqlite3.OperationalError as exc:
                    if "locked" not in str(exc).lower() or attempt == 59:
                        raise
                    time.sleep(0.05)
            db.executescript("""
                CREATE TABLE IF NOT EXISTS memories (
                    memory_id TEXT PRIMARY KEY,
                    content TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT 'general',
                    source TEXT NOT NULL DEFAULT 'user',
                    confidence REAL NOT NULL DEFAULT 1.0,
                    tags_json TEXT NOT NULL DEFAULT '[]',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active'
                );
                CREATE INDEX IF NOT EXISTS idx_memories_status_created
                    ON memories(status, created_at DESC);
                CREATE TABLE IF NOT EXISTS knowledge (
                    knowledge_id TEXT PRIMARY KEY,
                    topic TEXT NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source_refs_json TEXT NOT NULL DEFAULT '[]',
                    validation_status TEXT NOT NULL DEFAULT 'unverified',
                    version INTEGER NOT NULL,
                    supersedes TEXT,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'active'
                );
                CREATE INDEX IF NOT EXISTS idx_knowledge_topic_version
                    ON knowledge(topic, version DESC);
                CREATE INDEX IF NOT EXISTS idx_knowledge_status
                    ON knowledge(status, created_at DESC);
            """)
            # Repair legacy duplicate version numbers deterministically before
            # enforcing the invariant for all future writes.
            db.execute("BEGIN IMMEDIATE")
            topics = [r[0] for r in db.execute("SELECT DISTINCT topic FROM knowledge").fetchall()]
            for topic in topics:
                rows = db.execute(
                    "SELECT knowledge_id FROM knowledge WHERE topic=? ORDER BY version, created_at, knowledge_id",
                    (topic,),
                ).fetchall()
                previous_id = None
                for version, row in enumerate(rows, start=1):
                    db.execute(
                        "UPDATE knowledge SET version=?, supersedes=? WHERE knowledge_id=?",
                        (version, previous_id, row[0]),
                    )
                    previous_id = row[0]
            db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_knowledge_topic_version ON knowledge(topic, version)")
        self._secure_permissions()

    def _secure_permissions(self) -> None:
        # Best-effort owner-only permissions on POSIX; Windows ACLs remain OS-managed.
        for candidate in (self.db_path, Path(str(self.db_path) + "-wal"), Path(str(self.db_path) + "-shm")):
            try:
                if candidate.exists():
                    os.chmod(candidate, 0o600)
            except OSError:
                pass

    @staticmethod
    def _text(value: object, field: str, limit: int, required: bool = True) -> str:
        if not isinstance(value, str):
            raise ValueError(f"{field} debe ser texto.")
        value = value.strip()
        if required and not value:
            raise ValueError(f"{field} es obligatorio.")
        if len(value) > limit:
            raise ValueError(f"{field} supera el límite de {limit} caracteres.")
        return value

    @staticmethod
    def _string_list(value: object, field: str, limit: int = 30) -> list[str]:
        if not isinstance(value, list) or len(value) > limit:
            raise ValueError(f"{field} debe ser una lista de hasta {limit} elementos.")
        if any(not isinstance(item, str) or len(item) > 500 for item in value):
            raise ValueError(f"Cada elemento de {field} debe ser texto de hasta 500 caracteres.")
        return [item.strip() for item in value if item.strip()]

    def add_memory(self, raw: dict) -> dict:
        if not isinstance(raw, dict):
            raise ValueError("El cuerpo debe ser un objeto JSON.")
        content = self._text(raw.get("content"), "content", MAX_CONTENT)
        category = self._text(raw.get("category", "general"), "category", 80)
        source = self._text(raw.get("source", "user"), "source", 300)
        confidence = raw.get("confidence", 1.0)
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
            raise ValueError("confidence debe ser un número entre 0 y 1.")
        tags = self._string_list(raw.get("tags", []), "tags")
        now, memory_id = utc_now(), f"mem_{uuid4().hex}"
        with self._connect() as db:
            db.execute("""INSERT INTO memories
                (memory_id, content, category, source, confidence, tags_json, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (memory_id, content, category, source, float(confidence), json.dumps(tags), now, now))
        self._secure_permissions()
        return self.get_memory(memory_id)

    def get_memory(self, memory_id: str) -> dict | None:
        with self._connect() as db:
            row = db.execute("SELECT * FROM memories WHERE memory_id=?", (memory_id,)).fetchone()
        return self._memory_dict(row) if row else None

    @staticmethod
    def _memory_dict(row: sqlite3.Row) -> dict:
        item = dict(row)
        item["tags"] = json.loads(item.pop("tags_json"))
        return item

    def list_memories(self, query: str = "", category: str = "", limit: int = 50) -> list[dict]:
        if not 1 <= limit <= 100:
            raise ValueError("limit debe estar entre 1 y 100.")
        clauses, params = ["status='active'"], []
        if query:
            q = _like(query)
            clauses.append("(content LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\' OR source LIKE ? ESCAPE '\\')")
            params.extend([q, q, q])
        if category:
            clauses.append("category=?")
            params.append(category[:80])
        with self._connect() as db:
            rows = db.execute(
                f"SELECT * FROM memories WHERE {' AND '.join(clauses)} ORDER BY created_at DESC, rowid DESC LIMIT ?",
                (*params, limit),
            ).fetchall()
        return [self._memory_dict(row) for row in rows]

    def scan_memories(self, limit: int = 1000) -> list[dict]:
        """Most recent active memories for internal retrieval (not capped at the API's 100)."""
        if not 1 <= limit <= 5000:
            raise ValueError("limit debe estar entre 1 y 5000.")
        with self._connect() as db:
            rows = db.execute("SELECT * FROM memories WHERE status='active' ORDER BY created_at DESC, rowid DESC LIMIT ?",
                              (limit,)).fetchall()
        return [self._memory_dict(row) for row in rows]

    def latest_knowledge(self, limit: int = 1000) -> list[dict]:
        """Newest non-rejected version of each topic. list_knowledge orders by topic and
        returns every version, so with many topics/versions its first page hides later topics."""
        if not 1 <= limit <= 5000:
            raise ValueError("limit debe estar entre 1 y 5000.")
        with self._connect() as db:
            rows = db.execute("""SELECT k.* FROM knowledge k
                JOIN (SELECT topic, MAX(version) AS v FROM knowledge WHERE status='active' GROUP BY topic) latest
                  ON k.topic = latest.topic AND k.version = latest.v
                WHERE k.status='active' AND k.validation_status != 'rejected'
                ORDER BY k.created_at DESC, k.rowid DESC LIMIT ?""", (limit,)).fetchall()
        return [self._knowledge_dict(row) for row in rows]

    def delete_memory(self, memory_id: str) -> bool:
        with self._connect() as db:
            cursor = db.execute("DELETE FROM memories WHERE memory_id=?", (memory_id,))
        return cursor.rowcount > 0

    def add_knowledge(self, raw: dict) -> dict:
        if not isinstance(raw, dict):
            raise ValueError("El cuerpo debe ser un objeto JSON.")
        topic = self._text(raw.get("topic"), "topic", 160)
        title = self._text(raw.get("title"), "title", MAX_TITLE)
        content = self._text(raw.get("content"), "content", MAX_CONTENT)
        refs = self._string_list(raw.get("source_refs", []), "source_refs")
        validation = self._text(raw.get("validation_status", "unverified"), "validation_status", 40)
        if validation not in {"unverified", "reviewed", "verified", "rejected"}:
            raise ValueError("validation_status debe ser unverified, reviewed, verified o rejected.")
        item_id, now = f"kn_{uuid4().hex}", utc_now()
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            previous = db.execute(
                "SELECT knowledge_id, version FROM knowledge WHERE topic=? ORDER BY version DESC LIMIT 1",
                (topic,),
            ).fetchone()
            version = previous["version"] + 1 if previous else 1
            supersedes = previous["knowledge_id"] if previous else None
            db.execute("""INSERT INTO knowledge
                (knowledge_id, topic, title, content, source_refs_json, validation_status,
                 version, supersedes, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (item_id, topic, title, content, json.dumps(refs), validation, version, supersedes, now))
        self._secure_permissions()
        return self.get_knowledge(item_id)

    @staticmethod
    def _knowledge_dict(row: sqlite3.Row) -> dict:
        item = dict(row)
        item["source_refs"] = json.loads(item.pop("source_refs_json"))
        return item

    def get_knowledge(self, knowledge_id: str) -> dict | None:
        with self._connect() as db:
            row = db.execute("SELECT * FROM knowledge WHERE knowledge_id=?", (knowledge_id,)).fetchone()
        return self._knowledge_dict(row) if row else None

    def list_knowledge(self, query: str = "", limit: int = 50) -> list[dict]:
        if not 1 <= limit <= 100:
            raise ValueError("limit debe estar entre 1 y 100.")
        clauses, params = ["status='active'"], []
        if query:
            q = _like(query)
            clauses.append("(topic LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\' OR content LIKE ? ESCAPE '\\')")
            params.extend([q, q, q])
        with self._connect() as db:
            rows = db.execute(
                f"SELECT * FROM knowledge WHERE {' AND '.join(clauses)} ORDER BY topic, version DESC LIMIT ?",
                (*params, limit),
            ).fetchall()
        return [self._knowledge_dict(row) for row in rows]

    def delete_knowledge(self, knowledge_id: str) -> bool:
        with self._connect() as db:
            cursor = db.execute("DELETE FROM knowledge WHERE knowledge_id=?", (knowledge_id,))
        return cursor.rowcount > 0
