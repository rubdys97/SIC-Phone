from __future__ import annotations

import argparse
import json
import sys

from .server import serve
from .service import SICService


def main() -> None:
    parser = argparse.ArgumentParser(prog="sic", description="Strategic Intelligence Core")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("serve", help="Inicia la API local")
    prepare = sub.add_parser("prepare", help="Prepara un objetivo sin invocar un modelo")
    prepare.add_argument("objective")
    args = parser.parse_args()
    if args.command == "serve":
        try:
            serve()
        except (ValueError, RuntimeError) as exc:  # ProviderError/SandboxError subclass these
            print(f"Error de configuración: {exc}", file=sys.stderr)
            raise SystemExit(2) from None
    else:
        print(json.dumps(SICService().prepare({"objective": args.objective}), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
