from __future__ import annotations

import http.client
import ipaddress
import json
import os
import socket
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass


class ProviderError(RuntimeError):
    pass


def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    """Read a bounded integer from the environment with a clear error message."""
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} debe ser un entero.") from exc
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} debe estar entre {minimum} y {maximum}.")
    return value


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    endpoint: str
    model: str
    api_key: str
    timeout_seconds: int = 90

    @classmethod
    def from_env(cls) -> "ProviderConfig | None":
        endpoint = os.getenv("SIC_PROVIDER_URL", "").strip()
        model = os.getenv("SIC_MODEL", "").strip()
        api_key = os.getenv("SIC_PROVIDER_API_KEY", "").strip()
        if not endpoint or not model:
            return None
        validate_provider_url(endpoint)
        return cls(endpoint, model, api_key, env_int("SIC_PROVIDER_TIMEOUT", 90, 1, 600))


def _is_loopback(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def validate_provider_url(endpoint: str) -> None:
    parsed = urllib.parse.urlparse(endpoint)
    if parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname and _is_loopback(parsed.hostname)):
        raise ProviderError("El proveedor debe usar HTTPS. HTTP solo se permite en localhost para modelos locales.")
    if not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise ProviderError("URL del proveedor no válida.")
    if parsed.scheme not in {"http", "https"}:
        raise ProviderError("Esquema de URL no permitido.")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """urllib copies the Authorization header across redirects, including to other
    hosts or to plain HTTP. A provider endpoint has no reason to redirect, so refuse."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _opener(endpoint: str) -> urllib.request.OpenerDirector:
    handlers: list = [_NoRedirect()]
    if _is_loopback(urllib.parse.urlparse(endpoint).hostname or ""):
        # Local model servers must never be routed through an environment proxy.
        handlers.append(urllib.request.ProxyHandler({}))
    return urllib.request.build_opener(*handlers)


def post_json(endpoint: str, payload: dict, *, api_key: str = "", timeout: float = 90,
              max_bytes: int = 2_000_000, label: str = "proveedor",
              size_error: str | None = None) -> bytes:
    """POST a JSON body and return the raw response, bounded in size, without following redirects."""
    validate_provider_url(endpoint)
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with _opener(endpoint).open(request, timeout=timeout) as response:
            raw = response.read(max_bytes + 1)
    except urllib.error.HTTPError as exc:
        if 300 <= exc.code < 400:
            raise ProviderError(
                f"El {label} respondió con una redirección HTTP {exc.code}. SIC no sigue "
                "redirecciones para no reenviar credenciales; configura la URL final."
            ) from exc
        detail = exc.read(1_000).decode("utf-8", "replace")
        raise ProviderError(f"El {label} respondió HTTP {exc.code}: {detail}") from exc
    except (urllib.error.URLError, OSError, http.client.HTTPException) as exc:
        raise ProviderError(f"No se pudo conectar con el {label}: {exc}") from exc
    if len(raw) > max_bytes:
        raise ProviderError(size_error or f"La respuesta del {label} excede {max_bytes // 1_000_000} MB.")
    return raw


def call_chat_completion(config: ProviderConfig, system_prompt: str, user_prompt: str) -> str:
    payload = {
        "model": config.model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.2,
    }
    raw = post_json(config.endpoint, payload, api_key=config.api_key, timeout=config.timeout_seconds,
                    max_bytes=2_000_000, label="proveedor",
                    size_error="La respuesta del proveedor excede 2 MB.")
    try:
        data = json.loads(raw.decode("utf-8"))
        content = data["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise ProviderError("Respuesta incompatible: se esperaba Chat Completions con choices[0].message.content.") from exc
    if not isinstance(content, str) or not content.strip():
        raise ProviderError("El proveedor devolvió contenido vacío o no textual.")
    return content.strip()
