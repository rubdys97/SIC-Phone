from __future__ import annotations

import re
import unicodedata

from .contracts import AnalysisEnvelope, AnalysisRequest, new_task_id, utc_now

# Terms are matched against whole words (accent-insensitive). A trailing "*" means
# "any word starting with this prefix". Substring matching misclassified common text:
# "capital" contains "api", "ingredientes" and "predecir" contain "red".
_DOMAIN_TERMS = {
    "cybersecurity": ("cve", "cwe", "ciberseguridad", "vulnerabilidad*", "vulnerability", "pentest*", "seguridad",
                      "security", "firmware", "apk", "malware", "red", "redes", "exploit*", "hacking"),
    "software_engineering": ("codigo", "codigos", "programa", "programas", "software", "aplicacion", "aplicaciones",
                             "api", "apis", "bug", "bugs", "compilar", "repositorio*", "arquitectura"),
    "research": ("investigar", "investigacion", "investigaciones", "fuentes", "estudio", "estudios", "comparar",
                 "evidencia", "actualizacion"),
}


def _fold(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text.casefold())
    return "".join(c for c in decomposed if not unicodedata.combining(c))


def words(text: str) -> list[str]:
    return re.findall(r"\w+", _fold(text))


def count_matches(tokens: list[str], terms: tuple[str, ...]) -> int:
    """Number of distinct terms present among the tokens (exact word or prefix*)."""
    present = set(tokens)
    total = 0
    for term in terms:
        if term.endswith("*"):
            prefix = term[:-1]
            total += any(token.startswith(prefix) for token in present)
        else:
            total += term in present
    return total


def classify_domain(text: str) -> str:
    tokens = words(text)
    scores = {domain: count_matches(tokens, terms) for domain, terms in _DOMAIN_TERMS.items()}
    winner = max(scores, key=scores.get)
    return winner if scores[winner] else "general_strategy"


def prepare_analysis(request: AnalysisRequest) -> AnalysisEnvelope:
    combined = "\n".join([request.objective, *request.context, *request.constraints])
    domain = classify_domain(combined)
    unknowns: list[str] = []
    assumptions: list[str] = []

    if domain == "cybersecurity":
        unknowns.append("No se ha especificado el propietario del objetivo ni el alcance autorizado.")
        assumptions.append("No se autoriza ninguna prueba activa hasta confirmar propiedad o permiso expreso.")
    if not request.success_criteria:
        unknowns.append("No se definieron criterios de éxito medibles.")
    if not request.context:
        unknowns.append("No se proporcionó contexto adicional; el análisis debe evitar completar datos por inferencia.")

    facts = [f"Objetivo declarado por el usuario: {request.objective}"]
    facts.extend(f"Contexto proporcionado: {item}" for item in request.context)

    return AnalysisEnvelope(
        task_id=new_task_id(),
        created_at=utc_now(),
        objective=request.objective,
        domain=domain,
        facts=facts,
        assumptions=assumptions,
        unknowns=unknowns,
        constraints=request.constraints,
        success_criteria=request.success_criteria,
        execution_mode=request.execution_mode,
    )
