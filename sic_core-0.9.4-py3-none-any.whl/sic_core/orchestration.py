from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable
from uuid import uuid4
import hashlib
import json
import time
import secrets
import threading


class ToolError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ToolSpec:
    name: str
    description: str
    risk: str = "read_only"
    requires_approval: bool = False
    input_schema: dict[str, Any] | None = None

    def public(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "risk": self.risk,
            "requires_approval": self.requires_approval,
            "input_schema": self.input_schema or {"type": "object"},
        }


@dataclass(slots=True)
class RegisteredTool:
    spec: ToolSpec
    handler: Callable[[dict[str, Any]], Any]


class ToolRegistry:
    """Explicit allowlist with one-use, argument-bound approvals for risky tools."""

    APPROVAL_TTL_SECONDS = 300

    def __init__(self, audit_log: Any | None = None) -> None:
        self._tools: dict[str, RegisteredTool] = {}
        self._audit_log = audit_log
        self._lock = threading.RLock()
        self._pending: dict[str, dict[str, Any]] = {}
        self._approvals: dict[str, dict[str, Any]] = {}

    def _audit(self, *, call_id: str, tool: str, status: str, arguments: dict[str, Any], details: dict[str, Any] | None = None) -> None:
        if self._audit_log is None:
            return
        encoded = json.dumps(arguments, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        self._audit_log.record({"event_type": "tool_invocation", "call_id": call_id, "tool": tool,
                                "status": status, "arguments_sha256": hashlib.sha256(encoded).hexdigest(),
                                "details": details or {}})

    @staticmethod
    def _fingerprint(name: str, arguments: dict[str, Any]) -> str:
        encoded = json.dumps({"tool": name, "arguments": arguments}, ensure_ascii=False, sort_keys=True,
                             separators=(",", ":"), allow_nan=False).encode()
        return hashlib.sha256(encoded).hexdigest()

    def register(self, spec: ToolSpec, handler: Callable[[dict[str, Any]], Any]) -> None:
        if not spec.name or len(spec.name) > 80 or not spec.name.replace("_", "").replace("-", "").isalnum():
            raise ToolError("Nombre de herramienta no válido.")
        if spec.risk not in {"read_only", "low", "medium", "high", "critical"}:
            raise ToolError("Nivel de riesgo no válido.")
        if spec.input_schema is not None and (not isinstance(spec.input_schema, dict) or spec.input_schema.get("type") != "object"):
            raise ToolError("input_schema debe ser un JSON Schema de tipo object.")
        with self._lock:
            if spec.name in self._tools:
                raise ToolError("La herramienta ya está registrada.")
            self._tools[spec.name] = RegisteredTool(spec, handler)

    def list(self) -> list[dict[str, Any]]:
        with self._lock:
            return [self._tools[name].spec.public() for name in sorted(self._tools)]

    def approve(self, request_id: str, *, actor: str = "configured_approver") -> dict[str, Any]:
        if not isinstance(request_id, str) or not request_id or len(request_id) > 100:
            raise ToolError("Identificador de aprobación no válido.")
        if not isinstance(actor, str) or not actor.strip() or len(actor) > 120:
            raise ToolError("Identidad del aprobador no válida.")
        now = time.time()
        with self._lock:
            pending = self._pending.pop(request_id, None)
            if pending is None or pending["expires_at"] < now:
                raise ToolError("Solicitud de aprobación inexistente o vencida.")
            token = secrets.token_urlsafe(32)
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            approval = {**pending, "actor": actor[:120], "approved_at": now, "token_hash": token_hash}
            self._approvals[token_hash] = approval
        self._audit(call_id=pending["call_id"], tool=pending["name"], status="approved",
                    arguments=pending["arguments"], details={"actor": actor[:120], "expires_at": pending["expires_at"]})
        return {"status": "approved", "call_id": pending["call_id"], "tool": pending["name"],
                "approval_token": token, "expires_in_seconds": max(0, int(pending["expires_at"] - now)),
                "single_use": True}

    def invoke(self, name: str, arguments: dict[str, Any], *, approval_token: str | None = None) -> dict[str, Any]:
        call_id = f"call_{uuid4().hex[:16]}"
        tool = self._tools.get(name)
        if tool is None:
            self._audit(call_id=call_id, tool=str(name)[:80], status="rejected_unknown_tool", arguments={})
            raise ToolError("Herramienta no registrada o no autorizada.")
        if not isinstance(arguments, dict):
            raise ToolError("arguments debe ser un objeto JSON.")
        try:
            encoded_args = json.dumps(arguments, ensure_ascii=False, allow_nan=False)
        except (TypeError, ValueError) as exc:
            raise ToolError("arguments contiene valores JSON no válidos.") from exc
        if len(encoded_args.encode("utf-8")) > 16_000:
            raise ToolError("Los argumentos superan el límite permitido.")
        spec = tool.spec
        if spec.input_schema is not None:
            try:
                from .mcp import _validate_arguments
                _validate_arguments(spec.input_schema, arguments)
            except Exception as exc:
                raise ToolError(f"Argumentos rechazados por el esquema de la herramienta: {str(exc)[:300]}") from exc
        approval_required = spec.requires_approval or spec.risk in {"medium", "high", "critical"}
        if approval_required:
            if approval_token is not None and (not isinstance(approval_token, str) or len(approval_token) > 256):
                raise ToolError("Token de aprobación no válido.")
            fingerprint = self._fingerprint(name, arguments)
            if not approval_token:
                request_id = f"apr_{uuid4().hex}"
                pending = {"request_id": request_id, "call_id": call_id, "name": name,
                           "arguments": json.loads(encoded_args), "fingerprint": fingerprint,
                           "expires_at": time.time() + self.APPROVAL_TTL_SECONDS}
                with self._lock:
                    now = time.time()
                    self._pending = {key: value for key, value in self._pending.items() if value["expires_at"] >= now}
                    self._approvals = {key: value for key, value in self._approvals.items() if value["expires_at"] >= now}
                    if len(self._pending) >= 1024:
                        raise ToolError("Cola de aprobaciones llena; inténtalo más tarde.")
                    self._pending[request_id] = pending
                self._audit(call_id=call_id, tool=name, status="approval_required", arguments=arguments,
                            details={"risk": spec.risk, "request_id": request_id, "expires_at": pending["expires_at"]})
                return {"status": "approval_required", "approval_request_id": request_id, "call_id": call_id,
                        "tool": name, "risk": spec.risk, "expires_in_seconds": self.APPROVAL_TTL_SECONDS,
                        "message": "No se ejecutó. Un aprobador autorizado debe aprobar esta solicitud por separado."}
            token_hash = hashlib.sha256(approval_token.encode()).hexdigest()
            with self._lock:
                approved = self._approvals.pop(token_hash, None)
            if (approved is None or approved["expires_at"] < time.time() or
                    approved["name"] != name or approved["fingerprint"] != fingerprint):
                self._audit(call_id=call_id, tool=name, status="rejected_invalid_approval", arguments=arguments)
                raise ToolError("Aprobación inválida, vencida, reutilizada o no vinculada a estos argumentos.")
            call_id = approved["call_id"]
        elif approval_token:
            raise ToolError("No se acepta un token de aprobación para esta herramienta.")
        # Fail closed: persist an intent event before the side effect starts.
        self._audit(call_id=call_id, tool=name, status="execution_started", arguments=arguments,
                    details={"risk": spec.risk})
        started = time.monotonic()
        try:
            output = tool.handler(arguments)
        except Exception as exc:
            duration = round((time.monotonic() - started) * 1000)
            self._audit(call_id=call_id, tool=name, status="failed", arguments=arguments,
                        details={"error": type(exc).__name__, "duration_ms": duration})
            return {"status": "failed", "call_id": call_id, "tool": name, "error": type(exc).__name__, "message": str(exc)[:500]}
        duration = round((time.monotonic() - started) * 1000)
        self._audit(call_id=call_id, tool=name, status="completed", arguments=arguments,
                    details={"duration_ms": duration, "risk": spec.risk})
        return {"status": "completed", "call_id": call_id, "tool": name, "duration_ms": duration,
                "audit_status": "recorded" if self._audit_log is not None else "not_configured", "result": output}


class AgentOrchestrator:
    """Creates transparent specialist work plans; agents do not gain implicit tool access."""

    # Whole-word / prefix* matching (see planner.count_matches); substring matching
    # sent "capital" to software_engineering because it contains "api".
    SPECIALISTS = (
        ("cybersecurity", ("ciber*", "cyber*", "seguridad", "vulnerab*", "pentest*")),
        ("software_engineering", ("codigo", "programa", "programas", "software", "api", "apis", "bug", "bugs", "programar")),
        ("research", ("investig*", "fuentes", "comparar", "actualidad")),
        ("business_strategy", ("negocio*", "ventas", "marketing", "empresa*", "estrategia")),
        ("general_reasoning", ()),
    )

    def plan(self, objective: str, context: list[str] | None = None, constraints: list[str] | None = None) -> dict[str, Any]:
        if not isinstance(objective, str) or not objective.strip() or len(objective) > 12_000:
            raise ValueError("objective es obligatorio y debe tener hasta 12000 caracteres.")
        from .planner import count_matches, words
        tokens = words(objective)
        selected = [name for name, terms in self.SPECIALISTS if not terms or count_matches(tokens, terms)]
        # One lead specialist and one independent validation role.
        lead = selected[0]
        return {
            "plan_id": f"plan_{uuid4().hex[:16]}",
            "objective": objective.strip(),
            "status": "planned_not_executed",
            "orchestration": "central_supervisor",
            "agents": [
                {"id": "agent_lead", "specialty": lead, "role": "analizar y proponer"},
                {"id": "agent_validator", "specialty": "quality_and_risk", "role": "buscar omisiones, riesgos y criterios de verificación"},
            ],
            "steps": [
                {"order": 1, "owner": "agent_lead", "action": "descomponer el objetivo y establecer requisitos", "depends_on": []},
                {"order": 2, "owner": "agent_lead", "action": "desarrollar la solución y declarar incertidumbres", "depends_on": [1]},
                {"order": 3, "owner": "agent_validator", "action": "revisar riesgos, supuestos y criterios de aceptación", "depends_on": [2]},
                {"order": 4, "owner": "central_supervisor", "action": "integrar resultados y comprobar cumplimiento", "depends_on": [3]},
            ],
            "context": [x[:2000] for x in (context or [])[:20]],
            "constraints": [x[:2000] for x in (constraints or [])[:20]],
            "tool_access": "deny_by_default",
            "execution_requires": "registered_tool_and_policy_approval",
            "note": "Los agentes son roles lógicos coordinados; esta etapa no ejecuta agentes autónomos ni conecta servidores MCP externos.",
        }
