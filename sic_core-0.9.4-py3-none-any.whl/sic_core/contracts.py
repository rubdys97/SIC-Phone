from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


@dataclass(slots=True)
class AnalysisRequest:
    objective: str
    context: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    success_criteria: list[str] = field(default_factory=list)
    execution_mode: str = "supervised"

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "AnalysisRequest":
        if not isinstance(raw, dict):
            raise ValueError("El cuerpo debe ser un objeto JSON.")
        objective = raw.get("objective")
        if not isinstance(objective, str) or not objective.strip():
            raise ValueError("objective es obligatorio y debe ser texto.")
        if len(objective) > 12_000:
            raise ValueError("objective supera el límite de 12000 caracteres.")

        def string_list(name: str, limit: int = 20) -> list[str]:
            value = raw.get(name, [])
            if not isinstance(value, list) or len(value) > limit:
                raise ValueError(f"{name} debe ser una lista de hasta {limit} elementos.")
            if any(not isinstance(item, str) or len(item) > 2_000 for item in value):
                raise ValueError(f"Todos los elementos de {name} deben ser textos de hasta 2000 caracteres.")
            return [item.strip() for item in value if item.strip()]

        mode = raw.get("execution_mode", "supervised")
        if mode not in {"supervised", "bounded_autonomy"}:
            raise ValueError("execution_mode debe ser supervised o bounded_autonomy.")
        return cls(
            objective=objective.strip(),
            context=string_list("context"),
            constraints=string_list("constraints"),
            success_criteria=string_list("success_criteria"),
            execution_mode=mode,
        )


@dataclass(slots=True)
class AnalysisEnvelope:
    task_id: str
    created_at: str
    objective: str
    domain: str
    facts: list[str]
    assumptions: list[str]
    unknowns: list[str]
    constraints: list[str]
    success_criteria: list[str]
    execution_mode: str
    status: str = "prepared"
    reasoning_provider: str = "deterministic_preprocessor"
    reasoning_model: str | None = None
    analysis: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def new_task_id() -> str:
    return f"sic_{uuid4().hex[:16]}"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
