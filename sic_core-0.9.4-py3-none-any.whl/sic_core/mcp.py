from __future__ import annotations

import json
import os
import ipaddress
import re
import queue
import shutil
import subprocess
import signal
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4

from . import __version__
from .sandbox import MCPProcessSandbox, SandboxError

try:  # imported here, not inside preexec_fn: importing between fork and exec can deadlock
    import resource
except ImportError:  # non-POSIX
    resource = None  # type: ignore[assignment]

PROTOCOL_VERSION = "2025-11-25"
MAX_MESSAGE = 1_000_000
MAX_TOOLS = 200
_STDIO_AUTHORIZATION = object()


class MCPError(ValueError):
    pass


class _StableThreadSpawner:
    """Forks MCP subprocesses from one long-lived thread.

    bubblewrap's --die-with-parent is PR_SET_PDEATHSIG, which Linux ties to the *thread*
    that created the child, not to the process. SIC serves each HTTP request on a short-
    lived thread, so a server started inside POST /v1/mcp/connect was killed (SIGKILL) as
    soon as that request finished, and every later call failed with "El proceso MCP no está
    activo". Creating every child from this thread, which lives as long as the process,
    keeps the guarantee that sandboxed servers die with SIC without dying early.
    Serialising forks here also keeps preexec_fn from running concurrently.
    """

    def __init__(self) -> None:
        self._jobs: queue.Queue = queue.Queue()
        self._thread = threading.Thread(target=self._run, name="sic-mcp-spawner", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        while True:
            function, outcome, done = self._jobs.get()
            try:
                outcome.append((True, function()))
            except BaseException as exc:  # delivered to the caller
                outcome.append((False, exc))
            done.set()

    def run(self, function):
        outcome: list = []
        done = threading.Event()
        self._jobs.put((function, outcome, done))
        done.wait()
        succeeded, value = outcome[0]
        if succeeded:
            return value
        raise value


_SPAWNER: _StableThreadSpawner | None = None
_SPAWNER_LOCK = threading.Lock()


def _spawn(function):
    global _SPAWNER
    with _SPAWNER_LOCK:
        if _SPAWNER is None:
            _SPAWNER = _StableThreadSpawner()
    return _SPAWNER.run(function)


def _validate_endpoint(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"https", "http"} or not parsed.hostname:
        raise MCPError("El endpoint MCP debe ser una URL HTTP(S) válida.")
    if parsed.username or parsed.password:
        raise MCPError("No se permiten credenciales incrustadas en la URL.")
    if parsed.fragment:
        raise MCPError("La URL MCP no debe incluir fragmentos.")
    host = parsed.hostname.rstrip(".").lower()
    try:
        literal = ipaddress.ip_address(host.split("%", 1)[0])
        is_loopback = literal.is_loopback
    except ValueError:
        # Only the literal "localhost": names like "x.localhost" resolve to loopback only on
        # some resolvers and are sent to DNS on others, which would defeat the loopback rule.
        is_loopback = host == "localhost"
    if parsed.scheme == "http":
        if not is_loopback:
            raise MCPError("MCP HTTP sin TLS solo se permite en loopback.")
        return url
    if is_loopback:
        return url
    # Fail closed: urllib does not pin the validated DNS answer to the socket.
    # An allowlist plus a preflight lookup is not sufficient against DNS rebinding.
    raise MCPError("MCP HTTPS remoto deshabilitado: el cliente actual no fija la IP validada al socket y no puede neutralizar DNS rebinding. Usa loopback hasta implementar transporte con pinning.")


def _safe_json(data: bytes) -> Any:
    if len(data) > MAX_MESSAGE:
        raise MCPError("La respuesta MCP supera el límite de 1 MB.")
    try:
        return json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise MCPError("Respuesta JSON-RPC inválida.") from exc


@dataclass(slots=True)
class MCPServerConfig:
    name: str
    transport: str
    url: str | None = None
    command: str | None = None
    args: list[str] = field(default_factory=list)
    api_key: str | None = None
    timeout: float = 15.0


class _StdioSession:
    """One persistent MCP stdio subprocess; no shell and a minimal inherited environment."""
    def __init__(self, command: str, args: list[str], timeout: float, sandbox: MCPProcessSandbox | None = None):
        if not os.path.isabs(command) or not os.path.isfile(command):
            raise MCPError("El comando stdio debe ser una ruta absoluta a un ejecutable existente.")
        if not os.access(command, os.X_OK):
            raise MCPError("El comando stdio no tiene permiso de ejecución.")
        if len(args) > 32 or any(not isinstance(x, str) or len(x) > 8192 for x in args) or sum(len(x) for x in args) > 16_000:
            raise MCPError("Argumentos del proceso MCP no válidos.")
        self._workdir = tempfile.TemporaryDirectory(prefix="sic-mcp-")
        self._sandbox = sandbox or MCPProcessSandbox()
        available, reason = self._sandbox.available()
        if not available:
            self._workdir.cleanup()
            raise MCPError(f"MCP stdio bloqueado: {reason}")
        try:
            launch_command = self._sandbox.command(command, args, self._workdir.name)
        except SandboxError as exc:
            self._workdir.cleanup()
            raise MCPError(str(exc)) from exc
        env = {}
        def apply_limits():
            # Linux backend only: inability to apply a limit must abort process launch.
            resource.setrlimit(resource.RLIMIT_CPU, (30, 31))
            memory = 512 * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
            resource.setrlimit(resource.RLIMIT_FSIZE, (10 * 1024 * 1024, 10 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        self.proc = _spawn(lambda: subprocess.Popen(
            launch_command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, shell=False, close_fds=True, env=env,
            cwd=self._workdir.name, bufsize=0,
            start_new_session=(os.name == "posix"),
            preexec_fn=apply_limits if os.name == "posix" else None,
        ))
        self.timeout = timeout
        self._queue: queue.Queue[bytes | BaseException] = queue.Queue(maxsize=128)
        self._lock = threading.Lock()
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()

    def _read_loop(self) -> None:
        try:
            assert self.proc.stdout is not None
            while True:
                line = self.proc.stdout.readline(MAX_MESSAGE + 1)
                if not line:
                    raise MCPError("El servidor MCP cerró stdout.")
                if len(line) > MAX_MESSAGE:
                    raise MCPError("Mensaje MCP stdio demasiado grande.")
                try:
                    self._queue.put(line, timeout=1.0)
                except queue.Full:
                    self._terminate_group()
                    return
        except BaseException as exc:
            try:
                self._queue.put(exc, timeout=1.0)
            except queue.Full:
                pass

    def request(self, message: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            if self.proc.poll() is not None:
                raise MCPError("El proceso MCP no está activo.")
            assert self.proc.stdin is not None
            self.proc.stdin.write(json.dumps(message, separators=(",", ":")).encode() + b"\n")
            self.proc.stdin.flush()
            deadline = time.monotonic() + self.timeout
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._terminate_group()
                    raise MCPError("Tiempo de espera agotado en MCP stdio; proceso terminado.")
                try:
                    item = self._queue.get(timeout=remaining)
                except queue.Empty as exc:
                    self._terminate_group()
                    raise MCPError("Tiempo de espera agotado en MCP stdio; proceso terminado.") from exc
                if isinstance(item, BaseException):
                    raise MCPError(str(item))
                response = _safe_json(item.strip())
                if isinstance(response, dict) and response.get("id") == message.get("id"):
                    return response
                # Notifications and unrelated messages are ignored; no server-initiated
                # requests are executed by SIC in this release.

    def _terminate_group(self) -> None:
        if os.name == "posix":
            try:
                # Kill the complete process group even if the bubblewrap leader exited.
                os.killpg(self.proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        elif self.proc.poll() is None:
            self.proc.kill()
        try:
            self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass

    def notify(self, message: dict[str, Any]) -> None:
        with self._lock:
            if self.proc.poll() is not None:
                raise MCPError("El proceso MCP no está activo.")
            assert self.proc.stdin is not None
            self.proc.stdin.write(json.dumps(message, separators=(",", ":")).encode() + b"\n")
            self.proc.stdin.flush()

    def close(self) -> None:
        self._terminate_group()
        self._reader.join(timeout=2)  # the reader exits once the killed process closes stdout
        for pipe in (self.proc.stdin, self.proc.stdout):
            try:
                if pipe is not None:
                    pipe.close()
            except OSError:
                pass
        self._workdir.cleanup()


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class MCPClient:
    def __init__(self, config: MCPServerConfig, *, _stdio_authorization: object | None = None,
                 _sandbox: MCPProcessSandbox | None = None):
        self.config = config
        self._sandbox = _sandbox
        if config.timeout < 1 or config.timeout > 60:
            raise MCPError("timeout debe estar entre 1 y 60 segundos.")
        if config.transport not in {"stdio", "streamable_http"}:
            raise MCPError("Transporte MCP no admitido.")
        self.session_id: str | None = None
        self.protocol_version = PROTOCOL_VERSION
        self._initialized = False
        self._stdio: _StdioSession | None = None
        self._next_id = 0
        self._lock = threading.Lock()
        self.server_info: dict[str, Any] = {}
        if config.transport == "streamable_http":
            if not config.url:
                raise MCPError("Falta URL MCP.")
            _validate_endpoint(config.url)
        else:
            if not config.command:
                raise MCPError("Falta comando MCP stdio.")
            if not os.path.isabs(config.command) or not os.path.isfile(config.command) or not os.access(config.command, os.X_OK):
                raise MCPError("El comando stdio debe ser una ruta absoluta a un ejecutable existente y ejecutable.")
            if len(config.args) > 32 or any(not isinstance(x, str) or len(x) > 8192 for x in config.args) or sum(len(x) for x in config.args) > 16_000:
                raise MCPError("Argumentos del proceso MCP no válidos.")
            if _stdio_authorization is not _STDIO_AUTHORIZATION:
                raise MCPError("MCP stdio solo puede crearse mediante MCPManager con allowlist y sandbox verificado.")

    def _id(self) -> int:
        self._next_id += 1
        return self._next_id

    def _http(self, message: dict[str, Any], *, initializing: bool = False) -> dict[str, Any]:
        assert self.config.url
        headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        if not initializing:
            headers["MCP-Protocol-Version"] = self.protocol_version
            if self.session_id:
                headers["MCP-Session-Id"] = self.session_id
        request = urllib.request.Request(self.config.url, data=json.dumps(message).encode(), headers=headers, method="POST")
        try:
            opener = urllib.request.build_opener(urllib.request.HTTPHandler(), urllib.request.HTTPSHandler(),
                                                 urllib.request.ProxyHandler({}), _NoRedirect())
            with opener.open(request, timeout=self.config.timeout) as response:
                self.session_id = response.headers.get("MCP-Session-Id", self.session_id)
                content_type = response.headers.get("Content-Type", "")
                raw = response.read(MAX_MESSAGE + 1)
        except urllib.error.HTTPError as exc:
            body = exc.read(4096).decode("utf-8", "replace")
            raise MCPError(f"MCP HTTP {exc.code}: {body[:500]}") from exc
        except Exception as exc:
            raise MCPError(f"No se pudo conectar al servidor MCP: {type(exc).__name__}") from exc
        if not raw:
            return {}
        if "text/event-stream" in content_type:
            events = []
            # SSE allows CRLF and bare CR line endings. Splitting on "\n\n" alone never split
            # events from servers that send "\r\n\r\n", so a progress notification followed
            # by the result was merged into one invalid JSON payload.
            text = raw.decode("utf-8", "replace").replace("\r\n", "\n").replace("\r", "\n")
            for block in text.split("\n\n"):
                data = "\n".join(line[5:].lstrip() for line in block.splitlines() if line.startswith("data:"))
                if data:
                    events.append(_safe_json(data.encode()))
            for event in events:
                if isinstance(event, dict) and event.get("id") == message.get("id"):
                    return event
            raise MCPError("El flujo SSE MCP no devolvió la respuesta solicitada.")
        response_obj = _safe_json(raw)
        if not isinstance(response_obj, dict):
            raise MCPError("Respuesta MCP inesperada.")
        return response_obj

    def _rpc(self, method: str, params: dict[str, Any] | None = None, *, initializing: bool = False) -> dict[str, Any]:
        with self._lock:  # ids and the HTTP session state are per-client, not thread-safe
            message = {"jsonrpc": "2.0", "id": self._id(), "method": method, "params": params or {}}
            if self.config.transport == "stdio":
                assert self._stdio is not None
                response = self._stdio.request(message)
            else:
                response = self._http(message, initializing=initializing)
        if response.get("error"):
            err = response["error"]
            raise MCPError(f"MCP {err.get('code', 'error')}: {str(err.get('message', 'error'))[:400]}")
        if response.get("id") != message["id"] or "result" not in response:
            raise MCPError("Respuesta JSON-RPC MCP no coincide con la solicitud.")
        return response["result"]

    def connect(self) -> dict[str, Any]:
        if self.config.transport == "stdio":
            assert self.config.command
            self._stdio = _StdioSession(self.config.command, self.config.args, self.config.timeout, self._sandbox)
        result = self._rpc("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "SIC Core", "version": __version__},
        }, initializing=True)
        negotiated = result.get("protocolVersion")
        if negotiated not in {PROTOCOL_VERSION, "2025-06-18", "2025-03-26"}:
            self.close()
            raise MCPError(f"Versión MCP no compatible: {negotiated}")
        self.protocol_version = negotiated
        self._initialized = True
        self.server_info = result.get("serverInfo", {}) if isinstance(result.get("serverInfo", {}), dict) else {}
        notification = {"jsonrpc": "2.0", "method": "notifications/initialized"}
        if self.config.transport == "stdio":
            assert self._stdio is not None
            self._stdio.notify(notification)
        else:
            self._http(notification)
        return {"connected": True, "protocol_version": negotiated, "server_info": self.server_info}

    def list_tools(self) -> list[dict[str, Any]]:
        result = self._rpc("tools/list")
        tools = result.get("tools", [])
        if not isinstance(tools, list) or len(tools) > MAX_TOOLS:
            raise MCPError("Catálogo de herramientas MCP no válido o demasiado grande.")
        clean = []
        for item in tools:
            if not isinstance(item, dict) or not isinstance(item.get("name"), str):
                continue
            schema = item.get("inputSchema", {"type": "object"})
            if not isinstance(schema, dict) or schema.get("type") != "object":
                schema = {"type": "object"}
            if len(json.dumps(schema, ensure_ascii=False).encode()) > 16_000:
                schema = {"type": "object"}
            clean.append({"name": item["name"][:100], "description": str(item.get("description", ""))[:1000], "input_schema": schema})
        return clean

    def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(arguments, dict) or len(json.dumps(arguments, ensure_ascii=False)) > 16_000:
            raise MCPError("Argumentos MCP no válidos o demasiado grandes.")
        result = self._rpc("tools/call", {"name": name, "arguments": arguments})
        if result.get("isError") is True:
            raise MCPError("El servidor MCP indicó que la herramienta falló.")
        encoded = json.dumps(result, ensure_ascii=False)
        if len(encoded.encode()) > 64_000:
            raise MCPError("Resultado MCP supera 64 KB.")
        return result

    def close(self) -> None:
        if self._stdio:
            self._stdio.close()
            self._stdio = None


_MAX_PATTERN_INPUT = 512


def _pattern_is_safe(pattern: Any) -> bool:
    """Conservative guard against catastrophic backtracking.

    Schemas come from remote MCP servers, so a `pattern` such as (a+)+$ would let that
    server pin a SIC worker thread (Python's re has no timeout). Accepted patterns have
    no quantified groups, backreferences or lookaround, and few quantifiers; the checked
    string is also length-capped (_MAX_PATTERN_INPUT) to bound polynomial blow-up.
    """
    if not isinstance(pattern, str) or len(pattern) > 200:
        return False
    try:
        re.compile(pattern)
    except re.error:
        return False
    if re.search(r"\\[1-9]|\(\?[=!<P]", pattern):
        return False
    flat = re.sub(r"\\.", "E", pattern)                 # escapes -> one atom
    flat = re.sub(r"\[\^?\]?[^\]]*\]", "C", flat)       # character classes -> one atom
    if re.search(r"\)[*+{]", flat):                       # quantified group
        return False
    if len(re.findall(r"[*+?]|\{[^}]*\}", flat)) > 8:
        return False
    return len(re.findall(r"[*+]|\{\d+,\}", flat)) <= 3


def find_unsafe_pattern(schema: Any) -> str | None:
    """First `pattern` in a JSON Schema (walking only schema-valued keywords) that is not safe."""
    stack: list[Any] = [schema]
    visited = 0
    while stack:
        node = stack.pop()
        visited += 1
        if visited > 4096 or not isinstance(node, dict):
            continue
        if "pattern" in node and not _pattern_is_safe(node["pattern"]):
            return str(node["pattern"])[:200]
        props = node.get("properties")
        if isinstance(props, dict):
            stack.extend(props.values())
        for key in ("items", "additionalProperties"):
            if isinstance(node.get(key), dict):
                stack.append(node[key])
        for key in ("allOf", "anyOf", "oneOf"):
            if isinstance(node.get(key), list):
                stack.extend(node[key])
    return None


def _validate_arguments(schema: dict[str, Any], arguments: dict[str, Any]) -> None:
    """Bounded recursive validator for the JSON Schema subset SIC accepts."""
    if not isinstance(schema, dict) or not isinstance(arguments, dict):
        raise MCPError("El esquema o los argumentos MCP no son válidos.")
    visited = 0
    type_map = {"string": str, "integer": int, "number": (int, float), "boolean": bool,
                "object": dict, "array": list, "null": type(None)}

    def check(rule: dict[str, Any], value: Any, path: str, depth: int) -> None:
        nonlocal visited
        visited += 1
        if visited > 2048 or depth > 16:
            raise MCPError("El esquema o los argumentos exceden la complejidad permitida.")
        if not isinstance(rule, dict):
            raise MCPError("Definición JSON Schema inválida.")
        expected = rule.get("type")
        if isinstance(expected, list):
            if not any(_matches_type(item, value, type_map) for item in expected):
                raise MCPError(f"Tipo incorrecto en {path}.")
        elif expected and not _matches_type(expected, value, type_map):
            raise MCPError(f"Tipo incorrecto en {path}.")
        if "enum" in rule and value not in rule["enum"]:
            raise MCPError(f"Valor fuera de enum en {path}.")
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if "minimum" in rule and value < rule["minimum"]: raise MCPError(f"Valor menor que minimum en {path}.")
            if "maximum" in rule and value > rule["maximum"]: raise MCPError(f"Valor mayor que maximum en {path}.")
            if "exclusiveMinimum" in rule and value <= rule["exclusiveMinimum"]: raise MCPError(f"Valor no supera exclusiveMinimum en {path}.")
            if "exclusiveMaximum" in rule and value >= rule["exclusiveMaximum"]: raise MCPError(f"Valor no alcanza exclusiveMaximum en {path}.")
        if isinstance(value, str):
            if len(value) < rule.get("minLength", 0) or len(value) > rule.get("maxLength", 16000):
                raise MCPError(f"Longitud no permitida en {path}.")
            if "pattern" in rule:
                if not _pattern_is_safe(rule["pattern"]):
                    raise MCPError(f"Patrón del esquema no admitido por seguridad en {path}.")
                if len(value) > _MAX_PATTERN_INPUT:
                    raise MCPError(f"Texto demasiado largo para validar contra pattern en {path}.")
                if not re.search(rule["pattern"], value):
                    raise MCPError(f"Formato no permitido en {path}.")
        if isinstance(value, list):
            if len(value) < rule.get("minItems", 0) or len(value) > rule.get("maxItems", 256):
                raise MCPError(f"Cantidad de elementos no permitida en {path}.")
            if rule.get("uniqueItems") and len({json.dumps(x, sort_keys=True) for x in value}) != len(value):
                raise MCPError(f"Elementos duplicados en {path}.")
            if isinstance(rule.get("items"), dict):
                for index, item in enumerate(value): check(rule["items"], item, f"{path}[{index}]", depth + 1)
        if isinstance(value, dict):
            props = rule.get("properties", {})
            required = rule.get("required", [])
            if not isinstance(props, dict) or not isinstance(required, list):
                raise MCPError("Propiedades o requeridos inválidos en JSON Schema.")
            missing = [key for key in required if key not in value]
            if missing: raise MCPError("Faltan argumentos requeridos: " + ", ".join(map(str, missing[:20])))
            if len(value) > 256: raise MCPError(f"Demasiadas propiedades en {path}.")
            for key, item in value.items():
                if key in props: check(props[key], item, f"{path}.{key}", depth + 1)
                elif rule.get("additionalProperties", True) is False:
                    raise MCPError(f"Propiedad no declarada en {path}: {key}")
                elif isinstance(rule.get("additionalProperties"), dict):
                    check(rule["additionalProperties"], item, f"{path}.{key}", depth + 1)
        for keyword in ("allOf", "anyOf", "oneOf"):
            if keyword in rule:
                choices = rule[keyword]
                if not isinstance(choices, list) or len(choices) > 32:
                    raise MCPError(f"Composición JSON Schema inválida en {path}.")
                outcomes = []
                for subrule in choices:
                    try: check(subrule, value, path, depth + 1); outcomes.append(True)
                    except MCPError: outcomes.append(False)
                passed = sum(outcomes)
                if (keyword == "allOf" and passed != len(choices)) or (keyword == "anyOf" and passed < 1) or (keyword == "oneOf" and passed != 1):
                    raise MCPError(f"Restricción {keyword} incumplida en {path}.")

    check(schema, arguments, "$", 0)

def _matches_type(expected: Any, value: Any, type_map: dict[str, Any]) -> bool:
    python_type = type_map.get(expected) if isinstance(expected, str) else None
    if python_type is None: return False
    if expected in {"integer", "number"} and isinstance(value, bool): return False
    return isinstance(value, python_type) and (expected != "integer" or value % 1 == 0)


class MCPManager:
    """Connections and discovery only; remote tools remain inert until explicit allowlisting."""
    def __init__(self, stdio_allowlist: list[str] | None = None, extra_ro_binds: list[str] | None = None):
        self._stdio_allowlist = {os.path.realpath(path) for path in (stdio_allowlist or []) if path}
        self._clients: dict[str, MCPClient] = {}
        self._catalogs: dict[str, list[dict[str, Any]]] = {}
        self._connecting: set[str] = set()
        self._lock = threading.RLock()
        self._stdio_sandbox = MCPProcessSandbox(extra_ro_binds=extra_ro_binds or ())
        self._stdio_sandbox_status = self._stdio_sandbox.available()

    @property
    def extra_ro_bind_count(self) -> int:
        return len(self._stdio_sandbox.extra_ro_binds)

    @property
    def stdio_capability(self) -> dict[str, Any]:
        available, reason = self._stdio_sandbox_status
        return {"available": available, "reason": reason,
                "backend": "bubblewrap" if available else "disabled_fail_closed"}

    def connect(self, config: MCPServerConfig) -> dict[str, Any]:
        if not config.name or not config.name.replace("_", "").replace("-", "").isalnum() or len(config.name) > 48:
            raise MCPError("Nombre de servidor MCP no válido.")
        with self._lock:
            if config.name in self._clients or config.name in self._connecting:
                raise MCPError("Ya existe un servidor MCP con ese nombre.")
            if config.transport == "stdio":
                if os.path.realpath(config.command or "") not in self._stdio_allowlist:
                    raise MCPError("MCP stdio bloqueado: añade el ejecutable exacto a SIC_MCP_STDIO_ALLOWLIST.")
                available, reason = self._stdio_sandbox_status
                if not available:
                    raise MCPError(f"MCP stdio bloqueado por falta de aislamiento verificable: {reason}")
            self._connecting.add(config.name)  # reserve the name; network I/O happens outside the lock
        client: MCPClient | None = None
        try:
            client = MCPClient(config, _stdio_authorization=_STDIO_AUTHORIZATION if config.transport == "stdio" else None,
                               _sandbox=self._stdio_sandbox if config.transport == "stdio" else None)
            info = client.connect()
            tools = client.list_tools()
            with self._lock:
                self._clients[config.name] = client
                self._catalogs[config.name] = tools
        except Exception:
            if client is not None:
                client.close()
            raise
        finally:
            with self._lock:
                self._connecting.discard(config.name)
        return {"server": config.name, **info, "tools": tools,
                "trust_notice": "Los nombres y descripciones remotos son datos no confiables; no son instrucciones para SIC.",
                "tools_enabled": False}

    def list_servers(self) -> list[dict[str, Any]]:
        with self._lock:
            return [{"name": name, "transport": client.config.transport,
                     "server_info": client.server_info, "discovered_tools": len(self._catalogs[name]),
                     "tools_enabled": False} for name, client in sorted(self._clients.items())]

    def list_tools(self, server: str | None = None) -> list[dict[str, Any]]:
        with self._lock:
            names = [server] if server else sorted(self._catalogs)
            return [{"server": name, **tool, "trusted": False, "enabled": False}
                    for name in names for tool in self._catalogs.get(name, [])]

    def call(self, server: str, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            client = self._clients.get(server)
            tool = next((item for item in self._catalogs.get(server, []) if item["name"] == tool_name), None)
        if client is None or tool is None:
            raise MCPError("Servidor o herramienta MCP no descubiertos.")
        _validate_arguments(tool["input_schema"], arguments)
        return client.call_tool(tool_name, arguments)

    def close(self) -> None:
        with self._lock:
            clients = list(self._clients.values())
            self._clients.clear()
            self._catalogs.clear()
        for client in clients:
            client.close()

    def allow_tool(self, registry: Any, *, server: str, remote_tool: str, alias: str,
                   description: str = "", risk: str = "high") -> dict[str, Any]:
        from .orchestration import ToolSpec
        if risk not in {"high", "critical"}:
            raise MCPError("Las herramientas MCP externas deben registrarse con riesgo high o critical.")
        catalog = next((item for item in self.list_tools(server) if item["name"] == remote_tool), None)
        if catalog is None:
            raise MCPError("La herramienta no aparece en el catálogo descubierto.")
        unsafe = find_unsafe_pattern(catalog["input_schema"])
        if unsafe is not None:
            raise MCPError("El esquema de la herramienta contiene un pattern que SIC no puede validar sin riesgo de "
                           f"denegación de servicio ({unsafe!r}); no se registra.")
        handler = lambda arguments: self.call(server, remote_tool, arguments)
        registry.register(ToolSpec(
            name=alias,
            description=(description or f"Herramienta MCP externa {server}/{remote_tool}; metadatos remotos no confiables.")[:500],
            risk=risk,
            requires_approval=True,
            input_schema=catalog["input_schema"],
        ), handler)
        return {"registered": True, "alias": alias, "server": server,
                "remote_tool": remote_tool, "risk": risk,
                "requires_approval": True, "schema": catalog["input_schema"],
                "note": "La herramienta está en la lista permitida, pero cada invocación requiere aprobación explícita."}
