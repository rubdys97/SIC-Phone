from __future__ import annotations

import json
import os
import signal
import subprocess
import shutil
import sys
import tempfile
import time
from dataclasses import dataclass
from typing import Any


class SandboxError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class SandboxLimits:
    timeout_seconds: float = 10.0
    memory_mb: int = 256
    cpu_seconds: int = 5
    output_bytes: int = 64_000
    file_bytes: int = 1_000_000

    def validate(self) -> None:
        if not 1 <= self.timeout_seconds <= 60:
            raise SandboxError("timeout_seconds debe estar entre 1 y 60.")
        if not 32 <= self.memory_mb <= 2048:
            raise SandboxError("memory_mb debe estar entre 32 y 2048.")
        if not 1 <= self.cpu_seconds <= 60:
            raise SandboxError("cpu_seconds debe estar entre 1 y 60.")
        if not 1024 <= self.output_bytes <= 1_000_000:
            raise SandboxError("output_bytes fuera del rango permitido.")
        if not 1024 <= self.file_bytes <= 10_000_000:
            raise SandboxError("file_bytes fuera del rango permitido.")


class ProcessSandbox:
    """Runs only exact allowlisted executables, without a shell, in a temp cwd.

    POSIX resource limits are applied where available. This is defense in depth,
    not a network namespace/container/VM: use OS-level isolation for hostile code.
    """
    def __init__(self, executable_allowlist: list[str] | None = None):
        self.allowlist = {os.path.realpath(x) for x in (executable_allowlist or []) if x}

    def run(self, executable: str, args: list[str], payload: dict[str, Any] | None = None,
            limits: SandboxLimits | None = None) -> dict[str, Any]:
        limits = limits or SandboxLimits()
        limits.validate()
        if not isinstance(executable, str) or not os.path.isabs(executable):
            raise SandboxError("El ejecutable debe ser una ruta absoluta.")
        resolved = os.path.realpath(executable)
        if resolved not in self.allowlist:
            raise SandboxError("Ejecutable no autorizado por la lista de confianza.")
        if not os.path.isfile(resolved) or not os.access(resolved, os.X_OK):
            raise SandboxError("El ejecutable no existe o no tiene permiso de ejecución.")
        if not isinstance(args, list) or len(args) > 32 or any(not isinstance(x, str) or len(x) > 4096 for x in args):
            raise SandboxError("Argumentos inválidos.")
        if sum(map(len, args)) > 12_000:
            raise SandboxError("Argumentos demasiado grandes.")
        if payload is not None and (not isinstance(payload, dict) or len(json.dumps(payload).encode()) > 32_000):
            raise SandboxError("Entrada JSON inválida o demasiado grande.")

        def limits_preexec():
            try:
                import resource
                resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_seconds, limits.cpu_seconds + 1))
                memory = limits.memory_mb * 1024 * 1024
                if hasattr(resource, "RLIMIT_AS"):
                    resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
                resource.setrlimit(resource.RLIMIT_FSIZE, (limits.file_bytes, limits.file_bytes))
                resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))
            except (ImportError, AttributeError, OSError, ValueError):
                pass

        env = {k: v for k, v in os.environ.items() if k in {"PATH", "LANG", "LC_ALL", "SYSTEMROOT", "WINDIR", "TEMP", "TMP"}}
        stdin = json.dumps(payload or {}, ensure_ascii=False).encode()
        with tempfile.TemporaryDirectory(prefix="sic-sandbox-") as cwd:
            started = time.monotonic()
            with tempfile.TemporaryFile() as stdout_file, tempfile.TemporaryFile() as stderr_file:
                proc = subprocess.Popen([resolved, *args], stdin=subprocess.PIPE, stdout=stdout_file,
                                        stderr=stderr_file, cwd=cwd, env=env, shell=False,
                                        close_fds=True, start_new_session=(os.name == "posix"),
                                        preexec_fn=limits_preexec if os.name == "posix" else None)
                try:
                    proc.communicate(stdin, timeout=limits.timeout_seconds)
                except subprocess.TimeoutExpired:
                    if os.name == "posix":
                        try:
                            os.killpg(proc.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    else:
                        proc.kill()
                    proc.communicate()
                    raise SandboxError("Proceso terminado por exceder el tiempo máximo.")
                stdout_file.seek(0, os.SEEK_END)
                stdout_size = stdout_file.tell()
                stderr_file.seek(0, os.SEEK_END)
                stderr_size = stderr_file.tell()
                if stdout_size > limits.output_bytes or stderr_size > limits.output_bytes:
                    raise SandboxError("Salida del proceso supera el límite permitido.")
                stdout_file.seek(0)
                stderr_file.seek(0)
                stdout = stdout_file.read(limits.output_bytes + 1)
                stderr = stderr_file.read(limits.output_bytes + 1)
            return {"return_code": proc.returncode, "stdout": stdout.decode("utf-8", "replace"),
                    "stderr": stderr.decode("utf-8", "replace"),
                    "duration_ms": round((time.monotonic() - started) * 1000),
                    "isolation": "temp_cwd+allowlist+resource_limits_best_effort",
                    "network_isolation": False}


_WORKDIR_IN_SANDBOX = "/tmp/sic-mcp"
_SENSITIVE_HOME_DIRS = (".sic", ".ssh", ".gnupg", ".aws", ".kube", ".docker")


def _within(path: str, root: str) -> bool:
    try:
        return os.path.commonpath([path, root]) == root
    except ValueError:
        return False


def parse_extra_ro_binds(paths: list[str] | tuple[str, ...]) -> tuple[str, ...]:
    """Validate operator-supplied read-only mounts for the MCP sandbox.

    Without these, a stdio MCP server can only run code that lives under /usr (or an
    inline `-c` program). Extra roots are read-only, come only from operator
    configuration (never from the API), and must not expose the home directory,
    credential directories, the SIC databases, or kernel/device filesystems.
    """
    home = os.path.realpath(os.path.expanduser("~"))
    protected = [os.path.realpath(os.path.expanduser(os.getenv(name, default)))
                 for name, default in (("SIC_DB_PATH", "~/.sic/sic_memory.sqlite3"),
                                       ("SIC_AUDIT_DB_PATH", "~/.sic/audit.sqlite3"))]
    result: list[str] = []
    for raw in paths:
        if not raw:
            continue
        if not os.path.isabs(raw):
            raise SandboxError(f"El bind de solo lectura debe ser una ruta absoluta: {raw!r}")
        real = os.path.realpath(raw)
        if not os.path.isdir(real):
            raise SandboxError(f"El bind de solo lectura no es un directorio existente: {raw!r}")
        if _within(real, "/usr"):
            continue  # already visible
        if real == "/" or _within(_WORKDIR_IN_SANDBOX, real) or any(_within(real, r) or _within(r, real) for r in ("/proc", "/sys", "/dev")):
            raise SandboxError(f"Bind de solo lectura no permitido: {real}")
        if _within(home, real):
            raise SandboxError(f"Bind de solo lectura no permitido: expondría el directorio personal ({real}).")
        if any(_within(real, os.path.join(home, name)) for name in _SENSITIVE_HOME_DIRS):
            raise SandboxError(f"Bind de solo lectura no permitido: directorio de credenciales o datos de SIC ({real}).")
        if any(_within(db, real) for db in protected):
            raise SandboxError(f"Bind de solo lectura no permitido: contiene una base de datos de SIC ({real}).")
        result.append(real)
    return tuple(dict.fromkeys(result))


class MCPProcessSandbox:
    """Linux MCP stdio launcher using bubblewrap namespaces; fail closed elsewhere.

    This backend is deliberately Linux-only. It mounts the system runtime read-only,
    exposes only a private writable work directory, and disables networking and
    namespace access. A successful capability probe is required before launch.
    Operator-approved extra read-only roots (see parse_extra_ro_binds) let the server
    executable and its files live outside /usr.
    """
    def __init__(self, bwrap_path: str | None = None, extra_ro_binds: list[str] | tuple[str, ...] = ()):
        self.bwrap_path = bwrap_path or shutil.which("bwrap")
        self.extra_ro_binds = parse_extra_ro_binds(extra_ro_binds)

    @staticmethod
    def _mount_args() -> list[str]:
        args: list[str] = []
        if not os.path.isdir("/usr"):
            raise SandboxError("No existe /usr; no se puede preparar el runtime aislado.")
        args += ["--ro-bind", "/usr", "/usr"]
        for path in ("/bin", "/sbin", "/lib", "/lib64"):
            if os.path.exists(path):
                args += ["--ro-bind-try", path, path]
        return args

    def command(self, executable: str, args: list[str], workdir: str) -> list[str]:
        if os.name != "posix" or not sys.platform.startswith("linux"):
            raise SandboxError("MCP stdio aislado solo está implementado para Linux con bubblewrap.")
        if not self.bwrap_path or not os.path.isfile(self.bwrap_path) or not os.access(self.bwrap_path, os.X_OK):
            raise SandboxError("MCP stdio bloqueado: bubblewrap no está instalado.")
        if not os.path.isabs(executable) or not os.path.isfile(executable) or not os.access(executable, os.X_OK):
            raise SandboxError("El ejecutable MCP debe ser una ruta absoluta válida.")
        resolved_executable = os.path.realpath(executable)
        visible_roots = ("/usr", *self.extra_ro_binds)
        if not any(_within(resolved_executable, root) for root in visible_roots):
            raise SandboxError("El ejecutable MCP debe residir dentro de /usr o de un bind de solo lectura configurado "
                               "(SIC_MCP_RO_BINDS); esos son los únicos árboles visibles dentro del sandbox.")
        if not os.path.isdir(workdir):
            raise SandboxError("Directorio de trabajo MCP inválido.")
        command = [self.bwrap_path, "--die-with-parent", "--new-session", "--unshare-all"]
        command += self._mount_args()
        command += ["--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp"]
        # After --tmpfs /tmp so a bind located under /tmp is not hidden by it.
        for root in self.extra_ro_binds:
            command += ["--ro-bind", root, root]
        command += ["--dir", "/tmp/sic-mcp", "--bind", workdir, "/tmp/sic-mcp",
                    "--chdir", "/tmp/sic-mcp", "--clearenv",
                    "--setenv", "PATH", "/usr/bin:/bin",
                    "--setenv", "HOME", "/tmp/sic-mcp",
                    "--setenv", "LANG", "C.UTF-8", "--", resolved_executable, *args]
        return command

    def available(self) -> tuple[bool, str]:
        if os.name != "posix" or not sys.platform.startswith("linux"):
            return False, "MCP stdio aislado solo está implementado para Linux."
        if not self.bwrap_path:
            return False, "bubblewrap no está instalado."
        try:
            probe = [self.bwrap_path, "--die-with-parent", "--new-session", "--unshare-all"]
            probe += self._mount_args()
            probe += ["--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp", "--", "/usr/bin/true"]
            result = subprocess.run(probe, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL, timeout=5, check=False, close_fds=True)
            if result.returncode != 0:
                return False, "bubblewrap no pudo crear namespaces aislados en este host."
            return True, "linux_bubblewrap_namespaces_network_disabled_readonly_runtime"
        except (OSError, subprocess.TimeoutExpired, SandboxError):
            return False, "No se pudo verificar la capacidad de aislamiento bubblewrap."

