from __future__ import annotations

import hmac
import json
import logging
import os
import threading
import time
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

from . import __version__
from .provider import ProviderConfig, ProviderError, env_int
from .embeddings import EmbeddingConfig
from .memory import MemoryStore
from .service import SICService
from .orchestration import AgentOrchestrator, ToolRegistry, ToolError
from .mcp import MCPManager, MCPServerConfig, MCPError
from .audit import AuditLog

LOG = logging.getLogger("sic")
MAX_BODY = 64 * 1024
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})


def _host_header_name(value: str) -> str:
    """Hostname part of a Host header (port and IPv6 brackets removed, lowercased)."""
    value = value.strip().lower()
    if value.startswith("["):
        end = value.find("]")
        return value[1:end] if end != -1 else value
    return value.rsplit(":", 1)[0] if value.count(":") == 1 else value


class _TokenBucketLimiter:
    """Bounded per-client token bucket; safe for ThreadingHTTPServer workers."""
    def __init__(self, rate_per_minute: int = 120, burst: int = 30, max_clients: int = 10_000):
        if rate_per_minute < 1 or burst < 1 or max_clients < 1:
            raise ValueError("Los límites de tasa deben ser enteros positivos.")
        self.rate = rate_per_minute / 60.0
        self.capacity = float(burst)
        self.max_clients = max_clients
        self._buckets: OrderedDict[str, tuple[float, float]] = OrderedDict()
        self._lock = threading.Lock()

    def allow(self, key: str, now: float | None = None) -> tuple[bool, int]:
        now = time.monotonic() if now is None else now
        with self._lock:
            previous = self._buckets.pop(key, None)
            tokens, updated = previous if previous else (self.capacity, now)
            tokens = min(self.capacity, tokens + max(0.0, now - updated) * self.rate)
            if tokens >= 1.0:
                tokens -= 1.0
                allowed, retry = True, 0
            else:
                allowed = False
                retry = max(1, int((1.0 - tokens) / self.rate + 0.999))
            self._buckets[key] = (tokens, now)
            while len(self._buckets) > self.max_clients:
                self._buckets.popitem(last=False)
            return allowed, retry


class SICHandler(BaseHTTPRequestHandler):
    server_version = f"SIC/{__version__}"
    # Without a socket timeout a client that opens a connection and stalls holds a
    # worker thread forever (slowloris).
    timeout = 30

    def log_message(self, fmt: str, *args) -> None:
        LOG.info("%s - %s", self.address_string(), fmt % args)

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.end_headers()
        self.wfile.write(body)

    def _host_rejected(self) -> bool:
        """Reject requests whose Host header is not ours (DNS-rebinding defence).

        A web page can make the victim's browser talk to http://127.0.0.1:8765 by
        pointing an attacker-controlled name at loopback. Without a token that would hand
        the page the memory store, so on loopback binds only loopback names are accepted
        (plus SIC_ALLOWED_HOSTS). Remote binds are protected by tokens and the TLS proxy;
        for them the check applies only when SIC_ALLOWED_HOSTS is set.
        """
        configured = {h.strip().lower() for h in os.getenv("SIC_ALLOWED_HOSTS", "").split(",") if h.strip()}
        if os.getenv("SIC_HOST", "127.0.0.1") not in _LOOPBACK_HOSTS and not configured:
            return False
        supplied = self.headers.get("Host", "")
        if not supplied or _host_header_name(supplied) in (_LOOPBACK_HOSTS | configured):
            return False
        self._json(403, {"error": "host_not_allowed",
                         "message": "Cabecera Host no permitida. Añádela a SIC_ALLOWED_HOSTS si es legítima."})
        return True

    def _json_content_type(self) -> bool:
        # Requiring application/json forces browsers to send a CORS preflight, which this
        # server never approves; text/plain "simple" cross-site POSTs are refused (CSRF).
        return self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() == "application/json"

    def _rate_limited(self) -> bool:
        limiter = getattr(self.server, "rate_limiter", None)
        if limiter is None or urlparse(self.path).path == "/health":
            return False
        address = self.client_address[0] if self.client_address else "unknown"
        allowed, retry_after = limiter.allow(address)
        if allowed:
            return False
        self.send_response(429)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Retry-After", str(retry_after))
        self.send_header("X-Content-Type-Options", "nosniff")
        body = json.dumps({"error": "rate_limited", "retry_after_seconds": retry_after}).encode()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        return True

    def _mcp_authorized(self) -> bool:
        expected = os.getenv("SIC_API_TOKEN", "")
        supplied = self.headers.get("Authorization", "")
        return bool(expected) and hmac.compare_digest(supplied, f"Bearer {expected}")

    def _approval_authorized(self) -> bool:
        expected = os.getenv("SIC_APPROVAL_TOKEN", "")
        supplied = self.headers.get("X-SIC-Approval-Token", "")
        api_token = os.getenv("SIC_API_TOKEN", "")
        return bool(expected) and len(expected) >= 32 and expected != api_token and hmac.compare_digest(supplied, expected)

    def _authorized(self) -> bool:
        expected = os.getenv("SIC_API_TOKEN", "")
        host = os.getenv("SIC_HOST", "127.0.0.1")
        if host not in {"127.0.0.1", "localhost", "::1"} and not expected:
            return False
        if not expected:
            return True
        supplied = self.headers.get("Authorization", "")
        return hmac.compare_digest(supplied, f"Bearer {expected}")

    def do_GET(self) -> None:
        if self._host_rejected() or self._rate_limited():
            return
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/health":
            self._json(200, {"status": "ok", "service": "sic-core", "version": __version__})
            return
        if path in {"/v1/mcp/servers", "/v1/mcp/tools"} and not self._mcp_authorized():
            self._json(401, {"error": "mcp_admin_token_required", "message": "Configura SIC_API_TOKEN para administrar MCP."})
            return
        if path in {"/v1/memory", "/v1/knowledge", "/v1/tools", "/v1/audit"} and not self._authorized():
            self._json(401, {"error": "unauthorized"})
            return
        try:
            if path == "/v1/capabilities":
                provider = self.server.sic_service.provider
                mcp_manager = getattr(self.server, "mcp_manager", None)
                if mcp_manager is None:
                    mcp_manager = MCPManager()
                stdio_capability = mcp_manager.stdio_capability
                mcp_transports = ["streamable_http"] + (["stdio"] if stdio_capability["available"] else [])
                self._json(200, {
                    "service": "SIC Core",
                    "version": __version__,
                    "platform_independent_api": True,
                    "analysis_preprocessor": True,
                    "cognitive_engine": provider is not None,
                    "cognitive_passes": 3 if provider is not None else 0,
                    "chat_completions_provider": provider is not None,
                    "persistent_memory": True,
                    "versioned_knowledge_store": True,
                    "memory_context_retrieval": True,
                    "retrieval_method": "provider_embeddings_v1" if os.getenv("SIC_EMBEDDING_URL") and os.getenv("SIC_EMBEDDING_MODEL") else "local_hybrid_v2",
                    "semantic_embeddings_configured": bool(os.getenv("SIC_EMBEDDING_URL") and os.getenv("SIC_EMBEDDING_MODEL")),
                    "memory_backend": "sqlite",
                    "tool_execution": "allowlist_only",
                    "agent_orchestration": True,
                    "mcp_transport": True,
                    "mcp_transports": mcp_transports,
                    "mcp_stdio_allowlist_configured": bool(os.getenv("SIC_MCP_STDIO_ALLOWLIST")),
                    "mcp_stdio_sandbox": stdio_capability,
                    "mcp_servers_connected": len(mcp_manager.list_servers()),
                    "mcp_tools_auto_enabled": False,
                    "execution_audit": True,
                    "audit_hash_chain": True,
                    "stdio_process_limits": "rlimit_enforced_inside_bubblewrap_when_available",
                    "stdio_enabled": bool(stdio_capability["available"])
                                     and bool(os.getenv("SIC_MCP_STDIO_ALLOWLIST")),
                    "mcp_http_host_allowlist_required": True,
                    "tool_approval": "single_use_argument_bound_token",
                    "network_isolation": False,
                    "api_rate_limit_per_minute": round(getattr(self.server, "rate_limiter", _TokenBucketLimiter()).rate * 60),
                    "api_rate_limit_burst": int(getattr(self.server, "rate_limiter", _TokenBucketLimiter()).capacity),
                    "mcp_stdio_extra_ro_binds": mcp_manager.extra_ro_bind_count,
                    "mcp_remote_https_enabled": False,
                    "default_tool_count": len(getattr(self.server, "tool_registry", ToolRegistry()).list()),
                    "visual_observer": False,
                    "note": "La memoria solo almacena registros enviados explícitamente; no guarda automáticamente conversaciones ni análisis.",
                })
            elif path == "/v1/tools":
                self._json(200, {"tools": getattr(self.server, "tool_registry", ToolRegistry()).list(), "policy": "deny_by_default"})
            elif path == "/v1/audit":
                params = parse_qs(parsed.query)
                limit = int(params.get("limit", ["100"])[0])
                self._json(200, {"events": self.server.audit_log.list_events(limit), "integrity": self.server.audit_log.verify()})
            elif path == "/v1/mcp/servers":
                self._json(200, {"servers": self.server.mcp_manager.list_servers()})
            elif path == "/v1/mcp/tools":
                params = parse_qs(parsed.query)
                self._json(200, {"tools": self.server.mcp_manager.list_tools(params.get("server", [None])[0]), "policy": "discovered_not_enabled"})
            elif path == "/v1/memory":
                params = parse_qs(parsed.query)
                query = params.get("q", [""])[0]
                category = params.get("category", [""])[0]
                limit = int(params.get("limit", ["50"])[0])
                self._json(200, {"items": self.server.memory_store.list_memories(query, category, limit)})
            elif path == "/v1/knowledge":
                params = parse_qs(parsed.query)
                query = params.get("q", [""])[0]
                limit = int(params.get("limit", ["50"])[0])
                self._json(200, {"items": self.server.memory_store.list_knowledge(query, limit)})
            else:
                self._json(404, {"error": "not_found"})
        except (ValueError, TypeError) as exc:
            self._json(400, {"error": "invalid_request", "message": str(exc)})
        except Exception:
            LOG.exception("SIC GET request failed")
            self._json(500, {"error": "internal_error", "message": "Error interno; revisa los registros del servidor."})

    def do_POST(self) -> None:
        if self._host_rejected() or self._rate_limited():
            return
        path = urlparse(self.path).path
        if path in {"/v1/mcp/connect", "/v1/mcp/tools/allow", "/v1/tools/invoke"} and not self._mcp_authorized():
            self._json(401, {"error": "mcp_admin_token_required", "message": "Configura SIC_API_TOKEN para conectar o ejecutar herramientas."})
            return
        if path == "/v1/tools/approve" and not self._approval_authorized():
            self._json(401, {"error": "approver_token_required", "message": "Se requiere SIC_APPROVAL_TOKEN independiente para aprobar ejecuciones."})
            return
        if not self._authorized():
            self._json(401, {"error": "unauthorized", "message": "Token de API requerido o host remoto sin SIC_API_TOKEN."})
            return
        routes = {"/v1/prepare", "/v1/analyze", "/v1/context", "/v1/memory", "/v1/knowledge", "/v1/agents/plan", "/v1/tools/invoke", "/v1/tools/approve", "/v1/mcp/connect", "/v1/mcp/tools/allow"}
        if path not in routes:
            self._json(404, {"error": "not_found"})
            return
        if not self._json_content_type():
            self._json(415, {"error": "unsupported_media_type", "message": "Content-Type debe ser application/json."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_BODY:
                self._json(413, {"error": "invalid_body_size", "max_bytes": MAX_BODY})
                return
            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("El cuerpo JSON debe ser un objeto.")
            service = self.server.sic_service
            if path == "/v1/prepare":
                result = service.prepare(payload)
            elif path == "/v1/analyze":
                result = service.analyze(payload)
            elif path == "/v1/context":
                result = service.retrieve_context(payload)
            elif path == "/v1/agents/plan":
                result = self.server.agent_orchestrator.plan(payload.get("objective"), payload.get("context", []), payload.get("constraints", []))
            elif path == "/v1/tools/invoke":
                if "approved" in payload:
                    raise ValueError("El campo approved fue retirado; usa una aprobación de un solo uso.")
                result = self.server.tool_registry.invoke(payload.get("name", ""), payload.get("arguments", {}),
                                                          approval_token=payload.get("approval_token"))
            elif path == "/v1/tools/approve":
                if set(payload) - {"approval_request_id", "actor"}:
                    raise ValueError("Campos no permitidos en la aprobación.")
                result = self.server.tool_registry.approve(payload.get("approval_request_id", ""),
                                                           actor=payload.get("actor", "configured_approver"))
            elif path == "/v1/mcp/connect":
                allowed = {"name", "transport", "url", "command", "args", "api_key", "timeout"}
                if set(payload) - allowed:
                    raise ValueError("Campos no permitidos en configuración MCP.")
                config = MCPServerConfig(
                    name=payload.get("name", ""), transport=payload.get("transport", ""),
                    url=payload.get("url"), command=payload.get("command"),
                    args=payload.get("args", []), api_key=payload.get("api_key"),
                    timeout=float(payload.get("timeout", 15)),
                )
                if not isinstance(config.args, list):
                    raise ValueError("args debe ser una lista.")
                result = self.server.mcp_manager.connect(config)
            elif path == "/v1/mcp/tools/allow":
                result = self.server.mcp_manager.allow_tool(
                    self.server.tool_registry, server=payload.get("server", ""),
                    remote_tool=payload.get("remote_tool", ""), alias=payload.get("alias", ""),
                    description=payload.get("description", ""), risk=payload.get("risk", "high"),
                )
            elif path == "/v1/memory":
                result = self.server.memory_store.add_memory(payload)
            else:
                result = self.server.memory_store.add_knowledge(payload)
            self._json(201 if path in {"/v1/memory", "/v1/knowledge"} else 200, result)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, ToolError, MCPError, TypeError) as exc:
            self._json(400, {"error": "invalid_request", "message": str(exc)})
        except ProviderError as exc:
            LOG.warning("Provider error: %s", exc)
            self._json(502, {"error": "provider_error", "message": str(exc)})
        except Exception:
            # Never echo str(exc): it can carry file paths, SQL or other internals.
            LOG.exception("SIC request failed")
            self._json(500, {"error": "internal_error", "message": "Error interno; revisa los registros del servidor."})

    def do_DELETE(self) -> None:
        if self._host_rejected() or self._rate_limited():
            return
        if not self._authorized():
            self._json(401, {"error": "unauthorized"})
            return
        path = urlparse(self.path).path
        parts = path.strip("/").split("/")
        if len(parts) != 3 or parts[0] != "v1" or parts[1] not in {"memory", "knowledge"}:
            self._json(404, {"error": "not_found"})
            return
        record_id = unquote(parts[2])
        store = self.server.memory_store
        try:
            deleted = store.delete_memory(record_id) if parts[1] == "memory" else store.delete_knowledge(record_id)
        except Exception:
            LOG.exception("SIC DELETE request failed")
            self._json(500, {"error": "internal_error", "message": "Error interno; revisa los registros del servidor."})
            return
        self._json(200 if deleted else 404, {"deleted": deleted, "id": record_id})


def serve() -> None:
    logging.basicConfig(level=os.getenv("SIC_LOG_LEVEL", "INFO"))
    host = os.getenv("SIC_HOST", "127.0.0.1")
    port = env_int("SIC_PORT", 8765, 1, 65535)
    provider = ProviderConfig.from_env()
    db_path = os.getenv("SIC_DB_PATH", "~/.sic/sic_memory.sqlite3")
    remote = host not in {"127.0.0.1", "localhost", "::1"}
    if remote:
        api_token = os.getenv("SIC_API_TOKEN", "")
        if len(api_token) < 32:
            raise RuntimeError("Exposición remota bloqueada: SIC_API_TOKEN debe tener al menos 32 caracteres.")
        if os.getenv("SIC_TRUSTED_PROXY_TLS") != "1":
            raise RuntimeError("Exposición remota bloqueada: configura TLS en un proxy confiable y confirma SIC_TRUSTED_PROXY_TLS=1.")
        approval_token = os.getenv("SIC_APPROVAL_TOKEN", "")
        if len(approval_token) < 32 or hmac.compare_digest(approval_token, api_token):
            raise RuntimeError("Exposición remota bloqueada: SIC_APPROVAL_TOKEN debe ser independiente y tener al menos 32 caracteres.")
    httpd = ThreadingHTTPServer((host, port), SICHandler)
    rate = env_int("SIC_RATE_LIMIT_PER_MINUTE", 120, 1, 100_000)
    burst = env_int("SIC_RATE_LIMIT_BURST", 30, 1, 100_000)
    httpd.rate_limiter = _TokenBucketLimiter(rate, burst)
    httpd.memory_store = MemoryStore(db_path)
    audit_path = os.getenv("SIC_AUDIT_DB_PATH", "~/.sic/audit.sqlite3")
    httpd.audit_log = AuditLog(audit_path)
    httpd.sic_service = SICService(provider, httpd.memory_store, EmbeddingConfig.from_env())
    httpd.agent_orchestrator = AgentOrchestrator()
    httpd.tool_registry = ToolRegistry(audit_log=httpd.audit_log)
    httpd.mcp_manager = MCPManager([p for p in os.getenv("SIC_MCP_STDIO_ALLOWLIST", "").split(os.pathsep) if p],
                                   extra_ro_binds=[p for p in os.getenv("SIC_MCP_RO_BINDS", "").split(os.pathsep) if p])
    LOG.info("SIC Core %s escuchando en %s:%s", __version__, host, port)
    LOG.info("Modelo: %s", f"{provider.model} @ {provider.endpoint}" if provider else
             "no configurado (SIC_PROVIDER_URL y SIC_MODEL); /v1/analyze solo prepara la tarea")
    if host not in {"127.0.0.1", "localhost", "::1"}:
        LOG.info("SIC remoto: TLS de proxy declarado por operador; tokens separados y mínimos verificados.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        LOG.info("Apagando SIC Core")
    finally:
        httpd.mcp_manager.close()
        httpd.server_close()
