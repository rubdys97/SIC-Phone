from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any


class AuditLog:
    """SQLite append-only event log with a verifiable SHA-256 hash chain.

    This detects accidental or unauthorized edits to existing rows; it is not
    tamper-proof against an attacker who can rewrite the database and hashes.
    """
    def __init__(self, path: str):
        expanded = Path(path).expanduser()
        expanded.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = str(expanded)
        self._lock = threading.RLock()
        with self._connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS audit_events (
                seq INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL NOT NULL,
                event_json TEXT NOT NULL,
                previous_hash TEXT NOT NULL,
                event_hash TEXT NOT NULL UNIQUE
            )""")
        self._secure_permissions()

    def _secure_permissions(self) -> None:
        # Best-effort owner-only permissions on POSIX; Windows ACLs remain OS-managed.
        for candidate in (self.path, self.path + "-wal", self.path + "-shm"):
            try:
                if Path(candidate).exists():
                    os.chmod(candidate, 0o600)
            except OSError:
                pass

    @contextmanager
    def _connect(self):
        # sqlite3's own context manager only commits; it never closes the connection,
        # which leaked one file descriptor per recorded event.
        db = sqlite3.connect(self.path, timeout=10)
        try:
            db.execute("PRAGMA busy_timeout=10000")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def record(self, event: dict[str, Any]) -> dict[str, Any]:
        clean = json.loads(json.dumps(event, ensure_ascii=False, default=str))
        payload = json.dumps(clean, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        with self._lock, self._connect() as db:
            # Serialize writers across threads AND independent SIC worker processes.
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT event_hash FROM audit_events ORDER BY seq DESC LIMIT 1").fetchone()
            previous = row[0] if row else "0" * 64
            timestamp = time.time()
            digest = hashlib.sha256(f"{previous}|{timestamp:.6f}|{payload}".encode()).hexdigest()
            db.execute("INSERT INTO audit_events(timestamp,event_json,previous_hash,event_hash) VALUES(?,?,?,?)",
                       (timestamp, payload, previous, digest))
        self._secure_permissions()
        return {"timestamp": timestamp, "event": clean, "previous_hash": previous, "event_hash": digest}

    def list_events(self, limit: int = 100) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 500))
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT seq,timestamp,event_json,previous_hash,event_hash FROM audit_events ORDER BY seq DESC LIMIT ?", (limit,)).fetchall()
        return [{"sequence": r[0], "timestamp": r[1], "event": json.loads(r[2]),
                 "previous_hash": r[3], "event_hash": r[4]} for r in rows]

    def verify(self) -> dict[str, Any]:
        previous, checked = "0" * 64, 0
        with self._lock, self._connect() as db:
            # Stream rows instead of loading the whole log into memory.
            for seq, timestamp, payload, stored_previous, stored_hash in db.execute(
                    "SELECT seq,timestamp,event_json,previous_hash,event_hash FROM audit_events ORDER BY seq"):
                expected = hashlib.sha256(f"{previous}|{timestamp:.6f}|{payload}".encode()).hexdigest()
                if stored_previous != previous or stored_hash != expected:
                    return {"valid": False, "checked": checked, "broken_at": seq}
                previous = stored_hash
                checked += 1
        return {"valid": True, "checked": checked, "head": previous}
