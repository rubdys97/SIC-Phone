from __future__ import annotations

from .cognitive import CognitiveEngine
from .contracts import AnalysisRequest
from .planner import prepare_analysis
from .provider import ProviderConfig
from .embeddings import EmbeddingConfig, call_embeddings
from .context import ContextRetriever
from .memory import MemoryStore


class SICService:
    def __init__(self, provider: ProviderConfig | None = None, memory_store: MemoryStore | None = None, embedding_config: EmbeddingConfig | None = None):
        self.provider = provider
        self.memory_store = memory_store
        embedder = (lambda texts: call_embeddings(embedding_config, texts)) if embedding_config else None
        self.context_retriever = ContextRetriever(memory_store, embedder=embedder) if memory_store else None

    def prepare(self, raw: dict) -> dict:
        request = AnalysisRequest.from_dict(raw)
        envelope = prepare_analysis(request)
        result = envelope.to_dict()
        result["provider_available"] = self.provider is not None
        result["cognitive_engine_available"] = self.provider is not None
        result["next_action"] = "analyze" if self.provider else "configure_provider"
        return result

    def retrieve_context(self, raw: dict) -> dict:
        request = AnalysisRequest.from_dict(raw)
        if not self.context_retriever:
            return {"status": "memory_unavailable", "memories": [], "knowledge": [], "potential_conflicts": []}
        query = " ".join([request.objective, *request.context, *request.constraints, *request.success_criteria])
        return self.context_retriever.retrieve(query).to_dict()

    def analyze(self, raw: dict) -> dict:
        request = AnalysisRequest.from_dict(raw)
        envelope = prepare_analysis(request)
        result = envelope.to_dict()
        if self.provider is None:
            result["status"] = "prepared_without_model"
            result["notice"] = "El núcleo preparó la tarea, pero no hay un modelo configurado. No se simula razonamiento profundo."
            return result

        context_bundle = self.context_retriever.retrieve(" ".join([request.objective, *request.context, *request.constraints, *request.success_criteria])) if self.context_retriever else None
        cognitive = CognitiveEngine(self.provider).run(
            envelope.to_dict(),
            {
                "objective": request.objective,
                "context": request.context,
                "constraints": request.constraints,
                "success_criteria": request.success_criteria,
                "execution_mode": request.execution_mode,
            },
            context_bundle=context_bundle,
        )
        result.update({
            "status": "cognitive_analysis_received",
            "reasoning_provider": "openai_compatible_chat_completions",
            "reasoning_model": self.provider.model,
            "analysis": cognitive.to_dict(),
            "retrieved_context": context_bundle.to_dict() if context_bundle else {"memory_count": 0, "knowledge_count": 0, "note": "Memoria no conectada."},
        })
        return result
