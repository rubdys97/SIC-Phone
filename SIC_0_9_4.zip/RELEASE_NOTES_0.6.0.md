# SIC Core 0.6.0 — Etapa 5

## Incorporado
- Recuperación híbrida `local_hybrid_v2`: solapamiento léxico y similitud de subcadenas normalizadas.
- Adaptador opcional compatible con `/v1/embeddings` (`provider_embeddings_v1`).
- Validación de cantidad, dimensiones, tipo y finitud de vectores.
- Fallback local transparente si embeddings no está configurado o falla.
- Reporte de método usado y error de embeddings en la respuesta de contexto.
- Límite previo de 50 memorias + 50 elementos de conocimiento para respetar el máximo de 101 entradas del adaptador.
- Capacidades API actualizadas y documentación de configuración.

## Seguridad y límites
- Reutiliza la política HTTPS para proveedores remotos; HTTP solo para loopback.
- Clave de embeddings separada de la clave del proveedor de chat.
- No se persisten vectores ni se envían recuerdos automáticamente fuera del equipo salvo que se configure un endpoint remoto.
- Las puntuaciones son similitudes, no probabilidades ni validaciones factuales.
- El fallback local no es un modelo semántico ni una comprensión conceptual profunda.

## Verificación
- Suite unitaria: 28 pruebas aprobadas.
- Sin dependencias Python de terceros.
- Pruebas de embeddings usan respuestas simuladas; no se ha validado con un proveedor remoto real.
