# SIC Core 0.9.1 — Hardening y correcciones de concurrencia

**Base:** SIC 0.9.0 Etapa 8.  
**Objetivo:** corregir fallos reproducibles de concurrencia, retirar la aprobación booleana y reducir la superficie de riesgo MCP/API sin presentar controles parciales como sandbox completo.

## Correcciones implementadas

### A-01 — Auditoría concurrente
- `AuditLog.record()` usa `BEGIN IMMEDIATE` antes de leer el último hash y calcular el siguiente evento.
- La serialización SQLite coordina procesos independientes, no solo hilos de una instancia.
- Permisos 0600 best-effort para DB, WAL y SHM en sistemas POSIX.
- Prueba multiproceso: 4 procesos × 30 eventos; cadena verificada después de escritura concurrente.

### A-10 — Versionado de conocimiento
- `add_knowledge()` serializa lectura de versión e inserción con `BEGIN IMMEDIATE`.
- Índice único `UNIQUE(topic, version)`.
- Migración determinista de bases existentes con versiones duplicadas: reenumera por versión anterior, fecha y ID; reconstruye `supersedes`.
- Espera/reintento al activar WAL durante inicialización concurrente.
- Prueba multiproceso: 4 procesos × 20 inserciones; versiones 1–80 únicas.

### A-02 — Aprobación verificable de herramientas
- Eliminado `approved: true` como autorización.
- Primera invocación devuelve `approval_request_id` y no ejecuta.
- `POST /v1/tools/approve` requiere `SIC_APPROVAL_TOKEN`, separado de `SIC_API_TOKEN`.
- El aprobador emite token aleatorio de un solo uso, vinculado a herramienta, argumentos exactos y llamada.
- Token vence a los 5 minutos, se consume antes de ejecutar y no sobrevive al reinicio.
- La cola de solicitudes pendientes está acotada a 1,024 entradas y expira solicitudes vencidas.
- Las herramientas registradas con JSON Schema validan argumentos antes de solicitar aprobación o ejecutar.

Flujo:

1. `POST /v1/tools/invoke` con `name` y `arguments` → respuesta `approval_required` con `approval_request_id`.
2. Un aprobador separado llama `POST /v1/tools/approve`, usando `Authorization: Bearer <SIC_API_TOKEN>` y `X-SIC-Approval-Token: <SIC_APPROVAL_TOKEN>`; body `{"approval_request_id":"apr_...","actor":"operador"}`.
3. El aprobador entrega el `approval_token` resultante al cliente que realizará la ejecución.
4. Repetir `/v1/tools/invoke` con los mismos `name`, `arguments` y `approval_token`. Si cambia un argumento, vence o se reutiliza, se rechaza.

### A-03 — Restricción inicial de egreso MCP HTTP
- HTTPS remoto requiere host exacto en `SIC_MCP_HTTP_HOST_ALLOWLIST` (separado por comas).
- Se resuelve DNS antes de conectar y se rechazan IP no globales, privadas, loopback, link-local y reservadas.
- HTTP queda limitado a loopback.
- Redirecciones HTTP deshabilitadas.
- **Límite restante:** no hay fijación de IP en el socket; DNS rebinding entre validación y conexión todavía requiere mitigación de red/egreso del host. Mantener la política de red del sistema operativo restrictiva.

### A-07 / A-08 — Validación y límites MCP
- Validador JSON Schema recursivo acotado para tipos, enum, límites numéricos y de longitud, objetos, required, additionalProperties, arrays, items, uniqueItems, allOf/anyOf/oneOf.
- Límite de profundidad 16, nodos 2,048, propiedades 256, elementos 256 y tamaño de argumentos.
- Cola de lectura stdio acotada a 128 mensajes; al desbordarse termina el proceso.

### A-09 — Exposición remota fail-closed
- Para enlazar `SIC_HOST` fuera de loopback se exige `SIC_API_TOKEN` de al menos 32 caracteres, `SIC_APPROVAL_TOKEN` independiente de al menos 32 caracteres y `SIC_TRUSTED_PROXY_TLS=1`.
- La bandera TLS es una declaración explícita de que un proxy confiable termina TLS; SIC no valida por sí mismo la configuración del proxy ni implementa TLS nativo.

### MCP stdio — bloqueo seguro por defecto
- MCP stdio queda bloqueado por defecto porque SIC todavía no integra sandbox real de sistema operativo en la ruta MCP.
- Solo para desarrollo controlado se puede optar explícitamente con `SIC_MCP_STDIO_UNSAFE_DEV=1` y `SIC_MCP_STDIO_ALLOWLIST` con rutas absolutas exactas.
- Esta opción NO es aislamiento y no debe usarse con servidores no confiables ni en producción.

## Pruebas

- Pruebas de regresión de etapas anteriores.
- Concurrencia multiproceso de auditoría y versionado.
- Aprobación separada, vinculada a argumentos y de un solo uso.
- Rechazo del antiguo booleano `approved`.
- Validación JSON Schema anidada.
- Host MCP allowlist, bloqueo de IP privada y resolución DNS simulada.
- Prueba del endpoint de aprobación.

## Limitaciones que permanecen

- No hay sandbox de kernel/contenedor/VM integrado al MCP stdio; está bloqueado por defecto.
- No hay fijación de IP del socket contra DNS rebinding.
- TLS remoto depende de un proxy confiable declarado por el operador.
- La aprobación es volátil en memoria; no sobrevive reinicios ni ofrece identidad multiusuario federada.
- No hay rate limiting general ni scopes de token completos.
- Android no se ha compilado ni conectado todavía al backend SIC.
- No se ha ejecutado matriz real Windows/macOS ni pruebas contra proveedores MCP de producción.
- La cadena SHA-256 detecta alteraciones, pero no es resistente a un administrador hostil que pueda reescribir la DB completa.

**Estado:** hardening parcial con defectos críticos reproducidos corregidos y pruebas nuevas. No es certificación ni aprobación para producción.

## Resultado de construcción de esta entrega

`python -m unittest discover -s tests -v`: **63/63 aprobadas**.  
`python -m compileall -q sic_core tests`: completado sin errores.  
La matriz Windows/macOS, compilación Android y proxy TLS real no forman parte de esta verificación.
