import json
import os
import tempfile
import threading
from unittest.mock import patch
import unittest
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen

from sic_core.memory import MemoryStore
from sic_core.orchestration import AgentOrchestrator, ToolRegistry, ToolSpec
from sic_core.server import SICHandler, _TokenBucketLimiter
from sic_core.service import SICService
from sic_core.mcp import MCPManager


class MemoryApiTests(unittest.TestCase):
    def setUp(self):
        self.previous_token = os.environ.get("SIC_API_TOKEN")
        self.previous_approval_token = os.environ.get("SIC_APPROVAL_TOKEN")
        os.environ["SIC_API_TOKEN"] = "test-secret"
        os.environ["SIC_APPROVAL_TOKEN"] = "test-approval-secret-with-32-chars"
        self.tmp = tempfile.TemporaryDirectory()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), SICHandler)
        self.httpd.memory_store = MemoryStore(Path(self.tmp.name) / "api.sqlite3")
        self.httpd.sic_service = SICService(None, self.httpd.memory_store)
        self.httpd.agent_orchestrator = AgentOrchestrator()
        self.httpd.tool_registry = ToolRegistry()
        self.httpd.mcp_manager = MCPManager()
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.httpd.server_port}"

    def tearDown(self):
        self.httpd.mcp_manager.close()
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)
        self.tmp.cleanup()
        if self.previous_token is None:
            os.environ.pop("SIC_API_TOKEN", None)
        else:
            os.environ["SIC_API_TOKEN"] = self.previous_token
        if self.previous_approval_token is None:
            os.environ.pop("SIC_APPROVAL_TOKEN", None)
        else:
            os.environ["SIC_APPROVAL_TOKEN"] = self.previous_approval_token

    def call(self, method, path, payload=None, extra_headers=None):
        data = json.dumps(payload).encode() if payload is not None else None
        headers = {"Content-Type": "application/json", "Authorization": "Bearer test-secret"}
        headers.update(extra_headers or {})
        request = Request(self.base + path, data=data, method=method, headers=headers)
        with urlopen(request, timeout=3) as response:
            return response.status, json.loads(response.read())

    def test_create_list_delete_memory_via_api(self):
        status, created = self.call("POST", "/v1/memory", {"content": "API memory test"})
        self.assertEqual(status, 201)
        _, listing = self.call("GET", "/v1/memory?q=API%20memory")
        self.assertEqual(listing["items"][0]["memory_id"], created["memory_id"])
        _, deleted = self.call("DELETE", f"/v1/memory/{created['memory_id']}")
        self.assertTrue(deleted["deleted"])

    def test_create_and_list_knowledge_via_api(self):
        status, created = self.call("POST", "/v1/knowledge", {
            "topic": "api-test", "title": "API", "content": "Versioned knowledge"
        })
        self.assertEqual(status, 201)
        _, listing = self.call("GET", "/v1/knowledge?q=Versioned")
        self.assertEqual(listing["items"][0]["knowledge_id"], created["knowledge_id"])

    def test_context_preview_endpoint(self):
        self.call("POST", "/v1/memory", {"content": "SIC usa SQLite para memoria persistente", "category": "architecture"})
        status, result = self.call("POST", "/v1/context", {"objective": "Revisar SIC SQLite memoria"})
        self.assertEqual(status, 200)
        self.assertEqual(result["memory_count"], 1)

    def test_capabilities_report_persistence(self):
        _, capabilities = self.call("GET", "/v1/capabilities")
        self.assertTrue(capabilities["persistent_memory"])
        self.assertTrue(capabilities["versioned_knowledge_store"])
        self.assertTrue(capabilities["memory_context_retrieval"])

    def test_capabilities_report_stdio_disabled_without_verified_sandbox(self):
        with patch.dict(os.environ, {"SIC_MCP_STDIO_UNSAFE_DEV": "1"}):
            _, capabilities = self.call("GET", "/v1/capabilities")
        if not capabilities["mcp_stdio_sandbox"]["available"]:
            self.assertFalse(capabilities["stdio_enabled"])
            self.assertNotIn("stdio", capabilities["mcp_transports"])

    def test_capabilities_never_claim_remote_mcp_https_is_enabled(self):
        with patch.dict(os.environ, {"SIC_MCP_HTTP_REMOTE_ENABLED": "1"}):
            _, capabilities = self.call("GET", "/v1/capabilities")
        self.assertFalse(capabilities["mcp_remote_https_enabled"])

    def test_http_rate_limit_returns_429_and_retry_after(self):
        self.httpd.rate_limiter = _TokenBucketLimiter(rate_per_minute=1, burst=1)
        request = Request(self.base + "/v1/capabilities", method="GET")
        with urlopen(request, timeout=3) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(response.headers.get("X-Content-Type-Options"), "nosniff")
        with self.assertRaises(HTTPError) as caught:
            urlopen(request, timeout=3)
        self.assertEqual(caught.exception.code, 429)
        self.assertGreaterEqual(int(caught.exception.headers["Retry-After"]), 1)

    def test_agent_plan_endpoint_does_not_execute(self):
        status, plan = self.call("POST", "/v1/agents/plan", {"objective": "Diseñar una API segura"})
        self.assertEqual(status, 200)
        self.assertEqual(plan["status"], "planned_not_executed")

    def test_tool_invocation_endpoint_requires_registered_tool(self):
        self.httpd.tool_registry.register(ToolSpec("publish", "Publicar", risk="high"), lambda args: {"ok": True})
        status, result = self.call("POST", "/v1/tools/invoke", {"name": "publish", "arguments": {}})
        self.assertEqual(status, 200)
        self.assertEqual(result["status"], "approval_required")
        self.assertIn("approval_request_id", result)

    def test_legacy_boolean_approval_is_rejected(self):
        self.httpd.tool_registry.register(ToolSpec("publish", "Publicar", risk="high"), lambda args: {"ok": True})
        with self.assertRaises(HTTPError) as caught:
            self.call("POST", "/v1/tools/invoke", {"name": "publish", "arguments": {}, "approved": True})
        self.assertEqual(caught.exception.code, 400)
        result = json.loads(caught.exception.read())
        self.assertIn("retirado", result["message"])

    def test_separate_approval_endpoint_issues_argument_bound_single_use_token(self):
        self.httpd.tool_registry.register(ToolSpec("publish", "Publicar", risk="high"), lambda args: {"published": args["text"]})
        _, pending = self.call("POST", "/v1/tools/invoke", {"name": "publish", "arguments": {"text": "hola"}})
        _, approved = self.call("POST", "/v1/tools/approve",
                                {"approval_request_id": pending["approval_request_id"], "actor": "operator"},
                                {"X-SIC-Approval-Token": "test-approval-secret-with-32-chars"})
        _, result = self.call("POST", "/v1/tools/invoke",
                              {"name": "publish", "arguments": {"text": "hola"},
                               "approval_token": approved["approval_token"]})
        self.assertEqual(result["status"], "completed")

    def test_mcp_capability_and_empty_catalog(self):
        _, capabilities = self.call("GET", "/v1/capabilities")
        self.assertTrue(capabilities["mcp_transport"])
        self.assertFalse(capabilities["mcp_tools_auto_enabled"])
        _, catalog = self.call("GET", "/v1/mcp/tools")
        self.assertEqual(catalog["tools"], [])

    def test_tool_list_is_empty_by_default(self):
        _, result = self.call("GET", "/v1/tools")
        self.assertEqual(result["tools"], [])


if __name__ == "__main__":
    unittest.main()
