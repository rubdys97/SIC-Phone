import tempfile
import unittest
from pathlib import Path

from sic_core.context import ContextRetriever
from sic_core.memory import MemoryStore


class ContextRetrievalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = MemoryStore(Path(self.tmp.name) / "sic.sqlite3")

    def tearDown(self):
        self.tmp.cleanup()

    def test_retrieves_relevant_memory_and_latest_knowledge(self):
        memory = self.store.add_memory({"content": "El proyecto SIC utiliza SQLite para memoria persistente", "category": "architecture"})
        self.store.add_knowledge({"topic": "sic-storage", "title": "Storage v1", "content": "SIC usa SQLite local", "validation_status": "reviewed"})
        old = self.store.add_knowledge({"topic": "sic-storage", "title": "Storage v2", "content": "SIC usa SQLite y versionado", "validation_status": "verified"})
        result = ContextRetriever(self.store).retrieve("SIC SQLite memoria persistente")
        self.assertEqual(result.memories[0]["memory_id"], memory["memory_id"])
        self.assertEqual(result.knowledge[0]["knowledge_id"], old["knowledge_id"])
        self.assertEqual(result.knowledge[0]["version"], 2)

    def test_rejected_knowledge_is_not_retrieved(self):
        self.store.add_knowledge({"topic": "security", "title": "Rejected", "content": "SIC security token", "validation_status": "rejected"})
        result = ContextRetriever(self.store).retrieve("SIC security token")
        self.assertEqual(result.knowledge, ())

    def test_flags_heuristic_conflict_without_resolving_it(self):
        self.store.add_memory({"content": "El servidor siempre requiere token seguridad", "category": "policy"})
        self.store.add_memory({"content": "El servidor no requiere token seguridad", "category": "policy"})
        result = ContextRetriever(self.store).retrieve("servidor token seguridad")
        self.assertEqual(len(result.conflicts), 1)
        self.assertIn("requiere", result.conflicts[0]["shared_terms"])

    def test_empty_query_returns_no_context(self):
        self.store.add_memory({"content": "Información de SIC"})
        result = ContextRetriever(self.store).retrieve("")
        self.assertEqual(result.memories, ())


if __name__ == "__main__":
    unittest.main()
