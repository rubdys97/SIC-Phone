import json
import tempfile
import unittest
from pathlib import Path

from helpers import base_url, http_server
from sic_core.context import ContextRetriever
from sic_core.embeddings import EmbeddingConfig, call_embeddings
from sic_core.memory import MemoryStore
from sic_core.provider import ProviderError


class EmbeddingTests(unittest.TestCase):
    def test_embeddings_response_parsed_in_index_order(self):
        payload = {"data": [{"index": 1, "embedding": [0, 1]}, {"index": 0, "embedding": [1, 0]}]}
        with http_server(lambda request: (200, payload, None)) as server:
            vectors = call_embeddings(EmbeddingConfig(base_url(server) + "/v1/embeddings", "embed-model", "k"), ["a", "b"])
        self.assertEqual(vectors, [[1.0, 0.0], [0.0, 1.0]])
        sent = server.requests[0]
        self.assertEqual(sent["json"], {"model": "embed-model", "input": ["a", "b"]})
        self.assertEqual(sent["headers"]["Authorization"], "Bearer k")

    def test_bad_embedding_dimensions_rejected(self):
        payload = {"data": [{"index": 0, "embedding": [1]}, {"index": 1, "embedding": [1, 2]}]}
        with http_server(lambda request: (200, payload, None)) as server:
            with self.assertRaises(ProviderError):
                call_embeddings(EmbeddingConfig(base_url(server) + "/v1/embeddings", "embed-model"), ["a", "b"])

    def test_provider_embeddings_retrieve_by_similarity(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = MemoryStore(Path(tmp) / "memory.sqlite3")
            item = store.add_memory({"content": "El móvil necesita reemplazo de batería", "category": "repair"})
            # Query and memory deliberately share no meaningful lexical token.
            def fake_embedder(texts):
                return [[1.0, 0.0] if i in (0, 1) else [0.0, 1.0] for i, _ in enumerate(texts)]
            result = ContextRetriever(store, embedder=fake_embedder).retrieve("autonomía energética del teléfono")
            self.assertEqual(result.retrieval_method, "provider_embeddings_v1")
            self.assertEqual(result.memories[0]["memory_id"], item["memory_id"])

    def test_embedding_failure_falls_back_transparently(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = MemoryStore(Path(tmp) / "memory.sqlite3")
            store.add_memory({"content": "SIC utiliza SQLite para memoria"})
            def fail(_): raise ProviderError("servicio no disponible")
            result = ContextRetriever(store, embedder=fail).retrieve("SIC SQLite memoria")
            self.assertEqual(result.retrieval_method, "local_hybrid_v2")
            self.assertIn("servicio no disponible", result.embedding_error)
            self.assertEqual(len(result.memories), 1)


if __name__ == "__main__": unittest.main()
