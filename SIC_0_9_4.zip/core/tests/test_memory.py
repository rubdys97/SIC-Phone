import tempfile
import sqlite3
from uuid import uuid4
import unittest
from pathlib import Path

from sic_core.memory import MemoryStore


class MemoryStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = MemoryStore(Path(self.tmp.name) / "sic.sqlite3")

    def tearDown(self):
        self.tmp.cleanup()

    def test_memory_persists_and_searches(self):
        item = self.store.add_memory({"content": "Prefiere respuestas directas", "category": "preference", "tags": ["style"]})
        self.assertEqual(self.store.get_memory(item["memory_id"])["content"], "Prefiere respuestas directas")
        self.assertEqual(len(self.store.list_memories("directas")), 1)

    def test_memory_delete(self):
        item = self.store.add_memory({"content": "dato temporal"})
        self.assertTrue(self.store.delete_memory(item["memory_id"]))
        self.assertIsNone(self.store.get_memory(item["memory_id"]))

    def test_memory_validates_confidence(self):
        with self.assertRaises(ValueError):
            self.store.add_memory({"content": "x", "confidence": 2})

    def test_memory_validates_content(self):
        with self.assertRaises(ValueError):
            self.store.add_memory({"content": " "})

    def test_knowledge_versions_and_supersedes(self):
        first = self.store.add_knowledge({"topic": "python", "title": "Python", "content": "v1"})
        second = self.store.add_knowledge({"topic": "python", "title": "Python", "content": "v2", "validation_status": "reviewed"})
        self.assertEqual(first["version"], 1)
        self.assertEqual(second["version"], 2)
        self.assertEqual(second["supersedes"], first["knowledge_id"])

    def test_startup_migration_repairs_duplicate_legacy_versions(self):
        first = self.store.add_knowledge({"topic": "legacy", "title": "one", "content": "1"})
        with sqlite3.connect(self.store.db_path) as db:
            db.execute("DROP INDEX uq_knowledge_topic_version")
            for title in ("duplicate-a", "duplicate-b"):
                db.execute("INSERT INTO knowledge(knowledge_id,topic,title,content,source_refs_json,validation_status,version,supersedes,created_at,status) VALUES(?,?,?,?,?,?,?,?,?,?)",
                           (f"kn_{uuid4().hex}", "legacy", title, "x", "[]", "unverified", 1, first["knowledge_id"], "2026-01-01T00:00:00Z", "active"))
        migrated = MemoryStore(self.store.db_path)
        versions = [item["version"] for item in migrated.list_knowledge("legacy", limit=10)]
        self.assertEqual(sorted(versions), [1, 2, 3])
        with sqlite3.connect(self.store.db_path) as db:
            indexes = [row[1] for row in db.execute("PRAGMA index_list(knowledge)")]
        self.assertIn("uq_knowledge_topic_version", indexes)

    def test_knowledge_search(self):
        self.store.add_knowledge({"topic": "security", "title": "Threat model", "content": "Least privilege", "source_refs": ["https://example.invalid/doc"]})
        results = self.store.list_knowledge("privilege")
        self.assertEqual(results[0]["source_refs"], ["https://example.invalid/doc"])

    def test_knowledge_rejects_unknown_validation(self):
        with self.assertRaises(ValueError):
            self.store.add_knowledge({"topic": "x", "title": "x", "content": "x", "validation_status": "magic"})

    def test_limit_bounds(self):
        with self.assertRaises(ValueError):
            self.store.list_memories(limit=500)


if __name__ == "__main__":
    unittest.main()
