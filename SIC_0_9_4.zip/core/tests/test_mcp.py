import json
import os
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen

from sic_core.mcp import MCPClient, MCPError, MCPManager, MCPServerConfig, _validate_arguments
from sic_core.sandbox import MCPProcessSandbox
from sic_core.orchestration import ToolRegistry


class FakeMCPHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        payload = json.loads(self.rfile.read(length))
        method = payload.get("method")
        if method != "initialize":
            self.server.seen_headers.append(dict(self.headers))
        if method == "notifications/initialized":
            self.send_response(202)
            self.end_headers()
            return
        if method == "initialize":
            result = {"protocolVersion": "2025-11-25", "capabilities": {"tools": {}},
                      "serverInfo": {"name": "fake", "version": "1"}}
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("MCP-Session-Id", "session-test")
        elif method == "tools/list":
            result = {"tools": [{"name": "echo", "description": "Echo input", "inputSchema": {
                "type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}]}
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
        elif method == "tools/call":
            result = {"content": [{"type": "text", "text": payload["params"]["arguments"]["text"]}]}
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
        else:
            self.send_response(400)
            self.end_headers()
            return
        body = json.dumps({"jsonrpc": "2.0", "id": payload["id"], "result": result}).encode()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class MCPTests(unittest.TestCase):
    def test_recursive_json_schema_validation_enforces_nested_constraints(self):
        schema = {"type": "object", "properties": {"config": {"type": "object",
                  "properties": {"mode": {"type": "string", "enum": ["safe", "strict"]},
                                 "retries": {"type": "integer", "minimum": 1, "maximum": 3}},
                  "required": ["mode", "retries"], "additionalProperties": False},
                  "items": {"type": "array", "items": {"type": "string", "minLength": 2}, "maxItems": 3}},
                  "required": ["config"]}
        _validate_arguments(schema, {"config": {"mode": "safe", "retries": 2}, "items": ["ok"]})
        with self.assertRaises(MCPError):
            _validate_arguments(schema, {"config": {"mode": "unsafe", "retries": 2}})
        with self.assertRaises(MCPError):
            _validate_arguments(schema, {"config": {"mode": "safe", "retries": 9}})
        with self.assertRaises(MCPError):
            _validate_arguments(schema, {"config": {"mode": "safe", "retries": 2, "extra": True}})

    def test_remote_mcp_https_is_fail_closed_until_socket_ip_pinning_exists(self):
        with patch.dict(os.environ, {"SIC_MCP_HTTP_HOST_ALLOWLIST": "example.com", "SIC_MCP_HTTP_REMOTE_ENABLED": "1"}):
            with self.assertRaisesRegex(MCPError, "DNS rebinding"):
                MCPClient(MCPServerConfig(name="remote", transport="streamable_http", url="https://example.com/mcp"))

    def test_localhost_https_is_allowed_without_remote_dns(self):
        client = MCPClient(MCPServerConfig(name="local-tls", transport="streamable_http", url="https://localhost/mcp"))
        self.assertEqual(client.config.url, "https://localhost/mcp")

    def setUp(self):
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), FakeMCPHandler)
        self.httpd.seen_headers = []
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.httpd.server_port}/mcp"

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)

    def test_http_connect_discover_and_call(self):
        client = MCPClient(MCPServerConfig(name="local", transport="streamable_http", url=self.url))
        info = client.connect()
        self.assertTrue(info["connected"])
        self.assertEqual(client.list_tools()[0]["name"], "echo")
        result = client.call_tool("echo", {"text": "SIC"})
        self.assertEqual(result["content"][0]["text"], "SIC")
        self.assertEqual(self.httpd.seen_headers[-1].get("Mcp-Session-Id"), "session-test")
        self.assertEqual(self.httpd.seen_headers[-1].get("Mcp-Protocol-Version"), "2025-11-25")

    def test_remote_http_requires_https(self):
        with self.assertRaises(MCPError):
            MCPClient(MCPServerConfig(name="remote", transport="streamable_http", url="http://example.com/mcp"))

    def test_stdio_requires_absolute_existing_executable(self):
        with self.assertRaises(MCPError):
            MCPClient(MCPServerConfig(name="bad", transport="stdio", command="python"))

    def test_stdio_client_cannot_bypass_manager_allowlist(self):
        with self.assertRaisesRegex(MCPError, "solo puede crearse mediante MCPManager"):
            MCPClient(MCPServerConfig(name="direct", transport="stdio", command=sys.executable))

    def test_discovered_tool_is_not_automatically_registered(self):
        manager = MCPManager()
        manager.connect(MCPServerConfig(name="local", transport="streamable_http", url=self.url))
        registry = ToolRegistry()
        self.assertEqual(registry.list(), [])
        self.assertEqual(len(manager.list_tools()), 1)
        manager.close()

    def test_external_tool_allowlist_requires_high_risk_and_approval(self):
        manager = MCPManager()
        manager.connect(MCPServerConfig(name="local", transport="streamable_http", url=self.url))
        registry = ToolRegistry()
        with self.assertRaises(MCPError):
            manager.allow_tool(registry, server="local", remote_tool="echo", alias="remote_echo", risk="low")
        allowed = manager.allow_tool(registry, server="local", remote_tool="echo", alias="remote_echo")
        self.assertTrue(allowed["requires_approval"])
        self.assertEqual(registry.invoke("remote_echo", {"text": "x"})["status"], "approval_required")
        request = registry.invoke("remote_echo", {"text": "x"})
        approved = registry.approve(request["approval_request_id"], actor="test-approver")
        result = registry.invoke("remote_echo", {"text": "x"}, approval_token=approved["approval_token"])
        self.assertEqual(result["status"], "completed")
        manager.close()


    def test_stdio_transport_uses_persistent_jsonrpc_process(self):
        available, reason = MCPProcessSandbox().available()
        if not available:
            self.skipTest(f"Sandbox OS no disponible en este host: {reason}")
        python_runtime = "/usr/bin/python3"
        if not os.path.isfile(python_runtime):
            self.skipTest("No hay intérprete Python dentro del runtime /usr expuesto al sandbox")
        program = r"""import json, sys
for line in sys.stdin:
    msg = json.loads(line)
    method = msg.get('method')
    if method == 'notifications/initialized':
        continue
    if method == 'initialize':
        result = {'protocolVersion':'2025-11-25','capabilities':{'tools':{}},'serverInfo':{'name':'stdio-test','version':'1'}}
    elif method == 'tools/list':
        result = {'tools':[{'name':'ping','inputSchema':{'type':'object'}}]}
    elif method == 'tools/call':
        result = {'content':[{'type':'text','text':'pong'}]}
    else:
        continue
    print(json.dumps({'jsonrpc':'2.0','id':msg['id'],'result':result}), flush=True)
"""
        manager = MCPManager([os.path.realpath(python_runtime)])
        manager.connect(MCPServerConfig(name="stdio", transport="stdio", command=python_runtime,
                                        args=["-u", "-c", program], timeout=5))
        self.assertEqual(manager.list_tools()[0]["name"], "ping")
        self.assertEqual(manager.call("stdio", "ping", {})["content"][0]["text"], "pong")
        manager.close()

    def test_stdio_manager_requires_explicit_executable_allowlist(self):
        manager = MCPManager()
        with self.assertRaises(MCPError):
            manager.connect(MCPServerConfig(name="blocked", transport="stdio", command=sys.executable,
                                            args=["-c", "pass"]))

    def test_stdio_remains_blocked_even_with_allowlist_without_unsafe_dev_opt_in(self):
        # Hermetic: this used to depend on bubblewrap being absent from the host, and
        # failed (the server really launched) on any machine that had it installed.
        with patch.dict(os.environ, {}, clear=True), \
                patch.object(MCPProcessSandbox, "available", return_value=(False, "test unavailable")):
            manager = MCPManager([sys.executable])
            with self.assertRaisesRegex(MCPError, "aislamiento verificable"):
                manager.connect(MCPServerConfig(name="blocked", transport="stdio", command=sys.executable,
                                                args=["-c", "pass"]))

    def test_unsafe_dev_environment_variable_cannot_bypass_sandbox(self):
        with patch.dict(os.environ, {"SIC_MCP_STDIO_UNSAFE_DEV": "1"}, clear=True):
            with patch.object(MCPProcessSandbox, "available", return_value=(False, "test unavailable")):
                manager = MCPManager([sys.executable])
                with self.assertRaisesRegex(MCPError, "aislamiento verificable"):
                    manager.connect(MCPServerConfig(name="blocked", transport="stdio", command=sys.executable,
                                                    args=["-c", "pass"]))

    def test_bubblewrap_command_requires_namespace_and_network_isolation(self):
        if not sys.platform.startswith("linux") or not os.path.isfile("/usr/bin/python3"):
            self.skipTest("Prueba del backend bubblewrap solo en Linux con runtime /usr")
        with tempfile.TemporaryDirectory() as tmp:
            fake = Path(tmp) / "bwrap"
            fake.write_text("#!/bin/sh\nexit 0\n")
            fake.chmod(0o755)
            sandbox = MCPProcessSandbox(str(fake))
            command = sandbox.command("/usr/bin/python3", ["-c", "pass"], tmp)
            self.assertIn("--unshare-all", command)
            self.assertIn("--die-with-parent", command)
            self.assertIn("--ro-bind", command)
            self.assertIn("--clearenv", command)
            self.assertEqual(command[-3:], [os.path.realpath("/usr/bin/python3"), "-c", "pass"])

    def test_unknown_remote_tool_rejected(self):
        manager = MCPManager()
        manager.connect(MCPServerConfig(name="local", transport="streamable_http", url=self.url))
        with self.assertRaises(MCPError):
            manager.call("local", "not_discovered", {})
        manager.close()

    def test_remote_tool_arguments_are_checked_against_discovered_schema(self):
        manager = MCPManager()
        manager.connect(MCPServerConfig(name="local", transport="streamable_http", url=self.url))
        with self.assertRaises(MCPError):
            manager.call("local", "echo", {})
        with self.assertRaises(MCPError):
            manager.call("local", "echo", {"text": 12})
        manager.close()


if __name__ == "__main__":
    unittest.main()
