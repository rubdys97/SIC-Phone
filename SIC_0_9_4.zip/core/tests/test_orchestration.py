import unittest

from sic_core.orchestration import AgentOrchestrator, ToolError, ToolRegistry, ToolSpec


class OrchestrationTests(unittest.TestCase):
    def test_plan_assigns_specialist_and_validator(self):
        plan = AgentOrchestrator().plan("Auditar la seguridad de una API")
        self.assertEqual(plan["status"], "planned_not_executed")
        self.assertEqual(plan["agents"][0]["specialty"], "cybersecurity")
        self.assertEqual(plan["agents"][1]["specialty"], "quality_and_risk")
        self.assertEqual(len(plan["steps"]), 4)

    def test_empty_objective_rejected(self):
        with self.assertRaises(ValueError):
            AgentOrchestrator().plan(" ")

    def test_unregistered_tool_denied(self):
        with self.assertRaises(ToolError):
            ToolRegistry().invoke("shell", {"cmd": "id"})

    def test_approval_gate_requires_separate_single_use_token(self):
        registry = ToolRegistry()
        registry.register(ToolSpec("publish", "Publicar contenido", risk="high"), lambda args: {"ok": True})
        args = {"text": "hola"}
        request = registry.invoke("publish", args)
        self.assertEqual(request["status"], "approval_required")
        approved = registry.approve(request["approval_request_id"], actor="reviewer")
        self.assertEqual(registry.invoke("publish", args, approval_token=approved["approval_token"])["status"], "completed")
        with self.assertRaises(ToolError):
            registry.invoke("publish", args, approval_token=approved["approval_token"])

    def test_approval_is_bound_to_exact_arguments(self):
        registry = ToolRegistry()
        registry.register(ToolSpec("publish", "Publicar contenido", risk="high"), lambda args: {"ok": True})
        request = registry.invoke("publish", {"text": "original"})
        approved = registry.approve(request["approval_request_id"])
        with self.assertRaises(ToolError):
            registry.invoke("publish", {"text": "changed"}, approval_token=approved["approval_token"])

    def test_explicit_approval_executes_registered_tool(self):
        registry = ToolRegistry()
        registry.register(ToolSpec("lookup", "Consulta", risk="read_only"), lambda args: {"q": args["q"]})
        result = registry.invoke("lookup", {"q": "SIC"})
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["result"]["q"], "SIC")

    def test_registered_tool_schema_is_enforced(self):
        registry = ToolRegistry()
        registry.register(ToolSpec("bounded", "Bounded", input_schema={"type": "object",
                               "properties": {"count": {"type": "integer", "minimum": 1, "maximum": 2}},
                               "required": ["count"], "additionalProperties": False}), lambda args: args)
        self.assertEqual(registry.invoke("bounded", {"count": 2})["status"], "completed")
        with self.assertRaises(ToolError):
            registry.invoke("bounded", {"count": 5})

    def test_tool_failure_is_reported(self):
        registry = ToolRegistry()
        def fail(_):
            raise RuntimeError("boom")
        registry.register(ToolSpec("broken", "Falla"), fail)
        self.assertEqual(registry.invoke("broken", {})["status"], "failed")


if __name__ == "__main__":
    unittest.main()
