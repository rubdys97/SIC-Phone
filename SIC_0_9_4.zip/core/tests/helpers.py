"""Shared test helpers: a real loopback HTTP server instead of patching urllib internals."""
from __future__ import annotations

import json
import threading
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


@contextmanager
def http_server(responder):
    """Run a loopback server. responder(request) -> (status, body, headers).

    `request` is a dict with method, path, headers, json (parsed body or None) and raw.
    Every request is appended to `server.requests` so tests can inspect what was sent.
    `body` may be a dict/list (sent as JSON) or bytes.
    """
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _handle(self):
            length = int(self.headers.get("Content-Length", "0") or 0)
            raw = self.rfile.read(length) if length else b""
            try:
                parsed = json.loads(raw) if raw else None
            except ValueError:
                parsed = None
            request = {"method": self.command, "path": self.path, "headers": dict(self.headers),
                       "json": parsed, "raw": raw}
            self.server.requests.append(request)
            status, body, headers = responder(request)
            payload = body if isinstance(body, bytes) else json.dumps(body).encode()
            self.send_response(status)
            for key, value in {"Content-Type": "application/json", **(headers or {})}.items():
                self.send_header(key, value)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        do_POST = do_GET = _handle

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    server.requests = []
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def base_url(server) -> str:
    return f"http://127.0.0.1:{server.server_address[1]}"
