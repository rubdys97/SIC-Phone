import unittest

from sic_core.contracts import AnalysisRequest
from sic_core.planner import classify_domain, prepare_analysis
from sic_core.provider import ProviderError, validate_provider_url


class CoreTests(unittest.TestCase):
    def test_rejects_empty_objective(self):
        with self.assertRaises(ValueError):
            AnalysisRequest.from_dict({"objective": "  "})

    def test_classifies_software(self):
        self.assertEqual(classify_domain("Diseñar una API y corregir un bug"), "software_engineering")

    def test_cyber_scope_is_unknown_until_confirmed(self):
        envelope = prepare_analysis(AnalysisRequest.from_dict({"objective": "Analizar vulnerabilidad CVE en un servidor"}))
        self.assertTrue(any("alcance autorizado" in item for item in envelope.unknowns))
        self.assertTrue(envelope.assumptions)

    def test_local_http_provider_allowed(self):
        validate_provider_url("http://127.0.0.1:11434/v1/chat/completions")

    def test_remote_http_provider_rejected(self):
        with self.assertRaises(ProviderError):
            validate_provider_url("http://example.com/v1/chat/completions")


if __name__ == "__main__":
    unittest.main()
