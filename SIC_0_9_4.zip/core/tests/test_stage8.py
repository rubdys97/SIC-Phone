import os
import sys
import tempfile
import unittest
import multiprocessing
from pathlib import Path

from sic_core.audit import AuditLog
from sic_core.orchestration import ToolRegistry, ToolSpec
from sic_core.sandbox import ProcessSandbox, SandboxError, SandboxLimits


def _audit_writer(path: str, count: int) -> None:
    log = AuditLog(path)
    for index in range(count):
        log.record({"worker": os.getpid(), "index": index})

def _knowledge_writer(path: str, count: int) -> None:
    from sic_core.memory import MemoryStore
    store = MemoryStore(path)
    for index in range(count):
        store.add_knowledge({"topic": "parallel", "title": f"t{index}", "content": "v"})


class Stage8Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_audit_hash_chain_records_and_verifies(self):
        log = AuditLog(str(Path(self.tmp.name) / "audit.sqlite3"))
        log.record({"event_type": "test", "status": "ok"})
        log.record({"event_type": "test", "status": "failed"})
        self.assertTrue(log.verify()["valid"])
        self.assertEqual(len(log.list_events()), 2)

    def test_audit_detects_modified_event(self):
        path = str(Path(self.tmp.name) / "audit.sqlite3")
        log = AuditLog(path)
        log.record({"status": "original"})
        import sqlite3
        with sqlite3.connect(path) as db:
            db.execute("UPDATE audit_events SET event_json='{}' WHERE seq=1")
        self.assertFalse(log.verify()["valid"])

    def test_registry_audits_approval_and_execution_without_raw_arguments(self):
        log = AuditLog(str(Path(self.tmp.name) / "audit.sqlite3"))
        registry = ToolRegistry(audit_log=log)
        registry.register(ToolSpec("danger", "test", risk="high", requires_approval=True), lambda x: {"ok": True})
        request = registry.invoke("danger", {"secret": "do-not-log"})
        self.assertEqual(request["status"], "approval_required")
        approved = registry.approve(request["approval_request_id"], actor="test-approver")
        self.assertEqual(registry.invoke("danger", {"secret": "do-not-log"}, approval_token=approved["approval_token"])["status"], "completed")
        events = log.list_events()
        self.assertEqual([e["event"]["status"] for e in reversed(events)], ["approval_required", "approved", "execution_started", "completed"])
        self.assertNotIn("do-not-log", str(events))
        self.assertTrue(log.verify()["valid"])

    def test_audit_chain_is_valid_across_process_writers(self):
        path = str(Path(self.tmp.name) / "parallel-audit.sqlite3")
        context = multiprocessing.get_context("spawn")
        workers = [context.Process(target=_audit_writer, args=(path, 30)) for _ in range(4)]
        for worker in workers: worker.start()
        for worker in workers: worker.join(15)
        self.assertTrue(all(worker.exitcode == 0 for worker in workers))
        log = AuditLog(path)
        self.assertEqual(log.verify()["checked"], 120)
        self.assertTrue(log.verify()["valid"])

    def test_knowledge_versions_are_unique_across_process_writers(self):
        path = str(Path(self.tmp.name) / "parallel-memory.sqlite3")
        context = multiprocessing.get_context("spawn")
        workers = [context.Process(target=_knowledge_writer, args=(path, 20)) for _ in range(4)]
        for worker in workers: worker.start()
        for worker in workers: worker.join(20)
        self.assertTrue(all(worker.exitcode == 0 for worker in workers))
        import sqlite3
        with sqlite3.connect(path) as db:
            versions = [row[0] for row in db.execute("SELECT version FROM knowledge WHERE topic='parallel' ORDER BY version")]
        self.assertEqual(versions, list(range(1, 81)))

    def test_process_sandbox_requires_exact_allowlisted_executable(self):
        sandbox = ProcessSandbox([])
        with self.assertRaises(SandboxError):
            sandbox.run(sys.executable, ["-c", "print('x')"])

    def test_process_sandbox_executes_with_limits_and_temp_workdir(self):
        sandbox = ProcessSandbox([sys.executable])
        result = sandbox.run(sys.executable, ["-S", "-c", "import json,sys; x=json.load(sys.stdin); print(x['value'])"],
                             {"value": "sic-ok"}, SandboxLimits(timeout_seconds=5, memory_mb=256))
        self.assertEqual(result["return_code"], 0)
        self.assertEqual(result["stdout"].strip(), "sic-ok")
        self.assertFalse(result["network_isolation"])
        self.assertIn("resource_limits", result["isolation"])

    def test_process_sandbox_timeout_is_enforced(self):
        sandbox = ProcessSandbox([sys.executable])
        with self.assertRaises(SandboxError):
            sandbox.run(sys.executable, ["-S", "-c", "import time; time.sleep(3)"], {},
                        SandboxLimits(timeout_seconds=1, memory_mb=256))


if __name__ == "__main__":
    unittest.main()
