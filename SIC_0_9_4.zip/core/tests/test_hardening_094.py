"""Regression tests for the 0.9.4 hardening pass.

Each test pins a defect that existed in 0.9.3. Network behaviour is exercised against
real loopback servers and the sandbox against a real bubblewrap (skipped when the host
cannot create namespaces), rather than by patching library internals.
"""
import http.client
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

from helpers import base_url, http_server
from sic_core.audit import AuditLog
from sic_core.context import ContextRetriever
from sic_core.mcp import (MCPError, MCPManager, MCPServerConfig, _pattern_is_safe, _validate_arguments,
                          _validate_endpoint, find_unsafe_pattern)
from sic_core.memory import MemoryStore
from sic_core.orchestration import AgentOrchestrator, ToolRegistry
from sic_core.planner import classify_domain
from sic_core.provider import ProviderConfig, ProviderError, call_chat_completion
from sic_core.sandbox import MCPProcessSandbox, SandboxError, parse_extra_ro_binds
from sic_core.server import SICHandler
from sic_core.service import SICService

CORE_DIR = Path(__file__).resolve().parents[1]
PYTHON_IN_USR = "/usr/bin/python3"


def _bwrap_ready() -> bool:
    return sys.platform.startswith("linux") and os.path.isfile(PYTHON_IN_USR) and MCPProcessSandbox().available()[0]


needs_bwrap = unittest.skipUnless(_bwrap_ready(), "bubblewrap no disponible en este host")
linux_only = unittest.skipUnless(sys.platform.startswith("linux"), "semántica de rutas de Linux")


class SandboxAvailabilityGate(unittest.TestCase):
    """A skipped sandbox test proves nothing. CI sets SIC_REQUIRE_BWRAP=1 so that a runner
    without working user namespaces fails loudly instead of silently skipping the e2e tests."""

    @unittest.skipUnless(os.getenv("SIC_REQUIRE_BWRAP") == "1", "SIC_REQUIRE_BWRAP no está activo")
    def test_bubblewrap_must_be_usable_when_required(self):
        self.assertTrue(_bwrap_ready(), f"bubblewrap no funciona en este host: {MCPProcessSandbox().available()}")


# --------------------------------------------------------------------------- provider
class ProviderTests(unittest.TestCase):
    def test_redirect_is_refused_and_credentials_are_not_forwarded(self):
        # urllib follows 301/302/303 on a POST (as a GET) and copies the Authorization
        # header to the new location, so a redirecting endpoint could harvest the API key.
        # (307/308 are not followed for POST, so they never leaked; they are covered too.)
        for code in (301, 302, 303, 307, 308):
            with self.subTest(status=code):
                with http_server(lambda request: (200, {"ok": True}, None)) as sink:
                    target = base_url(sink) + "/steal"
                    with http_server(lambda request, c=code: (c, b"", {"Location": target})) as origin:
                        config = ProviderConfig(base_url(origin) + "/v1/chat/completions", "m", "SECRET-KEY")
                        with self.assertRaises(ProviderError):
                            call_chat_completion(config, "sys", "user")
                self.assertEqual(sink.requests, [], f"la clave API llegó al destino de la redirección {code}")

    def test_embeddings_requests_do_not_follow_redirects_either(self):
        from sic_core.embeddings import EmbeddingConfig, call_embeddings
        with http_server(lambda request: (200, {"data": []}, None)) as sink:
            with http_server(lambda request: (302, b"", {"Location": base_url(sink) + "/steal"})) as origin:
                with self.assertRaisesRegex(ProviderError, "redirección"):
                    call_embeddings(EmbeddingConfig(base_url(origin) + "/v1/embeddings", "m", "SECRET-KEY"), ["a"])
        self.assertEqual(sink.requests, [])

    def test_three_pass_analysis_end_to_end_over_real_http(self):
        def responder(request):
            n = len(request["json"]["messages"]) and len(responder.seen) + 1
            responder.seen.append(request)
            return 200, {"choices": [{"message": {"content": f"salida pasada {n}"}}]}, None
        responder.seen = []
        with http_server(responder) as server:
            service = SICService(ProviderConfig(base_url(server) + "/v1/chat/completions", "modelo-x", "KEY"))
            result = service.analyze({"objective": "Evaluar un plan de respaldo", "context": ["tiene 3 sucursales"],
                                      "success_criteria": ["restaurar en 1 hora"]})
        self.assertEqual(result["status"], "cognitive_analysis_received")
        analysis = result["analysis"]
        self.assertEqual((analysis["problem_frame"], analysis["critical_review"], analysis["executive_decision"]),
                         ("salida pasada 1", "salida pasada 2", "salida pasada 3"))
        self.assertEqual(len(server.requests), 3)
        for request in server.requests:
            self.assertEqual(request["headers"]["Authorization"], "Bearer KEY")
            self.assertEqual(request["json"]["model"], "modelo-x")
        first_prompt = server.requests[0]["json"]["messages"][1]["content"]
        self.assertIn("<<<DATOS>>>", first_prompt)
        self.assertIn('"objective": "Evaluar un plan de respaldo"', first_prompt)
        self.assertNotIn("{'objective'", first_prompt, "se serializó con repr() en vez de JSON")
        # the later passes must see the earlier ones
        third_prompt = server.requests[2]["json"]["messages"][1]["content"]
        self.assertIn("salida pasada 1", third_prompt)
        self.assertIn("salida pasada 2", third_prompt)

    def test_http_error_and_bad_shape_are_reported(self):
        with http_server(lambda request: (500, {"error": "boom"}, None)) as server:
            with self.assertRaisesRegex(ProviderError, "HTTP 500"):
                call_chat_completion(ProviderConfig(base_url(server) + "/x", "m", ""), "s", "u")
        with http_server(lambda request: (200, {"nope": 1}, None)) as server:
            with self.assertRaisesRegex(ProviderError, "incompatible"):
                call_chat_completion(ProviderConfig(base_url(server) + "/x", "m", ""), "s", "u")

    def test_invalid_numeric_environment_gives_a_clear_error(self):
        env = {"SIC_PROVIDER_URL": "http://127.0.0.1:1/v1/chat/completions", "SIC_MODEL": "m",
               "SIC_PROVIDER_TIMEOUT": "abc"}
        with patch.dict(os.environ, env):
            with self.assertRaisesRegex(ValueError, "SIC_PROVIDER_TIMEOUT"):
                ProviderConfig.from_env()


# --------------------------------------------------------------------------- server
class ServerHardeningTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {}, clear=False)
        self.env.start()
        for name in ("SIC_API_TOKEN", "SIC_APPROVAL_TOKEN", "SIC_ALLOWED_HOSTS", "SIC_HOST"):
            os.environ.pop(name, None)
        self.tmp = tempfile.TemporaryDirectory()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), SICHandler)
        self.httpd.memory_store = MemoryStore(Path(self.tmp.name) / "m.sqlite3")
        self.httpd.sic_service = SICService(None, self.httpd.memory_store)
        self.httpd.agent_orchestrator = AgentOrchestrator()
        self.httpd.tool_registry = ToolRegistry()
        self.httpd.mcp_manager = MCPManager()
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.port = self.httpd.server_port

    def tearDown(self):
        self.httpd.mcp_manager.close()
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=2)
        self.tmp.cleanup()
        self.env.stop()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            payload = json.dumps(body) if body is not None else None
            connection.request(method, path, body=payload, headers=headers or {})
            response = connection.getresponse()
            raw = response.read()
            return response.status, (json.loads(raw) if raw else None)
        finally:
            connection.close()

    def test_dns_rebinding_host_header_is_rejected(self):
        status, body = self.request("GET", "/v1/memory", headers={"Host": "attacker.example:8765"})
        self.assertEqual(status, 403)
        self.assertEqual(body["error"], "host_not_allowed")

    def test_loopback_host_names_are_accepted(self):
        for host in (f"127.0.0.1:{self.port}", f"localhost:{self.port}", "localhost", f"[::1]:{self.port}"):
            status, _ = self.request("GET", "/health", headers={"Host": host})
            self.assertEqual(status, 200, host)

    def test_extra_allowed_hosts_can_be_configured(self):
        with patch.dict(os.environ, {"SIC_ALLOWED_HOSTS": "sic.internal"}):
            self.assertEqual(self.request("GET", "/health", headers={"Host": "sic.internal"})[0], 200)
            self.assertEqual(self.request("GET", "/health", headers={"Host": "other.internal"})[0], 403)

    def test_cross_site_simple_post_is_refused_without_side_effects(self):
        # text/plain is a CORS "simple" content type: a web page can POST it to
        # localhost without a preflight. It must not reach the handlers.
        status, body = self.request("POST", "/v1/memory", {"content": "inyectado desde una web"},
                                    headers={"Content-Type": "text/plain"})
        self.assertEqual(status, 415)
        self.assertEqual(self.httpd.memory_store.list_memories(), [])

    def test_json_content_type_with_charset_is_accepted(self):
        status, body = self.request("POST", "/v1/memory", {"content": "ok"},
                                    headers={"Content-Type": "application/json; charset=utf-8"})
        self.assertEqual(status, 201)

    def test_internal_errors_do_not_leak_details(self):
        with patch.object(self.httpd.memory_store, "add_memory",
                          side_effect=RuntimeError("/home/secret/path.sqlite3: disk I/O error")):
            status, body = self.request("POST", "/v1/memory", {"content": "x"},
                                        headers={"Content-Type": "application/json"})
        self.assertEqual(status, 500)
        self.assertEqual(body["error"], "internal_error")
        self.assertNotIn("secret", json.dumps(body))

    def test_provider_failures_are_reported_as_502(self):
        with patch.object(self.httpd.sic_service, "analyze", side_effect=ProviderError("proveedor caído")):
            status, body = self.request("POST", "/v1/analyze", {"objective": "x"},
                                        headers={"Content-Type": "application/json"})
        self.assertEqual((status, body["error"]), (502, "provider_error"))

    def test_handler_has_a_socket_timeout(self):
        self.assertTrue(0 < SICHandler.timeout <= 60)


# --------------------------------------------------------------------------- audit
class AuditTests(unittest.TestCase):
    @unittest.skipUnless(os.path.isdir("/proc/self/fd"), "requiere /proc")
    def test_recording_events_does_not_leak_file_descriptors(self):
        with tempfile.TemporaryDirectory() as tmp:
            log = AuditLog(str(Path(tmp) / "audit.sqlite3"))
            log.record({"warmup": True})
            before = len(os.listdir("/proc/self/fd"))
            for index in range(300):
                log.record({"event": index})
            log.list_events(5)
            log.verify()
            after = len(os.listdir("/proc/self/fd"))
            self.assertLessEqual(after - before, 3, f"fds: {before} -> {after}")
            self.assertEqual(log.verify(), {"valid": True, "checked": 301, "head": log.list_events(1)[0]["event_hash"]})

    def test_tampering_is_detected(self):
        import sqlite3
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "audit.sqlite3")
            log = AuditLog(path)
            for index in range(5):
                log.record({"event": index})
            with sqlite3.connect(path) as db:
                db.execute("UPDATE audit_events SET event_json='{\"event\":99}' WHERE seq=3")
            result = log.verify()
            self.assertFalse(result["valid"])
            self.assertEqual(result["broken_at"], 3)
            self.assertEqual(result["checked"], 2)


# --------------------------------------------------------------------------- planner
class DomainClassificationTests(unittest.TestCase):
    def test_substrings_inside_ordinary_words_no_longer_match(self):
        # "capital" contains "api"; "ingredientes"/"predecir" contain "red".
        for text in ("Cómo ahorrar capital para el retiro", "Predecir la demanda de ingredientes", "Reducir gastos"):
            self.assertEqual(classify_domain(text), "general_strategy", text)
            self.assertEqual(AgentOrchestrator().plan(text)["agents"][0]["specialty"], "general_reasoning", text)

    def test_real_domain_words_still_match(self):
        self.assertEqual(classify_domain("Diseñar una API REST"), "software_engineering")
        self.assertEqual(classify_domain("Auditar la red y buscar vulnerabilidades"), "cybersecurity")
        self.assertEqual(classify_domain("Hacer pentesting de un APK"), "cybersecurity")
        self.assertEqual(classify_domain("Investigar fuentes y comparar evidencia"), "research")
        self.assertEqual(classify_domain("INVESTIGACIÓN sobre el mercado"), "research")  # case + accent folding


# --------------------------------------------------------------------------- memory
class MemoryRetrievalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = MemoryStore(Path(self.tmp.name) / "m.sqlite3")

    def tearDown(self):
        self.tmp.cleanup()

    def test_like_wildcards_are_searched_literally(self):
        self.store.add_memory({"content": "El descuento es del 100% en abril"})
        self.store.add_memory({"content": "Nota sin símbolo especial"})
        self.store.add_memory({"content": "ruta a_b/archivo"})
        self.assertEqual(len(self.store.list_memories("%")), 1)
        self.assertEqual(len(self.store.list_memories("_")), 1)
        self.assertEqual(len(self.store.list_memories("a_b")), 1)
        self.assertEqual(len(self.store.list_knowledge("%")), 0)

    def test_knowledge_beyond_the_first_fifty_topics_is_retrievable(self):
        for index in range(120):
            self.store.add_knowledge({"topic": f"tema-{index:03d}", "title": "genérico", "content": f"relleno {index}"})
        self.store.add_knowledge({"topic": "tema-999", "title": "Calibración",
                                  "content": "protocolo de calibración láser especial"})
        result = ContextRetriever(self.store).retrieve("calibración láser")
        self.assertEqual([k["topic"] for k in result.knowledge], ["tema-999"])

    def test_only_the_latest_version_of_a_topic_is_retrieved(self):
        self.store.add_knowledge({"topic": "precio", "title": "Precio", "content": "el precio de la pantalla es 800"})
        self.store.add_knowledge({"topic": "precio", "title": "Precio", "content": "el precio de la pantalla es 950"})
        self.store.add_knowledge({"topic": "viejo", "title": "Rechazado", "content": "el precio de la pantalla es 1",
                                  "validation_status": "rejected"})
        result = ContextRetriever(self.store).retrieve("precio de la pantalla")
        self.assertEqual([(k["topic"], k["version"]) for k in result.knowledge], [("precio", 2)])

    def test_old_memories_beyond_the_most_recent_fifty_are_found(self):
        import sqlite3
        target = self.store.add_memory({"content": "el router del taller usa el canal seis"})
        fillers = [self.store.add_memory({"content": f"nota de relleno número {index}"}) for index in range(120)]
        # created_at has 1 s resolution, so rapid inserts tie; give every record a distinct,
        # realistic age so that the target really is older than the 50 most recent ones.
        with sqlite3.connect(self.store.db_path) as db:
            db.execute("UPDATE memories SET created_at=? WHERE memory_id=?", ("2020-01-01T00:00:00+00:00", target["memory_id"]))
            for index, item in enumerate(fillers):
                db.execute("UPDATE memories SET created_at=? WHERE memory_id=?",
                           (f"2026-10-01T00:{index // 60:02d}:{index % 60:02d}+00:00", item["memory_id"]))
        result = ContextRetriever(self.store).retrieve("router del taller canal")
        self.assertEqual(result.memories[0]["memory_id"], target["memory_id"])

    def test_recency_order_is_deterministic_when_timestamps_tie(self):
        for index in range(5):
            self.store.add_memory({"content": f"registro {index}"})  # same second: created_at ties
        self.assertEqual([m["content"] for m in self.store.list_memories()],
                         [f"registro {i}" for i in (4, 3, 2, 1, 0)])
        self.assertEqual([m["content"] for m in self.store.scan_memories(2)], ["registro 4", "registro 3"])


# --------------------------------------------------------------------------- MCP
def mcp_responder(tools, call_result=None, sse=False, delay_initialize=0.0):
    """Minimal MCP Streamable-HTTP server. `sse=True` answers with CRLF-delimited SSE,
    sending a progress notification before the result of tools/list and tools/call."""
    def respond(request):
        message = request["json"] or {}
        method = message.get("method")
        if method == "notifications/initialized":
            return 202, b"", {"Content-Type": "text/plain"}
        if method == "initialize":
            time.sleep(delay_initialize)
            result = {"protocolVersion": "2025-11-25", "capabilities": {"tools": {}},
                      "serverInfo": {"name": "fake", "version": "1"}}
        elif method == "tools/list":
            result = {"tools": tools}
        elif method == "tools/call":
            result = call_result or {"content": [{"type": "text", "text": "ok"}]}
        else:
            return 400, b"", {}
        envelope = {"jsonrpc": "2.0", "id": message["id"], "result": result}
        if sse:
            progress = {"jsonrpc": "2.0", "method": "notifications/progress", "params": {"progress": 1}}
            events = [progress] if method in ("tools/list", "tools/call") else []
            body = "".join("event: message\r\ndata: " + json.dumps(e) + "\r\n\r\n" for e in [*events, envelope])
            return 200, body.encode(), {"Content-Type": "text/event-stream"}
        return 200, envelope, None
    return respond


class MCPHardeningTests(unittest.TestCase):
    def test_catastrophic_pattern_from_a_remote_schema_is_refused_quickly(self):
        schema = {"type": "object", "properties": {"x": {"type": "string", "pattern": "(a+)+$"}}}
        started = time.monotonic()
        with self.assertRaises(MCPError):
            _validate_arguments(schema, {"x": "a" * 40 + "!"})
        self.assertLess(time.monotonic() - started, 0.5)

    def test_common_safe_patterns_still_validate(self):
        schema = {"type": "object", "properties": {
            "mail": {"type": "string", "pattern": r"^[^@\s]+@[^@\s]+\.[^@\s]+$"},
            "date": {"type": "string", "pattern": r"^\d{4}-\d{2}-\d{2}$"}}}
        _validate_arguments(schema, {"mail": "a@b.co", "date": "2026-11-08"})
        with self.assertRaises(MCPError):
            _validate_arguments(schema, {"mail": "no-es-correo"})
        with self.assertRaises(MCPError):
            _validate_arguments(schema, {"date": "08/11/2026"})
        with self.assertRaises(MCPError):  # too long to check against a pattern safely
            _validate_arguments(schema, {"mail": "a" * 600 + "@b.co"})

    def test_pattern_guard_classification(self):
        for safe in (r"^[A-Za-z0-9_.-]+$", r"^https?://[^\s]+$", r"^\d{3}$"):
            self.assertTrue(_pattern_is_safe(safe), safe)
        for unsafe in (r"(a+)+$", r"(a|aa)+$", r"^(\w+\s?)*$", r"a*a*a*a*b", r"(.)\1", r"(?=x)y", "[", "x" * 201):
            self.assertFalse(_pattern_is_safe(unsafe), unsafe)

    def test_find_unsafe_pattern_walks_nested_schemas_but_not_data(self):
        nested = {"type": "object", "properties": {"a": {"type": "array", "items": {"type": "string", "pattern": "(x+)+"}}}}
        self.assertEqual(find_unsafe_pattern(nested), "(x+)+")
        # a property that is merely *named* "pattern" is not a regex
        self.assertIsNone(find_unsafe_pattern({"type": "object", "properties": {"pattern": {"type": "string"}}}))

    def test_allow_tool_refuses_a_tool_with_an_unsafe_pattern(self):
        tools = [{"name": "t", "inputSchema": {"type": "object", "properties": {
            "x": {"type": "string", "pattern": "(a+)+$"}}}}]
        with http_server(mcp_responder(tools)) as server:
            manager = MCPManager()
            manager.connect(MCPServerConfig(name="srv", transport="streamable_http", url=base_url(server) + "/mcp"))
            with self.assertRaisesRegex(MCPError, "denegación de servicio"):
                manager.allow_tool(ToolRegistry(), server="srv", remote_tool="t", alias="srv_t")
            manager.close()

    def test_sse_streams_with_several_crlf_events_are_parsed(self):
        # 0.9.3 merged "notification + result" into one invalid JSON payload when events were CRLF-delimited.
        tools = [{"name": "echo", "inputSchema": {"type": "object"}}]
        with http_server(mcp_responder(tools, call_result={"content": [{"type": "text", "text": "hola"}]}, sse=True)) as server:
            manager = MCPManager()
            manager.connect(MCPServerConfig(name="srv", transport="streamable_http", url=base_url(server) + "/mcp"))
            self.assertEqual(manager.list_tools()[0]["name"], "echo")
            self.assertEqual(manager.call("srv", "echo", {})["content"][0]["text"], "hola")
            manager.close()

    def test_a_slow_connect_does_not_block_the_rest_of_the_manager(self):
        with http_server(mcp_responder([], delay_initialize=1.5)) as server:
            manager = MCPManager()
            config = MCPServerConfig(name="slow", transport="streamable_http", url=base_url(server) + "/mcp", timeout=10)
            worker = threading.Thread(target=manager.connect, args=(config,))
            worker.start()
            time.sleep(0.3)
            started = time.monotonic()
            self.assertEqual(manager.list_servers(), [])
            self.assertLess(time.monotonic() - started, 0.5, "list_servers quedó bloqueado por un connect lento")
            with self.assertRaisesRegex(MCPError, "Ya existe"):
                manager.connect(MCPServerConfig(name="slow", transport="streamable_http", url=base_url(server) + "/mcp"))
            worker.join(timeout=10)
            self.assertEqual(len(manager.list_servers()), 1)
            manager.close()

    def test_localhost_subdomains_are_not_treated_as_loopback(self):
        for url in ("http://evil.localhost:8000/", "http://example.com/", "http://10.0.0.5/"):
            with self.assertRaises(MCPError, msg=url):
                _validate_endpoint(url)
        _validate_endpoint("http://localhost:8000/")
        _validate_endpoint("http://127.0.0.1:8000/")
        _validate_endpoint("http://[::1]:8000/")


# --------------------------------------------------------------------------- sandbox
HOSTILE_PROBE = r"""
import json, os, socket, sys
out = {}
def attempt(name, fn):
    try:
        out[name] = {"ok": True, "value": fn()}
    except Exception as exc:
        out[name] = {"ok": False, "error": type(exc).__name__}
def connect(host, port):
    s = socket.socket(); s.settimeout(2); s.connect((host, port)); return "conectó"
attempt("host_loopback_service", lambda: connect("127.0.0.1", int(sys.argv[1])))
attempt("internet", lambda: connect("1.1.1.1", 80))
attempt("dns", lambda: socket.gethostbyname("example.com"))
attempt("etc_passwd", lambda: open("/etc/passwd").read())
attempt("home", lambda: os.listdir("/home"))
attempt("write_usr", lambda: open("/usr/pwned", "w").write("x"))
attempt("write_workdir", lambda: open("/tmp/sic-mcp/ok", "w").write("x"))
attempt("root_listing", lambda: sorted(os.listdir("/")))
attempt("env", lambda: dict(os.environ))
attempt("pids", lambda: sorted(int(p) for p in os.listdir("/proc") if p.isdigit()))
print(json.dumps(out))
"""


@needs_bwrap
class SandboxIsolationTests(unittest.TestCase):
    def run_hostile(self, port):
        with tempfile.TemporaryDirectory() as workdir:
            command = MCPProcessSandbox().command(PYTHON_IN_USR, ["-c", HOSTILE_PROBE, str(port)], workdir)
            completed = subprocess.run(command, capture_output=True, text=True, timeout=30, env={})
            self.assertEqual(completed.returncode, 0, completed.stderr)
            return json.loads(completed.stdout)

    def test_a_hostile_server_process_is_contained(self):
        # A real service listening on the host's loopback must be unreachable from inside.
        with http_server(lambda request: (200, {"secret": "host-service"}, None)) as host_service:
            result = self.run_hostile(host_service.server_address[1])
            self.assertEqual(host_service.requests, [], "el proceso aislado alcanzó un servicio del host")
        for name in ("host_loopback_service", "internet", "dns", "etc_passwd", "home", "write_usr"):
            self.assertFalse(result[name]["ok"], f"{name} debería estar bloqueado: {result[name]}")
        self.assertTrue(result["write_workdir"]["ok"])  # the private workdir is the only writable place
        self.assertEqual(result["env"]["value"], {"PATH": "/usr/bin:/bin", "HOME": "/tmp/sic-mcp",
                                                  "LANG": "C.UTF-8", "PWD": "/tmp/sic-mcp"})
        self.assertNotIn("home", result["root_listing"]["value"])
        self.assertNotIn("etc", result["root_listing"]["value"])
        self.assertNotIn(os.getpid(), result["pids"]["value"], "el proceso ve procesos del host")
        self.assertLessEqual(len(result["pids"]["value"]), 4)

    def test_stdio_sessions_are_fully_cleaned_up_on_close(self):
        program = ("import json,sys\nfor l in sys.stdin:\n m=json.loads(l)\n x=m.get('method')\n"
                   " if x=='initialize': r={'protocolVersion':'2025-11-25','capabilities':{},'serverInfo':{}}\n"
                   " elif x=='tools/list': r={'tools':[]}\n else: continue\n"
                   " print(json.dumps({'jsonrpc':'2.0','id':m['id'],'result':r}),flush=True)\n")
        manager = MCPManager([PYTHON_IN_USR])
        manager.connect(MCPServerConfig(name="s", transport="stdio", command=PYTHON_IN_USR, args=["-u", "-c", program], timeout=5))
        session = manager._clients["s"]._stdio
        self.assertIsNone(session.proc.poll())
        manager.close()
        self.assertIsNotNone(session.proc.poll(), "el proceso MCP sigue vivo tras close()")
        self.assertTrue(session.proc.stdin.closed and session.proc.stdout.closed, "pipes sin cerrar")

    DEMO_SERVER = ("import json,sys\nfor l in sys.stdin:\n m=json.loads(l)\n x=m.get('method')\n"
                   " if x=='initialize': r={'protocolVersion':'2025-11-25','capabilities':{},'serverInfo':{}}\n"
                   " elif x=='tools/list': r={'tools':[{'name':'suma','inputSchema':{'type':'object'}}]}\n"
                   " elif x=='tools/call': a=m['params']['arguments']; r={'content':[{'type':'text','text':str(a.get('a',0)+a.get('b',0))}]}\n"
                   " else: continue\n"
                   " print(json.dumps({'jsonrpc':'2.0','id':m['id'],'result':r}),flush=True)\n")

    def test_server_survives_the_request_thread_that_connected_it(self):
        # 0.9.3: the sandbox's --die-with-parent is PR_SET_PDEATHSIG, tied to the *thread*
        # that forked. Each HTTP request runs on a short-lived thread, so the server was
        # SIGKILLed when POST /v1/mcp/connect returned and every later call failed.
        manager = MCPManager([PYTHON_IN_USR])
        config = MCPServerConfig(name="s", transport="stdio", command=PYTHON_IN_USR,
                                 args=["-u", "-c", self.DEMO_SERVER], timeout=10)
        worker = threading.Thread(target=manager.connect, args=(config,))
        worker.start()
        worker.join()
        time.sleep(0.5)  # ample time for a (wrongly) delivered death signal to land
        try:
            self.assertIsNone(manager._clients["s"]._stdio.proc.poll(), "el servidor murió con el hilo que lo creó")
            self.assertEqual(manager.call("s", "suma", {"a": 2, "b": 40})["content"][0]["text"], "42")
        finally:
            manager.close()

    @unittest.skipUnless(os.path.isdir("/proc/self"), "requiere /proc")
    def test_sandboxed_server_still_dies_when_the_sic_process_is_killed(self):
        code = ("import sys, time\nfrom sic_core.mcp import MCPManager, MCPServerConfig\n"
                f"m = MCPManager(['{PYTHON_IN_USR}'])\n"
                f"m.connect(MCPServerConfig(name='s', transport='stdio', command='{PYTHON_IN_USR}', "
                f"args=['-u', '-c', {self.DEMO_SERVER!r}], timeout=10))\n"
                "print(m._clients['s']._stdio.proc.pid, flush=True)\ntime.sleep(60)\n")

        def alive(pid):
            try:
                state = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0]
            except OSError:
                return False
            return state != "Z"

        parent = subprocess.Popen([sys.executable, "-c", code], stdout=subprocess.PIPE, text=True,
                                  env={**os.environ, "PYTHONPATH": str(CORE_DIR)}, cwd=CORE_DIR)
        try:
            child = int(parent.stdout.readline())
            self.assertTrue(alive(child))
            parent.kill()
            parent.wait()
            deadline = time.monotonic() + 5
            while alive(child) and time.monotonic() < deadline:
                time.sleep(0.1)
            self.assertFalse(alive(child), "el servidor MCP sobrevivió a la muerte de SIC")
        finally:
            parent.kill()
            parent.wait()

    def test_server_script_outside_usr_runs_through_a_read_only_bind(self):
        script = r"""
import json, sys
def tool_result(text): return {'content': [{'type': 'text', 'text': text}]}
for line in sys.stdin:
    msg = json.loads(line); method = msg.get('method')
    if method == 'initialize':
        result = {'protocolVersion': '2025-11-25', 'capabilities': {}, 'serverInfo': {'name': 'bound'}}
    elif method == 'tools/list':
        result = {'tools': [{'name': 'probe', 'inputSchema': {'type': 'object'}}]}
    elif method == 'tools/call':
        try:
            open(__file__, 'a').write('tamper'); verdict = 'ESCRIBIÓ'
        except OSError as exc:
            verdict = 'solo-lectura:' + type(exc).__name__
        result = tool_result(verdict)
    else:
        continue
    print(json.dumps({'jsonrpc': '2.0', 'id': msg['id'], 'result': result}), flush=True)
"""
        with tempfile.TemporaryDirectory() as tmp:
            server_dir = Path(tmp) / "mcp-server"
            server_dir.mkdir()
            (server_dir / "server.py").write_text(script)
            manager = MCPManager([PYTHON_IN_USR], extra_ro_binds=[str(server_dir)])
            manager.connect(MCPServerConfig(name="bound", transport="stdio", command=PYTHON_IN_USR,
                                            args=["-u", str(server_dir / "server.py")], timeout=10))
            verdict = manager.call("bound", "probe", {})["content"][0]["text"]
            manager.close()
            self.assertTrue(verdict.startswith("solo-lectura"), verdict)
            self.assertEqual((server_dir / "server.py").read_text(), script, "el bind de solo lectura fue modificado")

    def test_without_the_bind_a_script_outside_usr_is_not_visible(self):
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "server.py"
            script.write_text("print('hola')")
            manager = MCPManager([PYTHON_IN_USR])
            with self.assertRaises(MCPError):  # python exits immediately: cannot open the script
                manager.connect(MCPServerConfig(name="x", transport="stdio", command=PYTHON_IN_USR,
                                                args=["-u", str(script)], timeout=5))
            manager.close()


@linux_only
class ReadOnlyBindValidationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = Path(self.tmp.name) / "home" / "user"
        (self.home / ".ssh").mkdir(parents=True)
        (self.home / ".sic").mkdir()
        (self.home / "tools").mkdir()
        self.env = patch.dict(os.environ, {"HOME": str(self.home)})
        self.env.start()
        os.environ.pop("SIC_DB_PATH", None)
        os.environ.pop("SIC_AUDIT_DB_PATH", None)

    def tearDown(self):
        self.env.stop()
        self.tmp.cleanup()

    def test_dangerous_binds_are_rejected(self):
        for bad in ("/", "/proc", "/sys", "/dev", "/tmp", str(self.home), str(self.home.parent),
                    str(self.home / ".ssh"), str(self.home / ".sic"), "relativo/ruta", str(self.home / "no-existe")):
            with self.assertRaises(SandboxError, msg=bad):
                parse_extra_ro_binds([bad])

    def test_database_directory_cannot_be_exposed_even_when_relocated(self):
        data_dir = Path(self.tmp.name) / "var-sic"
        data_dir.mkdir()
        with patch.dict(os.environ, {"SIC_DB_PATH": str(data_dir / "m.sqlite3")}):
            with self.assertRaises(SandboxError):
                parse_extra_ro_binds([str(data_dir)])
            with self.assertRaises(SandboxError):
                parse_extra_ro_binds([self.tmp.name])  # an ancestor of it

    def test_ordinary_tool_directories_are_accepted_and_normalised(self):
        tools = str(self.home / "tools")
        self.assertEqual(parse_extra_ro_binds([tools, tools, "", "/usr/lib"]), (os.path.realpath(tools),))

    def test_executable_must_live_under_usr_or_a_configured_bind(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake_bwrap = Path(tmp) / "bwrap"
            fake_bwrap.write_text("#!/bin/sh\nexit 0\n")
            fake_bwrap.chmod(0o755)
            outside = self.home / "tools" / "server"
            outside.write_text("#!/bin/sh\n")
            outside.chmod(0o755)
            with self.assertRaisesRegex(SandboxError, "SIC_MCP_RO_BINDS"):
                MCPProcessSandbox(str(fake_bwrap)).command(str(outside), [], tmp)
            command = MCPProcessSandbox(str(fake_bwrap), [str(self.home / "tools")]).command(str(outside), [], tmp)
            self.assertIn(str(self.home / "tools"), command)
            # the bind must come after --tmpfs /tmp, otherwise a bind under /tmp is hidden
            self.assertGreater(command.index("--ro-bind", command.index("--tmpfs")), command.index("--tmpfs"))


# --------------------------------------------------------------------------- CLI
class CliTests(unittest.TestCase):
    def test_invalid_configuration_exits_cleanly_without_a_traceback(self):
        env = {**os.environ, "SIC_PORT": "no-es-un-numero", "PYTHONPATH": str(CORE_DIR)}
        completed = subprocess.run([sys.executable, "-m", "sic_core.cli", "serve"], capture_output=True, text=True,
                                   timeout=20, env=env, cwd=CORE_DIR)
        self.assertEqual(completed.returncode, 2)
        self.assertIn("SIC_PORT", completed.stderr)
        self.assertNotIn("Traceback", completed.stderr)


if __name__ == "__main__":
    unittest.main()
