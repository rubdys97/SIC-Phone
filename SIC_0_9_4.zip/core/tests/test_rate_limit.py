import unittest
from sic_core.server import _TokenBucketLimiter


class RateLimiterTests(unittest.TestCase):
    def test_token_bucket_enforces_burst_and_refills(self):
        limiter = _TokenBucketLimiter(rate_per_minute=60, burst=2)
        self.assertEqual(limiter.allow("client", now=10), (True, 0))
        self.assertEqual(limiter.allow("client", now=10), (True, 0))
        allowed, retry = limiter.allow("client", now=10)
        self.assertFalse(allowed)
        self.assertEqual(retry, 1)
        self.assertEqual(limiter.allow("client", now=11), (True, 0))

    def test_client_buckets_are_isolated_and_bounded(self):
        limiter = _TokenBucketLimiter(rate_per_minute=1, burst=1, max_clients=2)
        self.assertTrue(limiter.allow("a", now=1)[0])
        self.assertTrue(limiter.allow("b", now=1)[0])
        self.assertTrue(limiter.allow("c", now=1)[0])
        self.assertLessEqual(len(limiter._buckets), 2)

    def test_invalid_limits_rejected(self):
        with self.assertRaises(ValueError):
            _TokenBucketLimiter(rate_per_minute=0)


if __name__ == "__main__":
    unittest.main()
