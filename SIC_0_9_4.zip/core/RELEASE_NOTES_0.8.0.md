# SIC Core 0.8.0 — Etapa 7: integración MCP

## Incorporado

- Cliente MCP sin dependencias externas para los transportes `stdio` y Streamable HTTP legado (handshake `initialize`, versión `2025-11-25`).
- Negociación de versión y sesión HTTP mediante `MCP-Session-Id` cuando el servidor la asigna.
- Descubrimiento de herramientas remotas con límites de tamaño y validación básica de catálogo.
- Ejecución remota `tools/call` solo después de habilitar manualmente la herramienta en la lista permitida de SIC.
- Toda herramienta MCP habilitada queda clasificada como `high` o `critical` y exige aprobación en cada invocación.
- La administración MCP y la invocación de herramientas requieren `SIC_API_TOKEN`, incluso en loopback.
- MCP stdio bloqueado por defecto; requiere ruta ejecutable exacta en `SIC_MCP_STDIO_ALLOWLIST`.
- HTTPS obligatorio para MCP remoto; HTTP solo en loopback. Redirecciones HTTP bloqueadas.
- Respuestas y argumentos con límites; proceso stdio sin shell, con entorno reducido, timeout y cierre controlado.
- Metadatos de servidores/herramientas remotas marcados como no confiables; no se convierten en instrucciones del orquestador.
- Nuevos endpoints de conexión, catálogo y habilitación explícita.

## Endpoints

- `POST /v1/mcp/connect`: conectar un servidor y descubrir sus herramientas.
- `GET /v1/mcp/servers`: listar conexiones activas.
- `GET /v1/mcp/tools?server=NOMBRE`: consultar herramientas descubiertas (no habilitadas).
- `POST /v1/mcp/tools/allow`: registrar una herramienta remota en la lista permitida local.
- `POST /v1/tools/invoke`: invocar una herramienta habilitada. Para MCP requiere `approved: true` en esa invocación.

### Ejemplo: servidor MCP remoto

```json
{
  "name": "servidor_docs",
  "transport": "streamable_http",
  "url": "https://mcp.example.com/mcp",
  "api_key": "TOKEN_OPCIONAL",
  "timeout": 15
}
```

### Ejemplo: habilitar herramienta descubierta

```json
{
  "server": "servidor_docs",
  "remote_tool": "search_docs",
  "alias": "mcp_search_docs",
  "risk": "high"
}
```

La herramienta no se ejecuta al habilitarla. Cada llamada posterior requiere aprobación explícita:

```json
{
  "name": "mcp_search_docs",
  "arguments": {"query": "documentación SIC"},
  "approved": true
}
```

## Configuración de stdio

Por seguridad, no se permite lanzar cualquier ejecutable desde la API. Añade las rutas absolutas exactas que se consideren confiables a `SIC_MCP_STDIO_ALLOWLIST`, separadas por el separador de rutas del sistema operativo. El comando se ejecuta sin shell y con entorno reducido.

## Límites y seguridad pendientes

- El proceso stdio se separa como subproceso, pero **no es un sandbox del sistema operativo**. Se ejecuta con los permisos del usuario que ejecuta SIC y podría acceder a recursos que ese usuario tenga autorizados. Solo se deben permitir ejecutables confiables. Aislamiento real con contenedores/seccomp/AppContainer queda para una etapa posterior.
- No se implementa OAuth, renovación de tokens ni flujos de autorización MCP; se admite token Bearer estático opcional.
- No se admiten prompts, resources, sampling, elicitation, roots, notificaciones de servidor ni el protocolo moderno draft 2026-07-28.
- La compatibilidad Streamable HTTP cubre la familia `initialize` y protocolo `2025-11-25` / versiones anteriores enumeradas; no se afirma compatibilidad con revisiones draft posteriores.
- Las conexiones y herramientas habilitadas viven en memoria y se pierden al reiniciar SIC.
- No hay auditoría persistente ni interfaz de aprobación; la aprobación se expresa mediante una llamada autenticada a la API.
- Las pruebas HTTP utilizan un servidor MCP simulado local; no se ha validado un servidor externo de producción.

Antes de administrar conexiones MCP o invocar herramientas, configura un token de API de SIC. Por ejemplo, en Linux/macOS:

```bash
export SIC_API_TOKEN="usa-un-token-largo-y-aleatorio"
sic serve
```

En PowerShell:

```powershell
$env:SIC_API_TOKEN="usa-un-token-largo-y-aleatorio"
sic serve
```

Envía `Authorization: Bearer TU_TOKEN` en las solicitudes a los endpoints MCP y a `/v1/tools/invoke`. No publiques ese token ni lo incluyas en capturas o repositorios.
