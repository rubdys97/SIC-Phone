#!/usr/bin/env python3
"""End-to-end smoke test of an installed SIC Core.

Starts `sic serve` as a real subprocess with a simulated Chat Completions model and,
on Linux with bubblewrap, a stdio MCP server running inside the real sandbox. It then
walks the full workflow over HTTP: analysis, memory, MCP, and the approval flow.

    python core/scripts/smoke_e2e.py          # uses whichever sic_core is importable

Exit code 0 only if every check passes.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

API_TOKEN, APPROVER_TOKEN = "a" * 40, "b" * 40
PYTHON_IN_USR = "/usr/bin/python3"
MCP_SERVER = '''import json, sys
for line in sys.stdin:
    msg = json.loads(line); method = msg.get("method")
    if method == "initialize":
        result = {"protocolVersion": "2025-11-25", "capabilities": {}, "serverInfo": {"name": "demo"}}
    elif method == "tools/list":
        result = {"tools": [{"name": "suma", "description": "Suma dos enteros", "inputSchema": {
            "type": "object", "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
            "required": ["a", "b"], "additionalProperties": False}}]}
    elif method == "tools/call":
        args = msg["params"]["arguments"]
        result = {"content": [{"type": "text", "text": str(args["a"] + args["b"])}]}
    else:
        continue
    print(json.dumps({"jsonrpc": "2.0", "id": msg["id"], "result": result}), flush=True)
'''

results: list[tuple[str, bool, str]] = []


def check(name: str, condition: bool, detail: object = "") -> None:
    results.append((name, bool(condition), str(detail)))
    print(f"[{'OK ' if condition else 'FALLA'}] {name}" + (f"  → {detail}" if detail != "" else ""))


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class FakeModel(BaseHTTPRequestHandler):
    calls: list[dict] = []

    def log_message(self, *args):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        FakeModel.calls.append({"auth": self.headers.get("Authorization"), "body": body})
        payload = json.dumps({"choices": [{"message": {"content": f"[modelo simulado, pasada {len(FakeModel.calls)}]"}}]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def main() -> int:
    sandbox_ok = False
    try:
        from sic_core.sandbox import MCPProcessSandbox
        sandbox_ok = sys.platform.startswith("linux") and os.path.isfile(PYTHON_IN_USR) and MCPProcessSandbox().available()[0]
    except Exception as exc:  # pragma: no cover
        print(f"No se pudo importar sic_core: {exc}")
        return 2
    import sic_core
    print(f"SIC Core {sic_core.__version__} desde {Path(sic_core.__file__).parent}")

    model = ThreadingHTTPServer(("127.0.0.1", 0), FakeModel)
    threading.Thread(target=model.serve_forever, daemon=True).start()
    port = free_port()
    with tempfile.TemporaryDirectory() as data:
        mcp_dir = Path(data) / "mcp"
        mcp_dir.mkdir()
        (mcp_dir / "server.py").write_text(MCP_SERVER)
        env = {**os.environ, "SIC_PORT": str(port), "SIC_API_TOKEN": API_TOKEN, "SIC_APPROVAL_TOKEN": APPROVER_TOKEN,
               "SIC_PROVIDER_URL": f"http://127.0.0.1:{model.server_port}/v1/chat/completions", "SIC_MODEL": "modelo-demo",
               "SIC_PROVIDER_API_KEY": "clave-demo", "SIC_DB_PATH": f"{data}/memory.sqlite3",
               "SIC_AUDIT_DB_PATH": f"{data}/audit.sqlite3", "SIC_MCP_STDIO_ALLOWLIST": PYTHON_IN_USR,
               "SIC_MCP_RO_BINDS": str(mcp_dir)}
        server = subprocess.Popen([sys.executable, "-m", "sic_core.cli", "serve"], env=env, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, text=True, cwd=data)

        def call(method, path, body=None, headers=None, token=True):
            merged = {"Content-Type": "application/json", **({"Authorization": f"Bearer {API_TOKEN}"} if token else {}), **(headers or {})}
            request = urllib.request.Request(f"http://127.0.0.1:{port}{path}", method=method, headers=merged,
                                             data=json.dumps(body).encode() if body is not None else None)
            try:
                with urllib.request.urlopen(request, timeout=30) as response:
                    return response.status, json.loads(response.read())
            except urllib.error.HTTPError as exc:
                return exc.code, json.loads(exc.read())

        try:
            for _ in range(60):
                try:
                    call("GET", "/health")
                    break
                except OSError:
                    time.sleep(0.25)
            status, health = call("GET", "/health")
            check("el servidor arranca y responde en /health", status == 200 and health["version"] == sic_core.__version__, health)
            status, caps = call("GET", "/v1/capabilities")
            check("capacidades: motor cognitivo con 3 pasadas", caps.get("cognitive_engine") and caps.get("cognitive_passes") == 3)

            status, _ = call("POST", "/v1/memory", {"content": "Prefiero informes breves", "category": "preference"})
            check("guardar una memoria", status == 201)
            status, analysis = call("POST", "/v1/analyze", {"objective": "Elegir un plan de respaldo", "context": ["tengo 3 sucursales"]})
            check("/v1/analyze completa las 3 pasadas", status == 200 and analysis.get("status") == "cognitive_analysis_received"
                  and len(FakeModel.calls) == 3, analysis.get("status"))
            check("la memoria guardada se recupera como contexto", analysis.get("retrieved_context", {}).get("memory_count") == 1)
            check("la API key llega al proveedor", FakeModel.calls and FakeModel.calls[0]["auth"] == "Bearer clave-demo")

            status, body = call("POST", "/v1/memory", {"content": "web"}, headers={"Content-Type": "text/plain"})
            check("un POST text/plain (CSRF desde un navegador) se rechaza", status == 415, status)
            status, body = call("GET", "/v1/memory", headers={"Host": "evil.example"})
            check("un Host ajeno (DNS rebinding) se rechaza", status == 403, status)

            if not sandbox_ok:
                print("[OMITIDO] flujo MCP: requiere Linux con bubblewrap y espacios de nombres de usuario")
            else:
                server_py = str(mcp_dir / "server.py")
                status, connected = call("POST", "/v1/mcp/connect", {"name": "demo", "transport": "stdio", "command": PYTHON_IN_USR, "args": ["-u", server_py]})
                check("conectar un servidor MCP stdio dentro del sandbox", status == 200 and [t["name"] for t in connected.get("tools", [])] == ["suma"], connected.get("error", ""))
                status, allowed = call("POST", "/v1/mcp/tools/allow", {"server": "demo", "remote_tool": "suma", "alias": "demo_suma", "risk": "high"})
                check("habilitar la herramienta (queda con aprobación obligatoria)", status == 200 and allowed.get("requires_approval"))

                args = {"a": 2, "b": 40}
                status, pending = call("POST", "/v1/tools/invoke", {"name": "demo_suma", "arguments": args})
                check("invocar sin aprobación no ejecuta nada", pending.get("status") == "approval_required")
                status, denied = call("POST", "/v1/tools/approve", {"approval_request_id": pending["approval_request_id"]})
                check("aprobar sin el token del aprobador se rechaza", status == 401, status)
                status, approved = call("POST", "/v1/tools/approve", {"approval_request_id": pending["approval_request_id"]}, headers={"X-SIC-Approval-Token": APPROVER_TOKEN})
                check("aprobar con el token del aprobador", status == 200 and "approval_token" in approved)
                status, wrong = call("POST", "/v1/tools/invoke", {"name": "demo_suma", "arguments": {"a": 2, "b": 41}, "approval_token": approved["approval_token"]})
                check("el token no sirve con argumentos distintos", status == 400, wrong.get("message", "")[:50])

                status, pending = call("POST", "/v1/tools/invoke", {"name": "demo_suma", "arguments": args})
                status, approved = call("POST", "/v1/tools/approve", {"approval_request_id": pending["approval_request_id"]}, headers={"X-SIC-Approval-Token": APPROVER_TOKEN})
                status, done = call("POST", "/v1/tools/invoke", {"name": "demo_suma", "arguments": args, "approval_token": approved["approval_token"]})
                text = done.get("result", {}).get("content", [{}])[0].get("text")
                check("flujo completo: la herramienta corre en el sandbox y devuelve 2+40", status == 200 and done.get("status") == "completed" and text == "42", done.get("message", text))
                status, replay = call("POST", "/v1/tools/invoke", {"name": "demo_suma", "arguments": args, "approval_token": approved["approval_token"]})
                check("un token ya usado no se puede reutilizar", status == 400)
                status, audit = call("GET", "/v1/audit?limit=100")
                check("la auditoría registró los eventos y la cadena es íntegra", status == 200 and audit["integrity"]["valid"] and len(audit["events"]) >= 6, len(audit.get("events", [])))
        finally:
            server.terminate()
            try:
                server.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                server.kill()
            model.shutdown()

    failed = [name for name, ok, _ in results if not ok]
    print(f"\n{len(results) - len(failed)}/{len(results)} comprobaciones correctas" + (f"; FALLARON: {failed}" if failed else ""))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
