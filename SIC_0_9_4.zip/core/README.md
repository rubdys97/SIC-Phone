# SIC Core 0.9.4

Núcleo local en Python (solo biblioteca estándar, Python ≥ 3.11) con tres piezas independientes:

1. **Análisis en tres pasadas** contra cualquier modelo con API *Chat Completions* (OpenAI, Groq, Ollama, etc.).
2. **Memoria y conocimiento persistentes** (SQLite) con recuperación de contexto.
3. **Gateway de herramientas supervisadas**: lista de permitidas, aprobación de un solo uso, auditoría con cadena de hashes y cliente MCP con sandbox.

Qué **no** es, para no esperar de más:

- Las "tres pasadas" son tres prompts encadenados al **mismo** modelo (encuadrar → criticar → decidir). No es verificación independiente y no hay evaluaciones que midan si mejora el resultado frente a un único prompt bien escrito. Cuesta 3× las llamadas.
- `POST /v1/agents/plan` devuelve una plantilla fija de 4 pasos con un especialista elegido por palabras clave. No ejecuta agentes.
- SIC no trae herramientas propias: solo existen las que el anfitrión registra o las que tú habilitas desde un servidor MCP.

## Instalación y arranque

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install sic_core-0.9.4-py3-none-any.whl      # o: pip install ./core
sic serve                                         # http://127.0.0.1:8765
sic prepare "Diseñar una API multiplataforma"     # sin servidor ni modelo
```

Sin modelo configurado, `/v1/analyze` solo devuelve el preprocesado (`prepared_without_model`). Para activar las tres pasadas:

```bash
export SIC_PROVIDER_URL=https://api.groq.com/openai/v1/chat/completions   # o tu proveedor
export SIC_MODEL=<id exacto del modelo>
export SIC_PROVIDER_API_KEY=<clave>
sic serve
```

HTTPS es obligatorio salvo para `localhost`/`127.0.0.1` (modelos locales). Los errores de configuración se muestran como un mensaje (`Error de configuración: …`, código de salida 2), no como traceback.

## Configuración

| Variable | Defecto | Uso |
|---|---|---|
| `SIC_HOST` / `SIC_PORT` | `127.0.0.1` / `8765` | Dirección de escucha |
| `SIC_API_TOKEN` | — | Bearer para administración. **Obligatorio** (≥ 32 caracteres) si `SIC_HOST` no es loopback |
| `SIC_APPROVAL_TOKEN` | — | Token del aprobador, ≥ 32 caracteres y distinto de `SIC_API_TOKEN` |
| `SIC_TRUSTED_PROXY_TLS` | — | `1` para confirmar que un proxy TLS está delante (obligatorio en exposición remota) |
| `SIC_ALLOWED_HOSTS` | — | Nombres `Host` adicionales aceptados, separados por comas |
| `SIC_PROVIDER_URL`, `SIC_MODEL`, `SIC_PROVIDER_API_KEY`, `SIC_PROVIDER_TIMEOUT` | —, —, —, `90` | Modelo de razonamiento |
| `SIC_EMBEDDING_URL`, `SIC_EMBEDDING_MODEL`, `SIC_EMBEDDING_API_KEY`, `SIC_EMBEDDING_TIMEOUT` | —, —, —, `30` | Embeddings opcionales |
| `SIC_DB_PATH` / `SIC_AUDIT_DB_PATH` | `~/.sic/sic_memory.sqlite3` / `~/.sic/audit.sqlite3` | Bases de datos |
| `SIC_RATE_LIMIT_PER_MINUTE` / `SIC_RATE_LIMIT_BURST` | `120` / `30` | Límite por IP de cliente |
| `SIC_MCP_STDIO_ALLOWLIST` | — | Ejecutables exactos permitidos para MCP stdio (separador `:` en Linux) |
| `SIC_MCP_RO_BINDS` | — | Directorios montados de solo lectura dentro del sandbox MCP (ver más abajo) |
| `SIC_LOG_LEVEL` | `INFO` | Nivel de registro |

## API

Todas las peticiones con cuerpo exigen `Content-Type: application/json`.

| Endpoint | Función |
|---|---|
| `GET /health`, `GET /v1/capabilities` | Estado y capacidades reales de esta instancia |
| `POST /v1/prepare` | Preprocesa un objetivo (dominio, supuestos, incógnitas) sin modelo |
| `POST /v1/analyze` | Preprocesa y, si hay modelo, ejecuta las tres pasadas con contexto recuperado |
| `POST /v1/context` | Recupera memorias y conocimiento relevantes para un objetivo |
| `POST`/`GET /v1/memory`, `DELETE /v1/memory/{id}` | Memorias explícitas (nada se guarda automáticamente) |
| `POST`/`GET /v1/knowledge`, `DELETE /v1/knowledge/{id}` | Conocimiento versionado por tema |
| `POST /v1/agents/plan` | Plantilla de plan (ver arriba) |
| `GET /v1/tools`, `POST /v1/tools/invoke`, `POST /v1/tools/approve` | Herramientas supervisadas |
| `POST /v1/mcp/connect`, `GET /v1/mcp/servers`, `GET /v1/mcp/tools`, `POST /v1/mcp/tools/allow` | Cliente MCP |
| `GET /v1/audit` | Eventos recientes y verificación de la cadena de hashes |

Límites: cuerpo ≤ 64 KB, `objective` ≤ 12 000 caracteres, 20 elementos por lista.

## Seguridad

**Servidor.** En loopback sin `SIC_API_TOKEN`, los endpoints de memoria y análisis quedan abiertos a procesos locales; la administración de MCP y de herramientas **siempre** exige `SIC_API_TOKEN`. Frente a páginas web maliciosas: solo se aceptan cabeceras `Host` de loopback (más `SIC_ALLOWED_HOSTS`) para neutralizar DNS rebinding, y los POST deben ser `application/json` para impedir envíos cruzados "simples" desde un navegador. Hay timeout de socket, rate limit por IP, y los errores internos no devuelven detalles. Detrás de un proxy todos los clientes comparten el mismo bucket del rate limit.

**Credenciales de proveedores.** Las llamadas al modelo y a embeddings **no siguen redirecciones**; con ellas `urllib` reenviaba la cabecera `Authorization` al destino.

**Herramientas.** Denegadas por defecto. Las de riesgo medio, alto o crítico (y todas las de MCP) requieren aprobación por invocación:

1. `POST /v1/tools/invoke` → `approval_required` + `approval_request_id`. No se ejecuta nada.
2. `POST /v1/tools/approve` con la cabecera `X-SIC-Approval-Token` (además del Bearer de API) → `approval_token`, válido como máximo 5 minutos desde la solicitud.
3. `POST /v1/tools/invoke` con `approval_token`. El token es de un solo uso y está atado a esa herramienta y esos argumentos exactos.

Cada paso se registra en la auditoría antes de la acción. Si el registro falla, la ejecución no ocurre.

**Auditoría.** Cadena SHA-256 que detecta la edición de eventos existentes. No es a prueba de manipulación: quien pueda reescribir toda la base puede recalcular los hashes, y **borrar los eventos más recientes no se detecta**. Guarda el `head` que devuelve `/v1/audit` en otro sitio si necesitas detectarlo.

### MCP

- **HTTP**: solo `localhost`/IP loopback. MCP HTTPS remoto está **deshabilitado**: el cliente no fija la IP validada al socket, así que no neutraliza DNS rebinding.
- **stdio**: solo Linux con `bubblewrap` y espacios de nombres de usuario disponibles; en cualquier otro caso queda bloqueado. Cada ejecutable debe estar en `SIC_MCP_STDIO_ALLOWLIST`.
  - Dentro del sandbox: sin red (ni DNS ni el loopback del host), `/usr` de solo lectura, sin `/etc` ni `/home`, entorno vacío, solo sus propios procesos, directorio temporal privado, límites de CPU (30 s), memoria (512 MB), archivos (10 MB) y descriptores (32).
  - El ejecutable y sus archivos deben estar bajo `/usr` o bajo un directorio de `SIC_MCP_RO_BINDS` (solo lectura). Se rechazan `/`, `/proc`, `/sys`, `/dev`, tu directorio personal o cualquier ancestro suyo, `~/.ssh`, `~/.gnupg`, `~/.aws`, `~/.kube`, `~/.docker`, `~/.sic` y cualquier directorio que contenga las bases de datos de SIC.
  - Consecuencia: los servidores que necesitan red (la mayoría de los lanzados con `npx`/`uvx`) **no funcionan** ahí, y los runtimes que reservan mucho espacio virtual (Node/V8, JVM) probablemente tampoco por el límite de 512 MB. No hay filtro seccomp.
- Las herramientas descubiertas no se habilitan solas; se registran con riesgo `high` o `critical`. Se rechaza el registro de una herramienta cuyo esquema contenga un `pattern` capaz de backtracking catastrófico (el servidor remoto controla ese esquema).

## Memoria y recuperación

- Memorias: `content`, `category`, `source`, `confidence`, `tags`. Conocimiento: versionado por `topic`; solo se recupera la versión más reciente no rechazada.
- Recuperación **local** (`local_hybrid_v2`, léxico + n-gramas): revisa hasta las 1 000 memorias más recientes y los 1 000 temas más recientes. Es lexical: no entiende significado.
- Recuperación **con embeddings** (si defines `SIC_EMBEDDING_*`): solo ve las 50 memorias y 50 temas más recientes, porque cada petición envía hasta 101 textos y **no hay caché de vectores** (se recalculan en cada análisis). Si el proveedor falla, cae al modo local y lo informa.
- Los conflictos entre memorias son una heurística de negaciones para revisión humana, no contradicciones demostradas.
- Los datos recuperados se pasan al modelo como JSON entre marcadores `<<<DATOS>>>` y se declaran datos, no instrucciones. Eso reduce, no elimina, el riesgo de inyección de prompts.

## Límites conocidos

- `execution_mode: "bounded_autonomy"` se acepta pero no cambia nada: solo existe comportamiento supervisado.
- Validado en Linux con Python 3.12. Windows, macOS, Python 3.11 y 3.13 figuran en el workflow de CI, pero ese CI nunca se ha ejecutado; en Windows/macOS MCP stdio queda bloqueado por diseño.
- Probado contra un servidor Chat Completions simulado, no contra un proveedor real.
- En Ubuntu 24.04 el kernel puede restringir los espacios de nombres de usuario (AppArmor); `bwrap` fallará hasta ajustar `kernel.apparmor_restrict_unprivileged_userns`.
- `app/` (Android) es un cliente mínimo que llama directamente a un endpoint Chat Completions; no usa la API de SIC Core y no se ha compilado ni probado.
- Los documentos `AUDITORIA_*.md` son autoevaluaciones del proyecto, no auditorías independientes.

## Desarrollo

```bash
cd core
python -m unittest discover -s tests -v          # 115 pruebas
SIC_REQUIRE_BWRAP=1 python -m unittest discover -s tests   # falla si el sandbox no es utilizable, en vez de omitir
```

Prueba de humo de una instalación (servidor real, modelo simulado y, en Linux con `bubblewrap`, el flujo MCP + aprobación completo):

```bash
python scripts/smoke_e2e.py        # código de salida 0 solo si pasan todas las comprobaciones
```

Los tests de red usan servidores HTTP locales reales y los del sandbox usan `bubblewrap` real (se omiten si el host no puede crear espacios de nombres). El CI además construye el wheel, lo instala en un entorno limpio y ejecuta la suite contra él.

Historial: `RELEASE_NOTES_*.md`. Novedades de esta versión: [`RELEASE_NOTES_0.9.4.md`](RELEASE_NOTES_0.9.4.md).
