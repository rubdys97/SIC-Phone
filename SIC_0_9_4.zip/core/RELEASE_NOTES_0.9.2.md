# SIC Core 0.9.2 — API rate limiting y cierre preventivo de MCP remoto

**Estado:** candidato técnico de hardening. No es una certificación ni una autorización de despliegue público.

## Cambios

### API — limitación de tasa
- Token bucket por dirección IP cliente, protegido por lock para el servidor multihilo.
- Configuración: `SIC_RATE_LIMIT_PER_MINUTE` (predeterminado 120) y `SIC_RATE_LIMIT_BURST` (predeterminado 30).
- Respuesta HTTP 429 con `Retry-After` y cuerpo JSON estable.
- Tabla de buckets acotada a 10.000 clientes para evitar crecimiento ilimitado de memoria.
- `/health` queda exento para facilitar comprobaciones de disponibilidad.
- Se agregan `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer` y `Cache-Control: no-store` a respuestas JSON normales.

### MCP HTTPS remoto — fail-closed
- Se bloquean todos los endpoints MCP HTTPS no-loopback.
- Motivo: el cliente urllib actual no fija la IP validada a la conexión TLS. Una allowlist y una consulta DNS previa no eliminan la ventana de DNS rebinding.
- `SIC_MCP_HTTP_HOST_ALLOWLIST` no habilita el transporte remoto en 0.9.2. No existe una variable de entorno que permita saltarse este bloqueo.
- HTTP sin TLS continúa limitado a loopback. HTTPS loopback queda permitido.
- MCP stdio permanece bloqueado por defecto salvo la opción insegura de desarrollo heredada; esa opción no es sandbox y no debe usarse con servidores no confiables.

## Pruebas
- Nuevas pruebas del token bucket: ráfaga, refill, aislamiento entre clientes y límite de memoria.
- Prueba HTTP real del endpoint con 429 y `Retry-After`.
- Pruebas de rechazo de HTTPS MCP remoto aunque exista allowlist o variable antigua de opt-in.
- Suite completa: **69/69 pruebas aprobadas** en el entorno de construcción. `compileall` completado sin errores. Los detalles se registran en `AUDITORIA_0.9.2.md`.

## Límites que siguen abiertos
- No hay sandbox OS real integrado a MCP stdio.
- No hay transporte MCP remoto con pinning de IP en el socket, validación TLS/SNI y defensa DNS rebinding integral.
- Rate limiting en memoria: se reinicia con el proceso y no coordina varias réplicas. La IP de cliente solo es fiable si la topología de proxy está controlada; SIC no confía en `X-Forwarded-For`.
- No hay scopes de autorización granulares, identidad federada ni rotación automática de tokens.
- TLS remoto de la API sigue dependiendo de un proxy externo; el flag de proxy no prueba su configuración.
- No se ha compilado Android ni ejecutado una matriz real Windows/macOS en este entorno.
- No hay benchmark de calidad cognitiva, coste o latencia.

## Configuración de límites

```bash
SIC_RATE_LIMIT_PER_MINUTE=120
SIC_RATE_LIMIT_BURST=30
```

Para pruebas de integración se pueden usar valores pequeños, por ejemplo `SIC_RATE_LIMIT_PER_MINUTE=60` y `SIC_RATE_LIMIT_BURST=2`.
