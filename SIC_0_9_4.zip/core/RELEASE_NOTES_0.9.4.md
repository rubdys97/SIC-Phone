# SIC Core 0.9.4

Revisión de código línea por línea más validación real del sandbox. Cada defecto de esta lista se **reprodujo contra 0.9.3** antes de corregirse y tiene una prueba de regresión que falla en 0.9.3 y pasa aquí (`tests/test_hardening_094.py`), salvo donde se indica.

## El hallazgo más importante: MCP stdio nunca funcionó a través de la API HTTP

En 0.9.3 (y antes) un servidor MCP stdio conectado con `POST /v1/mcp/connect` moría en cuanto terminaba esa petición, y toda llamada posterior fallaba con `El proceso MCP no está activo` (`returncode -9`). `--die-with-parent` de bubblewrap es `PR_SET_PDEATHSIG`, que Linux asocia al **hilo** que hizo el fork, y cada petición HTTP corre en un hilo efímero. Ningún test lo detectaba porque todos conectaban y llamaban desde un hilo que seguía vivo; apareció al ejecutar el flujo completo con el CLI real. Ahora los procesos MCP se crean siempre desde un hilo estable (`_StableThreadSpawner`), y un test verifica que siguen muriendo si SIC muere. Aprovechando el cambio se sacó el `import resource` del `preexec_fn` (importar entre fork y exec puede bloquear un proceso con hilos).

## Validado por primera vez

- El sandbox `bubblewrap` de MCP stdio nunca se había ejecutado (el entorno de 0.9.3 no tenía `bwrap`). Ahora corre de extremo a extremo: el test e2e de stdio que se omitía pasa, y un proceso hostil dentro del sandbox no alcanza la red (internet, DNS ni un servicio en el loopback del host), no lee `/etc` ni `/home`, no escribe en `/usr`, no ve procesos del host y recibe un entorno vacío.
- La suite se ejecuta contra el wheel instalado en un entorno limpio, no solo contra el árbol de fuentes.
- `core/scripts/smoke_e2e.py` arranca `sic serve` real con un modelo simulado y recorre el flujo completo por HTTP (análisis, memoria, MCP en sandbox, aprobación de un solo uso, auditoría): 17 comprobaciones.

## Seguridad

- **La API key se filtraba en redirecciones.** Con respuestas 301/302/303 el cliente de modelo y el de embeddings seguían el redirect y reenviaban `Authorization` al destino. Ya no se siguen redirecciones.
- **Páginas web podían escribir en un SIC local.** Cualquier sitio podía hacer `POST` con `Content-Type: text/plain` a `127.0.0.1:8765` (sin preflight) y escribir memoria; con DNS rebinding podía además leer. Ahora se valida la cabecera `Host` (loopback + `SIC_ALLOWED_HOSTS`) y los POST deben ser `application/json`.
- **Denegación de servicio por esquemas MCP.** El servidor remoto controla el `pattern` de un esquema; con `(a+)+$` bastaban 26 caracteres para bloquear 4 s un hilo, duplicándose por cada carácter extra. Los patrones se filtran (sin grupos cuantificados, referencias inversas ni lookaround; pocos cuantificadores) y la entrada comprobada se limita a 512 caracteres. `allow_tool` rechaza esquemas con patrones no seguros.
- Sin timeout de socket: un cliente que se quedaba colgado retenía un hilo para siempre. Ahora 30 s.
- Los errores internos devolvían `str(exc)` (rutas, SQL). Ahora respuesta genérica 500 y detalle solo en el registro; los fallos del proveedor se informan como 502 `provider_error`.
- Solo el literal `localhost` y las IP loopback cuentan como loopback para MCP HTTP (`*.localhost` se resuelve por DNS en algunos sistemas). *Endurecimiento sin exploit demostrado.*
- El cliente MCP HTTP ignora los proxies del entorno (solo habla con loopback).

## Correcciones

- **Auditoría:** cada evento dejaba una conexión SQLite abierta (+66 descriptores tras 300 eventos). `verify()` ahora recorre las filas en streaming.
- **Recuperación de memoria:** solo consideraba las 50 memorias más recientes, y para conocimiento ordenaba por tema alfabético con límite 50 (incluyendo versiones antiguas), de modo que con 121 temas el último nunca se recuperaba. Ahora el modo local revisa hasta 1 000 elementos y solo versiones vigentes. Con embeddings sigue limitado a 50+50 (máximo de 101 textos por petición).
- **Orden por recencia no determinista:** `created_at` tiene resolución de 1 s, por lo que registros del mismo segundo empataban y se devolvían los más antiguos primero. Ahora se desempata por orden de inserción.
- **Búsqueda con `%` o `_`** actuaba como comodín; ahora es literal.
- **Clasificación de dominio por subcadenas:** "capital" contaba como `api` (ingeniería de software) y "ingredientes"/"predecir" como `red` (ciberseguridad). Ahora coincide por palabra completa o prefijo, sin acentos ni mayúsculas. Lo mismo en el orquestador de agentes.
- **MCP SSE:** con eventos delimitados por CRLF y más de un evento por respuesta (p. ej. progreso + resultado) se fusionaban en un JSON inválido.
- **MCP `connect`** mantenía el bloqueo global durante toda la conexión de red (`list_servers()` tardó 1.3 s bloqueado con un servidor lento). Ahora reserva el nombre y conecta fuera del bloqueo.
- `_StdioSession.close()` no cerraba las tuberías del proceso. Las llamadas `tools/call` de un mismo cliente se serializan (el candado existía pero no se usaba). `DELETE` y `GET` ya no cortan la conexión ante errores inesperados.
- El contexto y la solicitud llegaban al modelo serializados con `repr()` de Python, sin frontera entre instrucciones y datos del usuario; ahora van como JSON entre marcadores `<<<DATOS>>>`.

## Añadido

- `SIC_MCP_RO_BINDS`: directorios de solo lectura visibles dentro del sandbox MCP. Sin esto, un servidor stdio solo podía ejecutar código inline (`-c`) o que residiera en `/usr`. Validación estricta (ver README).
- `SIC_ALLOWED_HOSTS`, `Cross-Origin-Resource-Policy: same-origin`.
- Errores de configuración legibles (`Error de configuración: …`, salida 2) y resumen de modelo al arrancar.
- CI: instala `bubblewrap`, `SIC_REQUIRE_BWRAP=1` convierte la omisión silenciosa de los tests de sandbox en fallo, y un job nuevo prueba el wheel instalado.

## Tests

73 → 115 pruebas (42 nuevas; una de ellas es la compuerta de CI `SIC_REQUIRE_BWRAP`, que se omite fuera del CI). Los tests de red usan servidores HTTP locales reales (`tests/helpers.py`) en vez de parchear `urllib`. Se corrigió un test no hermético que fallaba en cualquier máquina con `bwrap` instalado.

## No hecho

- MCP HTTPS remoto sigue deshabilitado: requiere un transporte que fije la IP validada al socket, y no se implementó código de seguridad sin poder probarlo de extremo a extremo.
- Sin caché de embeddings; la auditoría no detecta el borrado de los eventos más recientes; sin filtro seccomp en el sandbox; rate limit por proceso.
- No se validó con un proveedor real, en Windows/macOS, con Python 3.11/3.13, ni el módulo Android.
- No se evaluó si las tres pasadas mejoran el resultado frente a un prompt único.
