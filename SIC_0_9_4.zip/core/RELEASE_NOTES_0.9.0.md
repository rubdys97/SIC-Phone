# SIC Core 0.9.0 — Etapa 8

## Objetivo
Fortalecer la ejecución de herramientas mediante auditoría persistente, límites de procesos locales y terminación controlada de procesos MCP stdio.

## Cambios
- Nuevo `AuditLog` SQLite con encadenamiento SHA-256, verificación de integridad y consulta paginada (máximo 500 eventos).
- `ToolRegistry` registra aprobación requerida, ejecución completada, fallo y herramienta desconocida. Los argumentos no se guardan en claro; se conserva SHA-256.
- Nuevo `ProcessSandbox`: ejecutables exactos en allowlist, sin shell, directorio temporal, entorno mínimo, timeout, límites POSIX best-effort para CPU, memoria virtual, tamaño de archivo y descriptores.
- Procesos MCP stdio: directorio temporal, límites POSIX best-effort y terminación del grupo de procesos al agotar timeout.
- Endpoint autenticado `GET /v1/audit?limit=100` con eventos y verificación de cadena.
- Variables `SIC_AUDIT_DB_PATH` (por defecto `~/.sic/audit.sqlite3`).

## Seguridad y límites conocidos
- Los límites POSIX son defensa en profundidad; en Windows no se aplica Job Object en esta versión.
- No existe aislamiento de red, namespaces, seccomp, AppContainer ni sandbox de kernel. `network_isolation` permanece `false`.
- MCP remoto se ejecuta en el proceso SIC y depende de TLS, permisos, timeout y aprobación; no es un entorno aislado.
- El hash chain detecta modificaciones, inserciones o reordenamientos respecto a la cadena existente, pero no es resistente a un atacante con control de escritura sobre la base de datos que pueda reconstruir toda la cadena. Para evidencia fuerte se requiere exportación/firmado externo o almacenamiento WORM.
- El `ProcessSandbox` es una API de ejecución explícita; no se conectan herramientas de shell ni se habilita ejecución arbitraria por defecto.
- No se guardan valores de argumentos, claves API ni resultados completos en el registro de auditoría.
- Las pruebas locales no sustituyen pruebas en Windows, Android ni servidores MCP externos de producción.
