# SIC Core 0.9.3 — aislamiento MCP stdio fail-closed

**Estado:** hardening parcial. No es una certificación ni autoriza despliegue público.

## Cambios

### MCP stdio — backend Linux bubblewrap
- Se incorpora `MCPProcessSandbox`, un lanzador Linux que exige `bubblewrap` y una prueba real de creación de namespaces antes de habilitar stdio.
- El proceso se inicia con namespaces aislados (`--unshare-all`), namespace de red separado, `--die-with-parent`, sesión nueva, runtime `/usr` de solo lectura y un directorio temporal privado como única ruta de escritura.
- El entorno heredado se elimina (`--clearenv`); solo se entrega PATH, HOME temporal y LANG.
- Los límites POSIX de CPU, memoria virtual, tamaño de archivo, descriptores y core dumps se aplican antes del `exec`. Si no pueden aplicarse, el lanzamiento falla.
- El cierre y los timeouts terminan el grupo de procesos completo, no solo el proceso líder.
- El ejecutable debe estar dentro de `/usr` para que exista dentro del namespace.
- Windows y macOS siguen bloqueados: no se finge compatibilidad ni se utiliza un modo alternativo inseguro.

### Frontera de autorización
- `MCPClient` ya no permite crear directamente una conexión stdio. La creación pasa por `MCPManager`, que exige ruta exacta en allowlist y sandbox verificado.
- `SIC_MCP_STDIO_UNSAFE_DEV=1` deja de tener efecto. La antigua vía de escape queda retirada.
- `/v1/capabilities` informa si bubblewrap pudo verificarse, qué transportes están disponibles y si stdio está realmente habilitado.

## Verificación ejecutada

Entorno: Linux, Python 3.13.5. En este contenedor **bubblewrap no está instalado**, por lo que el backend real se mantiene bloqueado.

- `python -m compileall -q sic_core tests`: correcto.
- `python -m unittest discover -s tests -v`: **72 aprobadas, 1 omitida** (prueba end-to-end stdio omitida porque el host no dispone de bubblewrap).
- Pruebas unitarias verifican construcción del comando bubblewrap, namespaces, ausencia de entorno heredado, rechazo de bypass inseguro, control de allowlist y reporte de capacidades.

## Límites abiertos

- El backend bubblewrap está implementado, pero no fue ejecutado end-to-end en este entorno porque no está instalado. Requiere validación en una máquina Linux con user namespaces habilitados y bubblewrap instalado.
- No existe backend equivalente para Windows (Job Objects/AppContainer) ni macOS (sandbox-exec u otro mecanismo mantenido). En ambos sistemas stdio permanece deshabilitado.
- MCP HTTPS remoto continúa bloqueado hasta implementar pinning de IP real al socket, SNI y validación TLS integral.
- El rate limiter continúa en memoria y no coordina múltiples réplicas.
- No se ha ejecutado GitHub Actions, Android Gradle, fuzzing, prueba de penetración ni prueba de carga.

## Dictamen

**Mejora de seguridad parcial verificada por pruebas unitarias; no apto para producción.** En el entorno actual, MCP stdio continúa deshabilitado de forma efectiva. La disponibilidad futura de stdio dependerá de que la prueba de namespaces bubblewrap pase en el host donde se ejecute SIC y de que el ejecutable esté incluido en la allowlist exacta.
