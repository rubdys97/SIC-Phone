# SIC 0.9.2 — Auditoría de cambios y verificación

## Alcance

Esta iteración prioriza protección de la API y reducción del riesgo SSRF/DNS rebinding. No implementa sandbox OS ni declara apto el sistema para producción.

## Hallazgos tratados

| Área | Cambio | Evidencia |
|---|---|---|
| API sin límite de solicitudes | Token bucket por IP, thread-safe y acotado | `tests/test_rate_limit.py`; prueba HTTP 429 en `tests/test_api_memory.py` |
| Respuestas HTTP sin cabeceras defensivas | Cabeceras anti-sniffing, anti-frame, no-referrer y no-store | Prueba de integración API |
| DNS rebinding MCP | Se bloquea por completo MCP HTTPS remoto hasta disponer de pinning real al socket | `test_remote_mcp_https_is_fail_closed_until_socket_ip_pinning_exists` |
| Configuración de tasa no validada | Constructor rechaza límites no positivos | `test_invalid_limits_rejected` |

## Diseño del rate limiter

- Token bucket en memoria por IP de conexión.
- Capacidad y tasa configurables.
- Lock compartido entre workers del `ThreadingHTTPServer`.
- LRU acotado a 10.000 entradas.
- Respuesta 429 con `Retry-After`.
- No se utiliza `X-Forwarded-For`, evitando confiar ciegamente en una cabecera manipulable.

## Verificación ejecutada

Se documentarán aquí únicamente resultados de ejecución efectiva del entorno de construcción. La suite cubre comportamiento unitario y una prueba HTTP local. No equivale a una prueba de penetración ni a una matriz multiplataforma.

## Resultado efectivo del entorno de construcción

- `python -m unittest discover -s tests -v`: **69/69 aprobadas**.
- `python -m compileall -q sic_core tests`: completado sin errores.
- Entorno de ejecución: Linux, Python 3.13.5.
- Se ejecutaron pruebas HTTP locales reales contra `ThreadingHTTPServer`, incluyendo 429, `Retry-After` y cabeceras.
- Se probaron escenarios de DNS rebinding de forma fail-closed: los hosts HTTPS no-loopback se rechazan antes de abrir conexión, incluso si se establece la allowlist o una variable antigua de opt-in.

## Pendiente de ejecución externa

- El workflow GitHub Actions está creado para 3 sistemas operativos × 3 versiones Python, pero no se ha ejecutado desde este entorno. No se afirma compatibilidad validada con Windows/macOS.
- No se ha compilado ni probado la app Android.
- No se ha ejecutado fuzzing, prueba de penetración, prueba de carga ni proxy TLS real.
- No se ha integrado sandbox OS para MCP stdio.

## Dictamen

**Mejora de seguridad parcial verificada en entorno Linux; no apto para producción ni exposición pública.** El cierre temporal de MCP HTTPS remoto reduce funcionalidad a cambio de eliminar la ventana conocida de DNS rebinding en este cliente. Para reactivar MCP remoto se necesita implementar un transporte que conecte directamente a una IP previamente validada, mantenga SNI y validación de certificado contra el hostname original, controle redirects y revalide cada conexión.
