# SIC 0.9.1 — Informe de remediación y verificación

**Fecha:** 8 de noviembre de 2026  
**Base revisada:** SIC 0.9.0 Etapa 8 y auditoría integral previa.  
**Resultado:** 63 pruebas automatizadas aprobadas; compilación sintáctica correcta. No equivale a certificación de seguridad ni a validación en dispositivos/OS externos.

## Hallazgos corregidos y pruebas de evidencia

| Hallazgo | Cambio | Evidencia ejecutada |
|---|---|---|
| A-01 auditoría multiproceso | `BEGIN IMMEDIATE` serializa lectura del head + cálculo + inserción | 4 procesos × 30 eventos; 120 eventos verificados, cadena válida |
| A-02 aprobación booleana | Solicitud separada, token aleatorio de un uso, TTL 5 min, vinculado a herramienta/argumentos/llamada | Prueba unitaria y prueba HTTP; booleano legado rechazado; reutilización/cambio de argumentos rechazados |
| A-03 SSRF MCP | Host exacto allowlist, DNS/IP global verificado, HTTP solo loopback, redirecciones deshabilitadas | DNS simulado público aceptado; IP privada rechazada; host sin allowlist rechazado |
| A-07 esquema JSON | Validador recursivo acotado y conectado a herramientas registradas | Tipos, enum, límites numéricos, objetos anidados, required y additionalProperties probados |
| A-08 cola stdio | Cola de lectura limitada a 128 mensajes | Revisión estática y pruebas de transporte existentes |
| A-09 exposición API | Inicio remoto falla cerrado sin secretos fuertes distintos y declaración de proxy TLS | Revisión estática; no se desplegó proxy TLS real |
| A-10 versionado | Transacción inmediata + índice único topic/version + migración de duplicados | 4 procesos × 20 escrituras; versiones 1–80 únicas; migración legacy probada |
| A-11 permisos | Permisos 0600 best-effort para DB/WAL/SHM | Revisión de código; ACL de Windows no probadas |
| A-04/A-05 stdio sin sandbox OS | MCP stdio bloqueado por defecto; opt-in solo de desarrollo inseguro | Prueba de bloqueo por defecto aunque exista allowlist |

## Resultado de pruebas

Comando ejecutado desde `core/`:

```bash
python -m unittest discover -s tests -v
python -m compileall -q sic_core tests
```

**63/63 pruebas aprobadas.** Incluye las pruebas anteriores y nuevas pruebas de multiproceso, migración, aprobación por endpoint, validación de argumentos y bloqueo de stdio.

## Cambios de configuración importantes

- `SIC_APPROVAL_TOKEN`: obligatorio para aprobar, mínimo 32 caracteres y distinto de `SIC_API_TOKEN`.
- `SIC_MCP_HTTP_HOST_ALLOWLIST`: hosts MCP HTTPS exactos, separados por comas.
- `SIC_MCP_STDIO_UNSAFE_DEV=1`: opt-in explícito solo para desarrollo; no proporciona sandbox.
- `SIC_TRUSTED_PROXY_TLS=1`: declaración de operador de que el tráfico remoto entra por proxy TLS confiable.
- `SIC_API_TOKEN`: mínimo 32 caracteres cuando `SIC_HOST` no es loopback.

## Riesgos abiertos: no declarar resueltos

1. DNS rebinding: SIC valida DNS, pero no fija la IP validada en el socket. La política de egreso del host debe restringir red; se necesita pinning de conexión para cerrar completamente este vector.
2. MCP stdio: no hay sandbox de kernel/contenedor/VM conectado al gestor. Por eso está bloqueado por defecto.
3. TLS: SIC no implementa TLS nativo. `SIC_TRUSTED_PROXY_TLS=1` es una confirmación de configuración externa, no una prueba automática del proxy.
4. API: no hay scopes completos, rotación de tokens integrada ni rate limiting general.
5. Aprobaciones: almacenamiento volátil; no hay identidad federada multiusuario ni persistencia tras reinicio.
6. Android: no se compiló ni conectó el cliente al backend en esta etapa.
7. Matriz de plataformas: no se probaron Windows/macOS reales.
8. Seguridad del host: `ProcessSandbox` sigue sin aislamiento de red/kernel y no es ruta de ejecución de MCP.
9. Integridad: hash chain no protege frente a administrador hostil capaz de reescribir DB completa.
10. Inteligencia: no hay benchmark reproducible de razonamiento, calibración, latencia y coste.

## Dictamen

SIC 0.9.1 corrige dos defectos críticos reproducibles y endurece aprobaciones, validación y superficie MCP/API. Sigue siendo un prototipo técnico supervisado. No exponerlo a Internet ni ejecutar servidores MCP no confiables hasta cerrar los riesgos abiertos y validar el despliegue real.
