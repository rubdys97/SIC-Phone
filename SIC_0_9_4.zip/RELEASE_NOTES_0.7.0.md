# SIC Core 0.7.0 — Etapa 6

## Incorporado
- Orquestador central con selección inicial de especialista por dominio.
- Planes explícitos con dependencias y agente de validación.
- Registro de herramientas basado en allowlist; inicia vacío.
- Política deny-by-default y aprobación por invocación para riesgos medios, altos y críticos.
- API `POST /v1/agents/plan`, `GET /v1/tools` y `POST /v1/tools/invoke`.
- Manejo de errores de herramientas sin ocultar fallos.

## Límites
- Los agentes son roles lógicos, no agentes autónomos paralelos.
- No se ejecutan comandos de sistema ni herramientas arbitrarias.
- MCP remoto no está conectado; se reserva la frontera para una etapa posterior.
- La aprobación HTTP `approved: true` solo es segura detrás de un canal autenticado y una interfaz de autorización confiable. El endpoint hereda la autenticación SIC.

## Verificación
- Pruebas unitarias de planificación, allowlist, aprobación, ejecución y fallos.
