# SIC

SIC (Strategic Intelligence Core) es un núcleo local en Python, sin dependencias externas, que combina análisis en tres pasadas contra un modelo de lenguaje, memoria persistente con recuperación de contexto y un gateway de herramientas supervisadas (aprobación de un solo uso, auditoría y cliente MCP con sandbox).

- **`core/`**: el paquete `sic_core` (versión 0.9.4), tests y documentación. **Empieza por [`core/README.md`](core/README.md)**: instalación, configuración, API, modelo de seguridad y límites conocidos.
- **`app/`**: cliente Android mínimo que llama directamente a un endpoint Chat Completions. No usa la API de SIC Core y no se ha compilado ni probado.
- **`.github/workflows/`**: CI del núcleo (con prueba del wheel instalado) y construcción del APK.

## Inicio rápido

```bash
cd core
python3 -m venv .venv && source .venv/bin/activate && pip install .
export SIC_PROVIDER_URL=https://TU-PROVEEDOR/v1/chat/completions SIC_MODEL=ID_DEL_MODELO SIC_PROVIDER_API_KEY=TU_CLAVE
sic serve
curl -s -X POST http://127.0.0.1:8765/v1/analyze -H 'Content-Type: application/json' \
  -d '{"objective":"Diseñar una arquitectura multiplataforma"}'
```

## Estado

Novedades y lo que sigue sin hacerse: [`core/RELEASE_NOTES_0.9.4.md`](core/RELEASE_NOTES_0.9.4.md). Los `AUDITORIA_*.md` y `RELEASE_NOTES_0.4`–`0.7` son historial del proyecto; las auditorías son autoevaluaciones, no revisiones independientes.
