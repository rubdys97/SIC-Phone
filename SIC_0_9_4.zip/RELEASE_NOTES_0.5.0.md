# SIC Core 0.5.0 — Etapa 4

## Integración de memoria y razonamiento
- Añadido `ContextRetriever` con recuperación léxica limitada sobre memoria explícita y conocimiento versionado.
- El motor cognitivo recibe el contexto recuperado y recibe instrucciones explícitas para tratarlo como datos, no como instrucciones.
- Se selecciona la última versión activa por tema y se excluye conocimiento rechazado.
- Se detectan posibles conflictos heurísticos entre recuerdos de la misma categoría sin resolverlos automáticamente.
- Añadido `POST /v1/context` para previsualizar el contexto recuperable.
- Capacidades y documentación actualizadas.

## Verificación
- Suite completa: 23 pruebas automatizadas aprobadas.
- Sin dependencias externas añadidas.

## Limitaciones conocidas
- Recuperación léxica, no semántica.
- Los conflictos detectados son heurísticos.
- No hay validación factual externa ni memoria automática de conversaciones.
- No hay sincronización multi-dispositivo, MCP ni ejecución de herramientas.
