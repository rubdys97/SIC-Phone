# SIC 0.9.3 — Auditoría de hardening

## Alcance

Se revisó la ruta MCP stdio heredada de SIC 0.9.2. El riesgo principal era que la ejecución de procesos se encontraba bloqueada en el gestor, pero la clase de bajo nivel podía crear procesos directamente y la opción `SIC_MCP_STDIO_UNSAFE_DEV=1` seguía siendo un bypass documentado.

## Hallazgos y remediación

| ID | Hallazgo | Cambio 0.9.3 | Estado |
|---|---|---|---|
| S93-01 | No existía sandbox OS conectado al transporte stdio | Backend Linux bubblewrap con namespaces, red aislada, runtime RO y workspace temporal | Implementado; host actual no tiene bwrap |
| S93-02 | `MCPClient` podía iniciar stdio fuera del gestor | Token interno de construcción; el gestor es la única ruta autorizada | Corregido y probado |
| S93-03 | Variable de desarrollo permitía eludir bloqueo | `SIC_MCP_STDIO_UNSAFE_DEV` deja de habilitar ejecución | Corregido y probado |
| S93-04 | Capacidades podían declarar stdio por variable, no por capacidad real | Endpoint consulta el resultado de la prueba de sandbox | Corregido y probado |
| S93-05 | Límites POSIX fallaban silenciosamente | Los límites son obligatorios en el backend Linux; fallo de `setrlimit` aborta el spawn | Corregido en el camino Linux |
| S93-06 | Cierre podía terminar solo el proceso líder | Se envía SIGKILL al grupo incluso si el líder ya terminó | Corregido; pendiente prueba con proceso descendiente real dentro de bwrap |

## Diseño de aislamiento Linux

La línea de lanzamiento usa bubblewrap con:
- `--unshare-all` para separar namespaces, incluido el de red.
- `--die-with-parent` y `--new-session`.
- `/usr` y runtimes asociados montados en solo lectura.
- `/proc` y `/dev` propios del namespace.
- `/tmp` nuevo y un único directorio temporal de trabajo montado como escritura.
- `--clearenv` y un conjunto mínimo de variables.
- Límites `RLIMIT_CPU`, `RLIMIT_AS`, `RLIMIT_FSIZE`, `RLIMIT_NOFILE` y `RLIMIT_CORE`.

El backend solo acepta ejecutables resueltos dentro de `/usr`. No monta `/home`, `/root`, `/mnt`, `/media`, `/run`, ni el filesystem raíz completo. Si bubblewrap no existe, si user namespaces están deshabilitados o si falla la prueba real, stdio queda bloqueado.

## Evidencia

- Entorno: Linux x86_64, Python 3.13.5.
- `bwrap`: no instalado. La prueba de capacidad retorna no disponible; esto es el resultado esperado fail-closed.
- `python -m compileall -q sic_core tests`: correcto.
- `python -m unittest discover -s tests -v`: **72 aprobadas, 1 omitida**.
- La prueba omitida es la integración stdio end-to-end, que requiere bubblewrap real.
- El ZIP fue comprobado con `unzip -t`; el wheel se construyó sin dependencias de runtime adicionales.

## Riesgos residuales

1. No se ha ejecutado el backend bubblewrap en un host que lo tenga instalado. Las pruebas de construcción del comando no equivalen a una prueba de aislamiento efectiva.
2. No hay backend de sandbox para Windows/macOS.
3. El aislamiento de red de MCP HTTPS remoto sigue cerrado; no se ha implementado pinning de IP al socket.
4. El rate limiting es local al proceso.
5. No hay identidad federada, scopes completos ni rotación automatizada de credenciales.
6. No se han ejecutado pruebas de penetración, fuzzing, carga, CI remota o Android.

## Dictamen

**No apto para producción.** La vía stdio es fail-closed en el entorno auditado y el bypass inseguro fue retirado. El backend Linux queda listo para validación real en un host con bubblewrap; hasta entonces no se afirma que el aislamiento esté probado.
