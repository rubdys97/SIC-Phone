# SIC Core 0.4.0 — Etapa 3

## Entrega
- Memoria explícita persistente en SQLite.
- Base de conocimiento con historial de versiones y referencias de fuente.
- API autenticable para crear, consultar y eliminar registros.
- Configuración del archivo de base mediante `SIC_DB_PATH`.
- Pruebas unitarias e integración HTTP.

## Verificación local
- `python -W error::ResourceWarning -m unittest discover -s tests -v`
- Resultado: 18 pruebas aprobadas.
- Compilación sintáctica de todos los módulos Python: aprobada.

## No incluido
- Extracción automática desde conversaciones.
- Memoria semántica/vectorial o embeddings.
- Sincronización entre dispositivos.
- Cifrado propio en reposo.
- Integración del almacén con el motor cognitivo.
- Integración del cliente Android con la API nueva.

La etapa 3 entrega el almacenamiento y sus contratos. No afirma capacidades que todavía no están implementadas.
