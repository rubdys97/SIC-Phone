package com.sic.mobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("sic_settings", MODE_PRIVATE) }

    private lateinit var endpointInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var promptInput: EditText
    private lateinit var transcript: TextView
    private lateinit var status: TextView
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(24))
            setBackgroundColor(0xFF0B1220.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "SIC"
            textSize = 34f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(0xFFF8FAFC.toInt())
        }
        page.addView(brand)
        page.addView(label("STRATEGIC INTELLIGENCE CORE  •  ANDROID 0.1"))
        page.addView(label("Núcleo local de planificación + modelo remoto configurable."))

        page.addView(section("CONEXIÓN HÍBRIDA"))
        endpointInput = field("URL completa del endpoint /chat/completions").also {
            it.setText(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions"))
            page.addView(it)
        }
        modelInput = field("Identificador exacto del modelo").also {
            it.setText(prefs.getString("model", ""))
            page.addView(it)
        }
        keyInput = field("API key (solo en memoria; no se guarda)").also {
            it.inputType = 129
            page.addView(it)
        }
        val save = button("Guardar URL y modelo")
        save.setOnClickListener {
            prefs.edit()
                .putString("endpoint", endpointInput.text.toString().trim())
                .putString("model", modelInput.text.toString().trim())
                .apply()
            status.text = "Configuración guardada. La API key no se almacena."
        }
        page.addView(save)

        page.addView(section("CONSOLA SIC"))
        transcript = TextView(this).apply {
            text = "SIC v0.1 listo.\nConfigura un proveedor compatible con Chat Completions para iniciar."
            textSize = 14f
            setTextColor(0xFFE2E8F0.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFF172033.toInt())
        }
        page.addView(transcript, LinearLayout.LayoutParams(-1, dp(250)))

        promptInput = field("Describe el objetivo, problema o investigación...")
        promptInput.minLines = 3
        promptInput.gravity = Gravity.TOP
        page.addView(promptInput)

        sendButton = button("Analizar con SIC")
        sendButton.setOnClickListener { submit() }
        page.addView(sendButton)

        status = label("Estado: esperando instrucciones.")
        page.addView(status)

        page.addView(section("CRITERIO OPERATIVO"))
        page.addView(label(
            "SIC convierte la intención en un plan verificable. No ejecuta comandos ni controla " +
            "el dispositivo en esta versión. Para ciberseguridad, limita el análisis a sistemas " +
            "propios, laboratorios o activos con autorización."
        ))
    }

    private fun submit() {
        val prompt = promptInput.text.toString().trim()
        val endpoint = endpointInput.text.toString().trim()
        val model = modelInput.text.toString().trim()
        val apiKey = keyInput.text.toString().trim()

        if (prompt.isBlank()) {
            status.text = "Escribe una solicitud primero."
            return
        }
        if (!endpoint.startsWith("https://") || !endpoint.endsWith("/chat/completions")) {
            status.text = "Introduce un endpoint HTTPS compatible que termine en /chat/completions."
            return
        }
        if (model.isBlank() || apiKey.isBlank()) {
            status.text = "Falta el identificador del modelo o la API key."
            return
        }

        hideKeyboard()
        val compiled = compileIntent(prompt)
        append("\n\nTÚ\n$prompt\n\nSIC · BRIEF LOCAL\n$compiled\n\nSIC · ANÁLISIS REMOTO\nProcesando...")
        status.text = "Estado: razonamiento en curso."
        sendButton.isEnabled = false

        executor.execute {
            try {
                val answer = callModel(endpoint, model, apiKey, prompt, compiled)
                runOnUiThread {
                    append("\n\nSIC\n$answer")
                    status.text = "Estado: análisis recibido."
                    sendButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    append("\n\nSIC · ERROR\n${e.message ?: "No se pudo completar la solicitud."}")
                    status.text = "Estado: error de conexión."
                    sendButton.isEnabled = true
                }
            }
        }
    }

    // Local deterministic intent framing: the remote model performs the substantive reasoning.
    private fun compileIntent(userText: String): String {
        val t = userText.lowercase()
        val domain = when {
            listOf("cve", "vulnerabilidad", "exploit", "pentest", "seguridad", "firmware", "apk").any { t.contains(it) } ->
                "Ciberseguridad / investigación técnica"
            listOf("código", "programa", "software", "aplicación", "bug").any { t.contains(it) } ->
                "Ingeniería de software"
            else -> "Análisis general / planificación"
        }
        val needsScope = domain.startsWith("Ciberseguridad")
        return buildString {
            appendLine("Dominio detectado: $domain")
            appendLine("Tarea: interpretar el objetivo, separar hechos de supuestos y proponer un plan por etapas.")
            appendLine("Calidad: priorizar precisión, evidencia, criterios de éxito y reconocimiento explícito de incertidumbre.")
            if (needsScope) appendLine("Control: confirmar autorización y alcance antes de cualquier prueba activa.")
            append("Salida: objetivo, contexto, hipótesis, estrategia, pasos, herramientas, restricciones, validación y siguiente decisión.")
        }
    }

    private fun callModel(endpoint: String, model: String, apiKey: String, userText: String, brief: String): String {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }

        val system = """
            Eres SIC (Strategic Intelligence Core), un núcleo especializado en razonamiento,
            análisis y planificación. Tu prioridad es la calidad del razonamiento: precisión,
            pensamiento crítico, hipótesis contrastables, eficiencia y verificación.
            No afirmes haber ejecutado acciones ni observado la pantalla. No inventes datos,
            herramientas, resultados ni capacidades. Si falta contexto, identifica exactamente
            qué falta. Distingue hechos, inferencias y dudas.
            Para ciberseguridad, trabaja en sistemas propios, laboratorios o con autorización
            expresa. Prioriza análisis defensivo, evaluación controlada y documentación.
            No proporciones instrucciones operativas para comprometer sistemas ajenos,
            desplegar malware, robar credenciales o evadir controles.
            Responde con estructura clara: objetivo, análisis, hipótesis, estrategia,
            pasos, herramientas, restricciones, validación y siguiente decisión.
        """.trimIndent()

        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content",
                "SOLICITUD:\n$userText\n\nBRIEF LOCAL SIC:\n$brief"))

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.2)

        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code: ${response.take(900)}")
            }
            val json = JSONObject(response)
            val content = json.getJSONArray("choices")
                .getJSONObject(0).getJSONObject("message").optString("content")
            if (content.isBlank()) throw IllegalStateException("El proveedor devolvió una respuesta vacía.")
            return content
        } finally {
            conn.disconnect()
        }
    }

    private fun append(text: String) {
        transcript.append(text)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(promptInput.windowToken, 0)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF60A5FA.toInt())
        setPadding(0, dp(22), 0, dp(8))
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFFCBD5E1.toInt())
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 14f
        setSingleLine(false)
        setTextColor(0xFFF8FAFC.toInt())
        setHintTextColor(0xFF94A3B8.toInt())
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(0xFF1E293B.toInt())
        val params = LinearLayout.LayoutParams(-1, dp(52))
        params.bottomMargin = dp(9)
        layoutParams = params
    }

    private fun button(textValue: String) = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = 14f
        val params = LinearLayout.LayoutParams(-1, dp(50))
        params.bottomMargin = dp(8)
        layoutParams = params
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
